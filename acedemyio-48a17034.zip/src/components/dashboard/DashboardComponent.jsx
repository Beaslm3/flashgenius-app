import React, { useState, useEffect } from "react";
import { FlashcardSet, Course, Summary } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, Brain, Sparkles, GraduationCap, FileText, AlertCircle, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";
import { Alert, AlertDescription } from "@/components/ui/alert";

import StatsOverview from "./StatsOverview";
import FlashcardSetGrid from "./FlashcardSetGrid";
import RecentActivity from "./RecentActivity";

// Utility function to add delay between API calls
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Retry function with exponential backoff
const retryWithBackoff = async (fn, maxRetries = 3, baseDelay = 1000) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (error.message.includes('Rate limit') && i < maxRetries - 1) {
        const delayTime = baseDelay * Math.pow(2, i);
        console.log(`Rate limit hit, retrying in ${delayTime}ms...`);
        await delay(delayTime);
        continue;
      }
      throw error;
    }
  }
};

export default function DashboardComponent() {
  const [flashcardSets, setFlashcardSets] = useState([]);
  const [courses, setCourses] = useState([]);
  const [summaries, setSummaries] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeFilter, setActiveFilter] = useState("all");
  const [stats, setStats] = useState({
    totalSets: 0,
    totalCards: 0,
    studiedToday: 0,
    totalCourses: 0,
    totalSummaries: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Load data with delays between calls to avoid rate limiting
      console.log("Loading flashcard sets...");
      const sets = await retryWithBackoff(() => FlashcardSet.list("-created_date", 10));
      setFlashcardSets(sets);
      
      await delay(500); // Wait before next call
      
      console.log("Loading courses...");
      const coursesData = await retryWithBackoff(() => Course.list("-created_date", 10));
      setCourses(coursesData);
      
      await delay(500); // Wait before next call
      
      console.log("Loading summaries...");
      const summariesData = await retryWithBackoff(() => Summary.list("-created_date", 10));
      setSummaries(summariesData);
      
      // Calculate stats with the loaded data
      setStats({
        totalSets: sets.length,
        totalCards: sets.reduce((acc, set) => acc + (set.cards_count || 10), 0),
        studiedToday: 0,
        totalCourses: coursesData.length,
        totalSummaries: summariesData.length
      });
      
    } catch (error) {
      console.error("Error loading data:", error);
      setError(error.message.includes('Rate limit') 
        ? "Too many requests. Please wait a moment and try again."
        : "Failed to load dashboard data. Please try again.");
    }
    setIsLoading(false);
  };

  const handleDeleteSet = async (setId) => {
    if (window.confirm("Are you sure you want to delete this flashcard set?")) {
      try {
        await retryWithBackoff(() => FlashcardSet.delete(setId));
        loadData(); // Reload data after deletion
      } catch (error) {
        console.error("Error deleting set:", error);
        setError("Failed to delete flashcard set. Please try again.");
      }
    }
  };

  const handleRetry = () => {
    loadData();
  };

  const filteredSets = flashcardSets.filter(set =>
    set.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    set.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredCourses = courses.filter(course =>
    course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSummaries = summaries.filter(summary =>
    summary.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const quickActions = [
    {
      title: "Create Flashcards",
      description: "Generate AI-powered flashcards instantly",
      icon: Sparkles,
      color: "from-amber-500 to-orange-500",
      link: createPageUrl("Create")
    },
    {
      title: "Build Course",
      description: "Create comprehensive courses with AI",
      icon: GraduationCap,
      color: "from-blue-500 to-indigo-500",
      link: createPageUrl("CourseBuilder")
    },
    {
      title: "AI Summarizer",
      description: "Transform documents into summaries",
      icon: FileText,
      color: "from-green-500 to-emerald-500",
      link: createPageUrl("Summarizer")
    },
    {
      title: "Study Mode",
      description: "Start learning with smart algorithms",
      icon: Brain,
      color: "from-purple-500 to-pink-500",
      link: createPageUrl("Study")
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      {/* Professional Header */}
      <div className="bg-white border-b border-slate-200/60 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl font-bold text-slate-900 mb-2"
              >
                Welcome Back!
              </motion.h1>
              <p className="text-lg text-slate-600">Continue your learning journey with AI-powered tools</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input
                  placeholder="Search your content..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 w-full sm:w-80 h-12 bg-slate-50/80 border-slate-200 focus:bg-white transition-colors"
                />
              </div>
              <Link to={createPageUrl("Create")}>
                <Button className="h-12 px-6 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-lg hover:shadow-xl transition-all">
                  <Plus className="w-5 h-5 mr-2" />
                  Create New
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-8">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>{error}</span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleRetry}
                className="ml-4"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Enhanced Stats Overview */}
        <StatsOverview stats={stats} isLoading={isLoading} />

        {/* Quick Actions */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={action.link}>
                  <div className="group cursor-pointer">
                    <div className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-200/50 hover:border-slate-300/50 group-hover:scale-105">
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-r ${action.color} flex items-center justify-center mb-4 shadow-lg`}>
                        <action.icon className="w-7 h-7 text-white" />
                      </div>
                      <h3 className="font-semibold text-slate-900 mb-2 group-hover:text-slate-700">
                        {action.title}
                      </h3>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {action.description}
                      </p>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Content Filters */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-3">
            {[
              { key: "all", label: "All Content", count: stats.totalSets + stats.totalCourses + stats.totalSummaries },
              { key: "flashcards", label: "Flashcard Sets", count: stats.totalSets },
              { key: "courses", label: "Courses", count: stats.totalCourses },
              { key: "summaries", label: "Summaries", count: stats.totalSummaries }
            ].map((filter) => (
              <button
                key={filter.key}
                onClick={() => setActiveFilter(filter.key)}
                className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                  activeFilter === filter.key
                    ? "bg-slate-900 text-white shadow-lg"
                    : "bg-white text-slate-600 hover:bg-slate-50 border border-slate-200"
                }`}
              >
                {filter.label}
                <span className="ml-2 text-xs opacity-75">({filter.count})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <FlashcardSetGrid 
              sets={activeFilter === "all" || activeFilter === "flashcards" ? filteredSets : []}
              courses={activeFilter === "all" || activeFilter === "courses" ? filteredCourses : []}
              summaries={activeFilter === "all" || activeFilter === "summaries" ? filteredSummaries : []}
              onDeleteSet={handleDeleteSet}
              isLoading={isLoading}
            />
          </div>
          <div className="lg:col-span-1">
            <RecentActivity />
          </div>
        </div>
      </div>
    </div>
  );
}