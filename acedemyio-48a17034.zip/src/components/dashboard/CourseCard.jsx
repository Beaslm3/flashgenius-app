import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Users, Clock, PlayCircle, BookOpen, Brain } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function CourseCard({ course, index = 0 }) {
  if (!course) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Card className="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer h-full flex flex-col">
        <div className="aspect-video bg-gradient-to-br from-indigo-100 to-purple-100 rounded-t-lg flex items-center justify-center relative overflow-hidden">
          <PlayCircle className="w-12 h-12 text-indigo-600 opacity-70" />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
        </div>
        
        <CardContent className="p-6 flex-grow flex flex-col">
          <div className="flex-grow">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="secondary" className="text-xs font-medium bg-indigo-100 text-indigo-800">
                {course.subject}
              </Badge>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span className="text-sm text-gray-600">4.8</span>
              </div>
            </div>
            
            <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
              {course.title}
            </h3>
            
            <p className="text-sm text-gray-600 mb-4 line-clamp-2">
              {course.meta_description || `A comprehensive ${course.level} course covering the fundamentals of ${course.subject}.`}
            </p>
            
            <div className="flex items-center gap-4 mb-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                <span>1.2k students</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Self-paced</span>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className="text-xs">
                {course.level}
              </Badge>
              {course.language && (
                <Badge variant="outline" className="text-xs">
                  {course.language}
                </Badge>
              )}
            </div>
          </div>
          
          <Button
            onClick={() => window.location.href = createPageUrl(`CourseViewer?id=${course.id}`)}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white mt-auto"
          >
            <Brain className="w-4 h-4 mr-2" />
            Start Learning
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}