import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Trophy, Target } from "lucide-react";

const activities = [
  {
    icon: Trophy,
    title: "Study Streak",
    description: "Keep up the momentum!",
    time: "Today",
    color: "text-amber-600"
  },
  {
    icon: Target,
    title: "Daily Goal",
    description: "Review 20 cards",
    time: "0/20 completed",
    color: "text-blue-600"
  },
  {
    icon: Clock,
    title: "Study Reminder",
    description: "Time for your daily review",
    time: "In 2 hours",
    color: "text-purple-600"
  }
];

export default function RecentActivity() {
  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="text-lg font-bold text-slate-900">Study Goals</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity, index) => (
          <div key={index} className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
            <div className={`p-2 rounded-lg bg-slate-50 ${activity.color}`}>
              <activity.icon className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-slate-900 text-sm">{activity.title}</p>
              <p className="text-xs text-slate-500 mt-1">{activity.description}</p>
              <p className="text-xs text-slate-400 mt-1">{activity.time}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}