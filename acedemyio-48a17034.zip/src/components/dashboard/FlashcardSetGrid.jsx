
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreVertical, Edit, Download, Trash2, Brain, BookOpen, FileText, GraduationCap, Clock, Star } from 'lucide-react';
import { motion } from 'framer-motion';

const typeInfo = {
    flashcards: {
        icon: BookOpen,
        title: "Flashcard Sets",
        studyUrl: (id) => createPageUrl(`Study?set=${id}`),
        editUrl: (id) => createPageUrl(`Edit?set=${id}`),
        gradient: "from-blue-500 to-indigo-500"
    },
    course: {
        icon: GraduationCap,
        title: "Courses",
        studyUrl: (id) => createPageUrl(`CourseViewer?id=${id}`), 
        editUrl: null,
        gradient: "from-green-500 to-emerald-500"
    },
    summary: {
        icon: FileText,
        title: "Summaries",
        studyUrl: null,
        editUrl: null,
        gradient: "from-purple-500 to-pink-500"
    }
};

const subjectImages = {
    mathematics: 'https://images.unsplash.com/photo-1596495577886-d9256f4e224a?w=400&h=250&fit=crop&crop=entropy',
    math: 'https://images.unsplash.com/photo-1596495577886-d9256f4e224a?w=400&h=250&fit=crop&crop=entropy',
    science: 'https://images.unsplash.com/photo-1574974671999-636df4a504e2?w=400&h=250&fit=crop&crop=entropy',
    biology: 'https://images.unsplash.com/photo-1530026405182-2813c32d6975?w=400&h=250&fit=crop&crop=entropy',
    chemistry: 'https://images.unsplash.com/photo-1627807094848-03c0a52697a4?w=400&h=250&fit=crop&crop=entropy',
    physics: 'https://images.unsplash.com/photo-1576319155264-99e416e4b8a2?w=400&h=250&fit=crop&crop=entropy',
    history: 'https://images.unsplash.com/photo-1581888222955-420959a7272b?w=400&h=250&fit=crop&crop=entropy',
    geography: 'https://images.unsplash.com/photo-1542037104-924825dc12e4?w=400&h=250&fit=crop&crop=entropy',
    english: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=400&h=250&fit=crop&crop=entropy',
    literature: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=400&h=250&fit=crop&crop=entropy',
    coding: 'https://images.unsplash.com/photo-1592609931095-54a2168ae893?w=400&h=250&fit=crop&crop=entropy',
    programming: 'https://images.unsplash.com/photo-1592609931095-54a2168ae893?w=400&h=250&fit=crop&crop=entropy',
    art: 'https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=400&h=250&fit=crop&crop=entropy',
    music: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&h=250&fit=crop&crop=entropy',
    economics: 'https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?w=400&h=250&fit=crop&crop=entropy',
    business: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=250&fit=crop&crop=entropy',
    languages: 'https://images.unsplash.com/photo-1521335839443-41a8b18431e2?w=400&h=250&fit=crop&crop=entropy',
    health: 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=400&h=250&fit=crop&crop=entropy',
    psychology: 'https://images.unsplash.com/photo-1579548122080-c35fd6820ecb?w=400&h=250&fit=crop&crop=entropy',
    philosophy: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=250&fit=crop&crop=entropy',
    default: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=250&fit=crop&crop=entropy'
};

const getSubjectImage = (subject) => {
    const normalizedSubject = subject?.toLowerCase().replace(/\s+/g, '');
    return subjectImages[normalizedSubject] || subjectImages.default;
};

const difficultyColors = {
    beginner: 'bg-green-100 text-green-800 border-green-200',
    intermediate: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    advanced: 'bg-red-100 text-red-800 border-red-200',
    easy: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    hard: 'bg-red-100 text-red-800 border-red-200'
};

const ItemCard = ({ item, type, onDeleteSet }) => {
    const navigate = useNavigate();
    const info = typeInfo[type];

    const onExport = () => {
        navigate(createPageUrl(`Export?type=${type}&id=${item.id}`));
    };

    const onStudy = () => {
        if (info.studyUrl) {
            navigate(info.studyUrl(item.id));
        }
    };

    const onEdit = () => {
        if (info.editUrl) {
            navigate(info.editUrl(item.id));
        }
    };

    const onDelete = () => {
        if (type === 'flashcards' && onDeleteSet) {
            onDeleteSet(item.id);
        }
    };

    const coverImage = item.cover_image_url || getSubjectImage(item.subject);

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="h-full"
        >
            <Card className="h-full flex flex-col group transition-all duration-300 bg-white/90 backdrop-blur-sm border-slate-200/50 shadow-sm hover:shadow-xl hover:border-slate-300/50 hover:-translate-y-1">
                <CardHeader className="relative p-0 overflow-hidden">
                    <div className="absolute top-3 right-3 z-10">
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="secondary" size="icon" className="w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm shadow-sm hover:bg-white transition-all">
                                    <MoreVertical className="w-4 h-4 text-slate-600" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-40">
                                {info.editUrl && (
                                    <DropdownMenuItem onSelect={onEdit}>
                                        <Edit className="mr-2 h-4 w-4" />
                                        <span>Edit</span>
                                    </DropdownMenuItem>
                                )}
                                <DropdownMenuItem onSelect={onExport}>
                                    <Download className="mr-2 h-4 w-4" />
                                    <span>Export</span>
                                </DropdownMenuItem>
                                {type === 'flashcards' && onDeleteSet && (
                                    <DropdownMenuItem onSelect={onDelete} className="text-red-600 focus:text-red-600">
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        <span>Delete</span>
                                    </DropdownMenuItem>
                                )}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                    
                    <div className="relative h-40 overflow-hidden">
                        <img 
                            src={coverImage} 
                            alt={item.title} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                        
                        {/* Subject Badge */}
                        <div className="absolute bottom-3 left-3">
                            <Badge className="bg-white/90 text-slate-800 backdrop-blur-sm border-0 shadow-sm">
                                {item.subject}
                            </Badge>
                        </div>
                    </div>
                </CardHeader>
                
                <CardContent className="flex-grow flex flex-col justify-between p-5">
                    <div className="space-y-3">
                        <div>
                            <CardTitle className="text-lg font-bold text-slate-900 line-clamp-2 leading-tight">
                                {item.title}
                            </CardTitle>
                            {item.description && (
                                <CardDescription className="text-sm text-slate-600 line-clamp-2 mt-2 leading-relaxed">
                                    {item.description}
                                </CardDescription>
                            )}
                        </div>
                        
                        <div className="flex flex-wrap gap-2">
                            {item.difficulty && (
                                <Badge variant="outline" className={`text-xs capitalize ${difficultyColors[item.difficulty] || 'bg-slate-100 text-slate-800'}`}>
                                    {item.difficulty}
                                </Badge>
                            )}
                            {item.source_type && (
                                <Badge variant="outline" className="text-xs text-slate-600">
                                    {item.source_type.replace(/_/g, ' ')}
                                </Badge>
                            )}
                            {type === 'flashcards' && item.cards_count && (
                                <Badge variant="outline" className="text-xs text-blue-600">
                                    <BookOpen className="w-3 h-3 mr-1" />
                                    {item.cards_count} cards
                                </Badge>
                            )}
                        </div>
                    </div>
                    
                    <div className="mt-4 space-y-2">
                        {info.studyUrl && (
                            <Button 
                                onClick={onStudy} 
                                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-sm hover:shadow-md transition-all"
                                size="sm"
                            >
                                <Brain className="w-4 h-4 mr-2" />
                                Study Now
                            </Button>
                        )}
                        
                        <div className="flex items-center justify-between text-xs text-slate-500">
                            <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>
                                    {item.created_date ? new Date(item.created_date).toLocaleDateString() : 'Recently'}
                                </span>
                            </div>
                            <div className="flex items-center gap-1">
                                <Star className="w-3 h-3" />
                                <span>4.8</span>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default function FlashcardSetGrid({ sets = [], courses = [], summaries = [], onDeleteSet, isLoading }) {
    const items = {
        flashcards: sets,
        course: courses,
        summary: summaries,
    };

    const hasItems = sets.length > 0 || courses.length > 0 || summaries.length > 0;

    if (isLoading) {
        return (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(6)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                        <Card className="h-80 bg-white/80 backdrop-blur-sm border-slate-200/50">
                            <div className="h-40 bg-slate-200 rounded-t-lg"></div>
                            <CardContent className="p-5 space-y-3">
                                <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                                <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                                <div className="h-8 bg-slate-200 rounded w-full"></div>
                            </CardContent>
                        </Card>
                    </div>
                ))}
            </div>
        );
    }

    if (!hasItems) {
        return (
            <div className="text-center py-20">
                <div className="w-32 h-32 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                    <BookOpen className="w-16 h-16 text-slate-400" />
                </div>
                <h3 className="text-3xl font-bold text-slate-800 mb-4">Ready to Start Learning?</h3>
                <p className="text-slate-600 mb-8 max-w-md mx-auto text-lg leading-relaxed">
                    Create your first flashcard set, course, or summary with our AI-powered tools and begin your educational journey.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all">
                        <BookOpen className="w-5 h-5 mr-2" />
                        Create Flashcards
                    </Button>
                    <Button variant="outline" className="px-8 py-3 text-lg border-slate-300 hover:border-slate-400 hover:bg-slate-50 transition-all">
                        Browse Examples
                    </Button>
                </div>
            </div>
        );
    }
    
    return (
        <div className="space-y-12">
            {Object.entries(items).map(([type, itemList]) => {
                if (itemList.length === 0) return null;
                const info = typeInfo[type];
                return (
                    <div key={type}>
                        <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 bg-gradient-to-r ${info.gradient} rounded-xl flex items-center justify-center shadow-lg`}>
                                    <info.icon className="w-6 h-6 text-white" />
                                </div>
                                <div>
                                    <h2 className="text-2xl font-bold text-slate-800">{info.title}</h2>
                                    <p className="text-slate-600">
                                        {itemList.length} {itemList.length === 1 ? 'item' : 'items'} available
                                    </p>
                                </div>
                            </div>
                            <Badge variant="outline" className="text-sm px-3 py-1">
                                {itemList.length}
                            </Badge>
                        </div>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {itemList.map(item => (
                                <ItemCard key={item.id} item={item} type={type} onDeleteSet={onDeleteSet} />
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
