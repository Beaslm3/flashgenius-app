import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { BookOpen, GraduationCap, FileText, TrendingUp, Users, Clock, Target, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function StatsOverview({ stats, isLoading }) {
    const statCards = [
        {
            title: "Flashcard Sets",
            value: stats.totalSets,
            icon: BookOpen,
            color: "from-blue-500 to-blue-600",
            bgColor: "bg-blue-50",
            change: "+12%"
        },
        {
            title: "Total Cards",
            value: stats.totalCards,
            icon: Sparkles,
            color: "from-amber-500 to-amber-600",
            bgColor: "bg-amber-50",
            change: "+8%"
        },
        {
            title: "Courses Created",
            value: stats.totalCourses,
            icon: GraduationCap,
            color: "from-green-500 to-green-600",
            bgColor: "bg-green-50",
            change: "+15%"
        },
        {
            title: "AI Summaries",
            value: stats.totalSummaries,
            icon: FileText,
            color: "from-purple-500 to-purple-600",
            bgColor: "bg-purple-50",
            change: "+23%"
        }
    ];

    if (isLoading) {
        return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                {[...Array(4)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                        <Card className="bg-white border-slate-200/50">
                            <CardContent className="p-6">
                                <div className="h-4 bg-slate-200 rounded w-1/2 mb-4"></div>
                                <div className="h-8 bg-slate-200 rounded w-1/3 mb-2"></div>
                                <div className="h-3 bg-slate-200 rounded w-1/4"></div>
                            </CardContent>
                        </Card>
                    </div>
                ))}
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {statCards.map((stat, index) => (
                <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                >
                    <Card className="relative overflow-hidden bg-white border-slate-200/50 hover:shadow-lg transition-all duration-300 group">
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                                    <stat.icon className={`w-6 h-6 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`} />
                                </div>
                                <div className="text-right">
                                    <div className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                                        {stat.change}
                                    </div>
                                </div>
                            </div>
                            
                            <div className="space-y-2">
                                <h3 className="text-sm font-medium text-slate-600">
                                    {stat.title}
                                </h3>
                                <div className="text-3xl font-bold text-slate-900">
                                    {stat.value.toLocaleString()}
                                </div>
                            </div>
                            
                            {/* Subtle background gradient */}
                            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${stat.color} opacity-5 rounded-full -translate-y-16 translate-x-16`}></div>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
}