import React, { useState, useEffect } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Bot, 
  Send, 
  Loader2, 
  Sparkles, 
  Lightbulb, 
  FileText, 
  Users, 
  BarChart,
  MessageSquare,
  X,
  Minimize2,
  Maximize2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const suggestions = [
  { icon: FileText, text: "Generate a quiz for this lesson", action: "quiz" },
  { icon: Users, text: "Create student engagement activities", action: "engagement" },
  { icon: BarChart, text: "Analyze course performance", action: "analytics" },
  { icon: MessageSquare, text: "Write an announcement", action: "announcement" },
  { icon: Lightbulb, text: "Suggest improvements", action: "improve" },
  { icon: Sparkles, text: "Generate learning objectives", action: "objectives" }
];

export default function AICopilot({ context = {}, onAction = () => {}, isMinimized = false, onToggleMinimize = () => {} }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [contextualSuggestions, setContextualSuggestions] = useState([]);

  useEffect(() => {
    // Generate contextual suggestions based on current context
    if (context.type === 'course-editor') {
      setContextualSuggestions([
        { icon: FileText, text: "Improve this module content", action: "improve-module" },
        { icon: Users, text: "Add interactive elements", action: "add-interactive" },
        { icon: Sparkles, text: "Generate quiz questions", action: "generate-quiz" }
      ]);
    } else if (context.type === 'dashboard') {
      setContextualSuggestions([
        { icon: BarChart, text: "Analyze student progress", action: "analyze-progress" },
        { icon: MessageSquare, text: "Draft weekly announcement", action: "draft-announcement" },
        { icon: Lightbulb, text: "Course improvement ideas", action: "improvement-ideas" }
      ]);
    } else {
      setContextualSuggestions(suggestions);
    }
  }, [context]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage = { type: 'user', content: inputText, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      const contextInfo = context.courseTitle ? `Course: ${context.courseTitle}` : '';
      const moduleInfo = context.currentModule ? `Module: ${context.currentModule}` : '';
      
      const prompt = `You are an AI educational assistant helping teachers and students. 
      
Context: ${contextInfo} ${moduleInfo}
User Request: ${inputText}

Provide helpful, actionable advice in a friendly, professional tone. Keep responses concise but informative.`;

      const response = await InvokeLLM({ prompt });
      
      const aiMessage = { type: 'ai', content: response, timestamp: new Date() };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage = { 
        type: 'error', 
        content: 'Sorry, I encountered an error. Please try again.', 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionClick = async (suggestion) => {
    setInputText(suggestion.text);
    if (onAction) {
      onAction(suggestion.action, context);
    }
  };

  if (isMinimized) {
    return (
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Button
          onClick={() => {
            setIsOpen(true);
            onToggleMinimize();
          }}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
        >
          <Bot className="w-6 h-6 text-white" />
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-6 right-6 z-50"
    >
      <Card className="w-96 h-[500px] shadow-2xl border-0 bg-white">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Bot className="w-5 h-5" />
              AI Copilot
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={onToggleMinimize}
                className="text-white hover:bg-white/20 w-8 h-8"
              >
                <Minimize2 className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/20 w-8 h-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0 flex flex-col h-[420px]">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 ? (
              <div className="text-center py-8">
                <Bot className="w-12 h-12 text-blue-500 mx-auto mb-3" />
                <p className="text-gray-600 mb-4">Hi! I'm your AI assistant. How can I help you today?</p>
                
                <div className="space-y-2">
                  {contextualSuggestions.slice(0, 3).map((suggestion, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => handleSuggestionClick(suggestion)}
                      className="w-full text-left justify-start"
                    >
                      <suggestion.icon className="w-4 h-4 mr-2" />
                      {suggestion.text}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-blue-600 text-white'
                        : message.type === 'error'
                        ? 'bg-red-50 text-red-700 border border-red-200'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))
            )}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 p-3 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm text-gray-600">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="border-t p-4">
            <div className="flex gap-2">
              <Input
                placeholder="Ask me anything..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage} disabled={isLoading || !inputText.trim()}>
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}