import React, { useState, useEffect, useRef } from "react";
import { User, AISession } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  MessageCircle, 
  X, 
  Send, 
  Minimize2, 
  Maximize2, 
  Sparkles, 
  Brain, 
  BookOpen, 
  Zap,
  Mic,
  MicOff,
  Volume2,
  Settings
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "react-router-dom";
import ReactMarkdown from "react-markdown";

const NIA_PERSONALITY = `You are Nia, the Next-Gen Intelligent Assistant for Acedemy.io - a warm, encouraging, and highly capable AI companion. You help users learn, create content, and achieve their goals.

PERSONALITY TRAITS:
- Warm, confident, and encouraging
- Speak in short, actionable prompts
- Celebrate user wins and progress
- Proactive in offering help
- Remember user context and preferences
- Professional but friendly tone

CORE RESPONSIBILITIES:
- Guide users through features and workflows
- Suggest next steps based on their current context
- Help generate content when requested
- Answer questions about the platform
- Motivate and encourage learning progress
- Provide contextual tips and best practices`;

const getContextualPrompts = (pathname, user) => {
  const prompts = {
    '/dashboard': [
      "Ready to create something amazing today?",
      "I notice you have some courses in progress. Want to finish one?",
      "How about generating some flashcards for your latest topic?"
    ],
    '/coursebuilder': [
      "Building a new course? I can help brainstorm topics!",
      "Need help structuring your course outline?",
      "Want me to suggest learning objectives for your course?"
    ],
    '/create': [
      "Creating flashcards? I can help optimize your questions!",
      "Need ideas for better flashcard formats?",
      "Want to add images to make your flashcards more engaging?"
    ],
    '/summarizer': [
      "Summarizing content? I can help you choose the best format!",
      "Need help deciding on summary length?",
      "Want tips for better document processing?"
    ],
    '/calculator': [
      "Working on math problems? I can help explain the steps!",
      "Need help with a specific math topic?",
      "Want me to generate practice problems?"
    ],
    '/test': [
      "Taking a test? I can provide study tips!",
      "Need help understanding a question format?",
      "Want strategies for better test performance?"
    ],
    '/progressreports': [
      "Ready to track your learning progress?",
      "Want help setting new learning goals?",
      "Need motivation to continue your learning streak?"
    ]
  };

  const defaultPrompts = [
    `Hi ${user?.full_name?.split(' ')[0] || 'there'}! What can I help you with today?`,
    "I'm here to help you learn and create. What's your goal?",
    "Need assistance with any of our AI tools?"
  ];

  return prompts[pathname] || defaultPrompts;
};

export default function NiaAssistant() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadUserAndSession();
    setupSpeechRecognition();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (user && isOpen && messages.length === 0) {
      sendContextualGreeting();
    }
  }, [location.pathname, isOpen, user]);

  const loadUserAndSession = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Load or create AI session
      const sessions = await AISession.filter({ 
        user_id: currentUser.id, 
        status: 'active' 
      }, '-created_date', 1);
      
      if (sessions.length > 0) {
        const existingSession = sessions[0];
        setSession(existingSession);
        setMessages(existingSession.conversation_history || []);
      } else {
        await createNewSession(currentUser);
      }
    } catch (error) {
      console.error("Error loading user session:", error);
    }
  };

  const createNewSession = async (currentUser) => {
    try {
      const newSession = await AISession.create({
        user_id: currentUser.id,
        session_type: 'general',
        context: {
          user_name: currentUser.full_name,
          onboarding_completed: false,
          learning_preferences: {},
          current_goals: []
        },
        conversation_history: [],
        user_preferences: {
          language: 'en',
          learning_style: 'adaptive'
        }
      });
      setSession(newSession);
    } catch (error) {
      console.error("Error creating session:", error);
    }
  };

  const setupSpeechRecognition = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognitionInstance = new window.webkitSpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';
      recognitionInstance.onresult = (event) => {
        setInputMessage(event.results[0][0].transcript);
      };
      recognitionInstance.onend = () => setIsListening(false);
      setRecognition(recognitionInstance);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      recognition?.stop();
    } else {
      recognition?.start();
    }
    setIsListening(!isListening);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const sendContextualGreeting = async () => {
    const contextualPrompts = getContextualPrompts(location.pathname, user);
    const greeting = contextualPrompts[Math.floor(Math.random() * contextualPrompts.length)];
    
    const welcomeMessage = {
      role: 'ai',
      content: greeting,
      timestamp: new Date().toISOString(),
      metadata: { type: 'contextual_greeting' }
    };
    
    setMessages([welcomeMessage]);
    await updateSessionHistory([welcomeMessage]);
  };

  const updateSessionHistory = async (newMessages) => {
    if (!session) return;
    
    try {
      await AISession.update(session.id, {
        conversation_history: newMessages,
        context: {
          ...session.context,
          last_interaction: new Date().toISOString(),
          current_page: location.pathname
        }
      });
    } catch (error) {
      console.error("Error updating session:", error);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage = {
      role: 'user',
      content: inputMessage.trim(),
      timestamp: new Date().toISOString()
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInputMessage("");
    setIsLoading(true);

    try {
      const contextPrompt = `${NIA_PERSONALITY}

CURRENT CONTEXT:
- User: ${user?.full_name || 'User'}
- Current Page: ${location.pathname}
- Time: ${new Date().toLocaleString()}

CONVERSATION HISTORY:
${messages.slice(-5).map(m => `${m.role}: ${m.content}`).join('\n')}

USER MESSAGE: ${userMessage.content}

Respond as Nia with helpful, encouraging, and contextually relevant advice. Keep responses concise but warm.`;

      const aiResponse = await InvokeLLM({
        prompt: contextPrompt,
        add_context_from_internet: false
      });

      const aiMessage = {
        role: 'ai',
        content: aiResponse,
        timestamp: new Date().toISOString(),
        metadata: { 
          context_page: location.pathname,
          response_type: 'conversational'
        }
      };

      const finalMessages = [...updatedMessages, aiMessage];
      setMessages(finalMessages);
      await updateSessionHistory(finalMessages);

      // Text-to-speech for AI responses
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(aiResponse);
        utterance.rate = 0.9;
        utterance.pitch = 1.1;
        window.speechSynthesis.speak(utterance);
      }

    } catch (error) {
      console.error("Error getting AI response:", error);
      const errorMessage = {
        role: 'ai',
        content: "I'm having trouble connecting right now. Please try again in a moment!",
        timestamp: new Date().toISOString(),
        metadata: { type: 'error' }
      };
      setMessages([...updatedMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!user) return null;

  return (
    <>
      {/* Floating Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            className="fixed bottom-6 right-6 z-50"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="w-14 h-14 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
              size="icon"
            >
              <MessageCircle className="w-6 h-6" />
            </Button>
            <div className="absolute -top-2 -right-2 w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Interface */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-6 right-6 z-50"
            initial={{ scale: 0, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0, opacity: 0, y: 20 }}
          >
            <Card className={`w-80 sm:w-96 ${isMinimized ? 'h-16' : 'h-96'} bg-white/95 backdrop-blur-sm shadow-2xl border-0 overflow-hidden transition-all duration-300`}>
              <CardHeader className="p-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <CardTitle className="text-sm font-medium">Nia Assistant</CardTitle>
                      <p className="text-xs opacity-90">Your AI Learning Companion</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setIsMinimized(!isMinimized)}
                      className="h-6 w-6 text-white/80 hover:text-white hover:bg-white/20"
                    >
                      {isMinimized ? <Maximize2 className="w-3 h-3" /> : <Minimize2 className="w-3 h-3" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setIsOpen(false)}
                      className="h-6 w-6 text-white/80 hover:text-white hover:bg-white/20"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              {!isMinimized && (
                <CardContent className="p-0 flex flex-col h-80">
                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {messages.map((message, index) => (
                      <div
                        key={index}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] p-3 rounded-lg ${
                            message.role === 'user'
                              ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          <div className="text-sm">
                            <ReactMarkdown>{message.content}</ReactMarkdown>
                          </div>
                          <div className="text-xs opacity-70 mt-1">
                            {new Date(message.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-gray-100 rounded-lg p-3">
                          <div className="flex items-center gap-2">
                            <div className="animate-spin w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full"></div>
                            <span className="text-sm text-gray-600">Nia is thinking...</span>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Input */}
                  <div className="border-t p-3">
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="Ask Nia anything..."
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        onKeyPress={handleKeyPress}
                        disabled={isLoading}
                        className="flex-1 border-gray-200 focus:border-purple-400"
                      />
                      {recognition && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleListening}
                          className={`h-8 w-8 ${isListening ? 'text-red-500' : 'text-gray-500'}`}
                        >
                          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                        </Button>
                      )}
                      <Button
                        onClick={handleSendMessage}
                        disabled={isLoading || !inputMessage.trim()}
                        size="icon"
                        className="h-8 w-8 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}