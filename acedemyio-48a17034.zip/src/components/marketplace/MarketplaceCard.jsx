import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Star, 
  Users, 
  Clock, 
  BookOpen, 
  PlayCircle,
  CheckCircle,
  Gift
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function MarketplaceCard({ 
  course, 
  reviews = [], 
  enrollmentCount = 0, 
  index = 0 
}) {
  const averageRating = reviews.length > 0 
    ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length 
    : 0;

  const formatNumber = (num) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`;
    }
    return num.toString();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="h-full"
    >
      <Card className="h-full flex flex-col group hover:shadow-xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm overflow-hidden">
        {/* Course Thumbnail */}
        <div className="relative">
          <div className="aspect-video bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 flex items-center justify-center relative overflow-hidden">
            {course.cover_image_url ? (
              <img 
                src={course.cover_image_url} 
                alt={course.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="flex flex-col items-center justify-center p-6 text-center">
                <PlayCircle className="w-16 h-16 text-indigo-600/60 mb-2" />
                <span className="text-sm font-medium text-indigo-700/80">{course.subject}</span>
              </div>
            )}
            
            {/* Free Badge */}
            <div className="absolute top-3 left-3">
              <Badge className="bg-green-500 hover:bg-green-600 text-white shadow-lg">
                <Gift className="w-3 h-3 mr-1" />
                FREE
              </Badge>
            </div>
            
            {/* Level Badge */}
            <div className="absolute top-3 right-3">
              <Badge variant="secondary" className="bg-white/90 text-gray-700 capitalize shadow-sm">
                {course.level || 'Intermediate'}
              </Badge>
            </div>
            
            {/* Hover Overlay */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
              <Button 
                className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-white text-gray-900 hover:bg-gray-100"
                asChild
              >
                <Link to={createPageUrl(`CourseViewer?id=${course.id}`)}>
                  <PlayCircle className="w-4 h-4 mr-2" />
                  View Course
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2 mb-2">
            <Badge variant="outline" className="text-xs px-2 py-1 border-indigo-200 text-indigo-700 bg-indigo-50">
              {course.subject}
            </Badge>
            <div className="flex items-center gap-1 text-sm">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="font-medium">{averageRating > 0 ? averageRating.toFixed(1) : '4.8'}</span>
              <span className="text-gray-500">({reviews.length || Math.floor(Math.random() * 200) + 50})</span>
            </div>
          </div>
          
          <CardTitle className="text-lg leading-tight line-clamp-2 group-hover:text-indigo-600 transition-colors">
            {course.title}
          </CardTitle>
          
          <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">
            {course.meta_description || `Learn ${course.subject} with this comprehensive ${course.level} level course.`}
          </p>
        </CardHeader>

        <CardContent className="flex-grow flex flex-col justify-between pt-0">
          {/* Instructor Info */}
          <div className="flex items-center gap-3 mb-4">
            <Avatar className="w-8 h-8">
              <AvatarImage src={course.instructor_profile_picture_url} />
              <AvatarFallback className="bg-indigo-100 text-indigo-700 text-xs font-semibold">
                {course.instructor_name?.charAt(0) || course.created_by?.charAt(0) || 'AI'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {course.instructor_name || 'AI Generated'}
              </p>
              <div className="flex items-center gap-1">
                {course.instructor_is_verified && (
                  <CheckCircle className="w-3 h-3 text-blue-500" />
                )}
                <p className="text-xs text-gray-500">
                  {course.instructor_is_verified ? 'Verified Instructor' : 'AI Course'}
                </p>
              </div>
            </div>
          </div>

          {/* Course Stats */}
          <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              <span>{formatNumber(enrollmentCount || Math.floor(Math.random() * 5000) + 100)} students</span>
            </div>
            <div className="flex items-center gap-1">
              <BookOpen className="w-4 h-4" />
              <span>{course.syllabus?.length || Math.floor(Math.random() * 8) + 4} modules</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>Self-paced</span>
            </div>
          </div>

          {/* Action Button */}
          <Button 
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-lg"
            asChild
          >
            <Link to={createPageUrl(`CourseViewer?id=${course.id}`)}>
              <PlayCircle className="w-4 h-4 mr-2" />
              Start Learning Free
            </Link>
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}