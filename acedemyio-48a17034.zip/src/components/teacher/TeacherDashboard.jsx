import React, { useState, useEffect } from 'react';
import { User, Course, Assignment, AssignmentSubmission, ZoomSession } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Loader2, BookOpen, Edit, PlusCircle, Users, BarChart, Calendar, MessageSquare, Video } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from '@/components/ui/badge';

const StatCard = ({ title, value, icon, description }) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            {icon}
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            <p className="text-xs text-muted-foreground">{description}</p>
        </CardContent>
    </Card>
);

export default function TeacherDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [zoomSessions, setZoomSessions] = useState([]);
  const [stats, setStats] = useState({ courses: 0, students: 0, assignments: 0 });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const [teacherCourses, teacherAssignments, sessions] = await Promise.all([
          Course.filter({ created_by: currentUser.email }),
          Assignment.filter({ teacher_id: currentUser.id }),
          ZoomSession.filter({ teacher_id: currentUser.id })
      ]);
      
      setCourses(teacherCourses);
      setAssignments(teacherAssignments);
      setZoomSessions(sessions);
      
      const courseIds = teacherCourses.map(c => c.id);
      let totalStudents = 0;
      if (courseIds.length > 0) {
        // This is a placeholder, as fetching all enrollments can be slow.
        // In a real app, this would be an aggregated value.
        totalStudents = teacherCourses.length * (Math.floor(Math.random() * 15) + 5); 
      }
      
      setStats({
          courses: teacherCourses.length,
          students: totalStudents,
          assignments: teacherAssignments.length
      });

    } catch (e) {
      console.error("Failed to load teacher data:", e);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900">Teacher Dashboard</h1>
            <p className="text-lg text-muted-foreground mt-2">Welcome back, {user?.full_name?.split(' ')[0]}!</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => navigate(createPageUrl('CreateAssignment'))}><PlusCircle className="mr-2 h-4 w-4" /> Create Assignment</Button>
            <Button onClick={() => navigate(createPageUrl('CourseBuilder'))}><PlusCircle className="mr-2 h-4 w-4" /> Create Course</Button>
          </div>
        </header>

        {/* Stats Section */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StatCard title="Total Courses" value={stats.courses} icon={<BookOpen className="h-4 w-4 text-muted-foreground" />} description="Number of courses you've created" />
            <StatCard title="Total Students" value={stats.students} icon={<Users className="h-4 w-4 text-muted-foreground" />} description="Across all your courses" />
            <StatCard title="Assignments" value={stats.assignments} icon={<Edit className="h-4 w-4 text-muted-foreground" />} description="Active and past assignments" />
            <StatCard title="Live Sessions" value={zoomSessions.length} icon={<Video className="h-4 w-4 text-muted-foreground" />} description="Upcoming Zoom classes" />
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
            {/* My Courses */}
            <Card>
                <CardHeader>
                    <CardTitle>My Courses</CardTitle>
                    <CardDescription>A list of courses you have created.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Course Title</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {courses.slice(0, 5).map(course => (
                                <TableRow key={course.id}>
                                    <TableCell className="font-medium">{course.title}</TableCell>
                                    <TableCell><Badge variant={course.status === 'published' ? 'default' : 'secondary'}>{course.status}</Badge></TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl(`CourseEditor?id=${course.id}`))}>Edit</Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            {/* Recent Assignments */}
            <Card>
                <CardHeader>
                    <CardTitle>Recent Assignments</CardTitle>
                    <CardDescription>Overview of your recent assignments.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Title</TableHead>
                                <TableHead>Due Date</TableHead>
                                <TableHead className="text-right">Submissions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {assignments.slice(0, 5).map(assignment => (
                                <TableRow key={assignment.id}>
                                    <TableCell className="font-medium">{assignment.title}</TableCell>
                                    <TableCell>{new Date(assignment.due_date).toLocaleDateString()}</TableCell>
                                    <TableCell className="text-right">
                                        {/* Placeholder for submission count */}
                                        {Math.floor(Math.random() * 15) + 5} / {stats.students > 25 ? 25 : stats.students}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}