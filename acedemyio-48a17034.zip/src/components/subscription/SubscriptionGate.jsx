import React, { useState, useEffect } from "react";
import { User, Subscription } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Lock, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const PLAN_LIMITS = {
  free: {
    monthly_cards: 50,
    monthly_ai_requests: 25,
    max_sets: 5,
    visual_cards: false,
    document_upload: false,
    supported_languages: 5,
    export_formats: ["csv"]
  },
  pro: {
    monthly_cards: 500,
    monthly_ai_requests: 250,
    max_sets: -1, // unlimited
    visual_cards: true,
    document_upload: true,
    supported_languages: -1, // unlimited
    export_formats: ["csv", "pdf", "docx"]
  },
  premium: {
    monthly_cards: 2000,
    monthly_ai_requests: 1000,
    max_sets: -1,
    visual_cards: true,
    document_upload: true,
    supported_languages: -1,
    export_formats: ["csv", "pdf", "docx", "kindle"]
  },
  enterprise: {
    monthly_cards: -1, // unlimited
    monthly_ai_requests: -1,
    max_sets: -1,
    visual_cards: true,
    document_upload: true,
    supported_languages: -1,
    export_formats: ["csv", "pdf", "docx", "kindle", "custom"]
  }
};

export default function SubscriptionGate({ 
  feature, 
  children, 
  fallbackComponent = null,
  showUpgradePrompt = true 
}) {
  const [subscription, setSubscription] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadSubscription();
  }, []);

  const loadSubscription = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      const userSubs = await Subscription.filter({ user_id: user.id });
      if (userSubs.length > 0) {
        setSubscription(userSubs[0]);
      } else {
        // Create default free subscription
        const freeSub = await Subscription.create({
          user_id: user.id,
          plan_type: "free",
          status: "active",
          start_date: new Date().toISOString().split('T')[0],
          monthly_cards_used: 0,
          monthly_ai_requests: 0,
          last_reset_date: new Date().toISOString().split('T')[0]
        });
        setSubscription(freeSub);
      }
    } catch (error) {
      console.error("Error loading subscription:", error);
    }
    setIsLoading(false);
  };

  const checkFeatureAccess = (feature) => {
    if (!subscription) return false;
    
    const planType = subscription.plan_type;
    const limits = PLAN_LIMITS[planType];
    
    if (!limits) return false;
    
    switch (feature) {
      case 'visual_cards':
        return limits.visual_cards;
      case 'document_upload':
        return limits.document_upload;
      case 'unlimited_sets':
        return limits.max_sets === -1;
      case 'premium_export':
        return limits.export_formats.includes('pdf') || limits.export_formats.includes('docx');
      case 'advanced_features':
        return planType !== 'free';
      default:
        return true;
    }
  };

  const checkUsageLimit = (limitType) => {
    if (!subscription) return false;
    
    const planType = subscription.plan_type;
    const limits = PLAN_LIMITS[planType];
    
    if (!limits) return false;
    
    switch (limitType) {
      case 'monthly_cards':
        return limits.monthly_cards === -1 || subscription.monthly_cards_used < limits.monthly_cards;
      case 'monthly_ai_requests':
        return limits.monthly_ai_requests === -1 || subscription.monthly_ai_requests < limits.monthly_ai_requests;
      default:
        return true;
    }
  };

  const getUsageInfo = (limitType) => {
    if (!subscription) return { used: 0, limit: 0 };
    
    const planType = subscription.plan_type;
    const limits = PLAN_LIMITS[planType];
    
    switch (limitType) {
      case 'monthly_cards':
        return {
          used: subscription.monthly_cards_used || 0,
          limit: limits.monthly_cards === -1 ? "Unlimited" : limits.monthly_cards
        };
      case 'monthly_ai_requests':
        return {
          used: subscription.monthly_ai_requests || 0,
          limit: limits.monthly_ai_requests === -1 ? "Unlimited" : limits.monthly_ai_requests
        };
      default:
        return { used: 0, limit: 0 };
    }
  };

  if (isLoading) {
    return <div className="animate-pulse bg-slate-200 rounded-lg h-32"></div>;
  }

  // Check if feature is accessible
  const hasAccess = checkFeatureAccess(feature);
  
  if (hasAccess) {
    return children;
  }

  // Show fallback or upgrade prompt
  if (fallbackComponent) {
    return fallbackComponent;
  }

  if (!showUpgradePrompt) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
      <CardHeader className="text-center pb-4">
        <div className="w-16 h-16 bg-gradient-to-r from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Crown className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-xl font-bold text-slate-900">
          Upgrade to Unlock This Feature
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center">
        <p className="text-slate-600 mb-6">
          {feature === 'visual_cards' && "Generate flashcards with AI-powered images to enhance your learning experience."}
          {feature === 'document_upload' && "Upload documents and automatically extract key information into flashcards."}
          {feature === 'unlimited_sets' && "Create unlimited flashcard sets to organize all your study materials."}
          {feature === 'premium_export' && "Export your flashcards to professional formats like PDF and Word documents."}
          {feature === 'advanced_features' && "Access advanced AI features and unlimited language support."}
        </p>
        <div className="flex gap-3 justify-center">
          <Link to={createPageUrl("Pricing")}>
            <Button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white">
              <Zap className="w-4 h-4 mr-2" />
              Upgrade Now
            </Button>
          </Link>
          <Button variant="outline">
            Learn More
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Hook for checking subscription status
export const useSubscription = () => {
  const [subscription, setSubscription] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSubscription();
  }, []);

  const loadSubscription = async () => {
    try {
      const user = await User.me();
      const userSubs = await Subscription.filter({ user_id: user.id });
      if (userSubs.length > 0) {
        setSubscription(userSubs[0]);
      }
    } catch (error) {
      console.error("Error loading subscription:", error);
    }
    setIsLoading(false);
  };

  const hasFeature = (feature) => {
    if (!subscription) return false;
    const planType = subscription.plan_type;
    const limits = PLAN_LIMITS[planType];
    return limits?.[feature] || false;
  };

  const getUsage = (limitType) => {
    if (!subscription) return { used: 0, limit: 0 };
    const planType = subscription.plan_type;
    const limits = PLAN_LIMITS[planType];
    
    switch (limitType) {
      case 'monthly_cards':
        return {
          used: subscription.monthly_cards_used || 0,
          limit: limits.monthly_cards === -1 ? "Unlimited" : limits.monthly_cards
        };
      default:
        return { used: 0, limit: 0 };
    }
  };

  return {
    subscription,
    isLoading,
    hasFeature,
    getUsage,
    planType: subscription?.plan_type || 'free',
    isActive: subscription?.status === 'active' || subscription?.status === 'trial'
  };
};