import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Loader2, Sparkles, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

/**
 * A component to protect routes based on authentication status and user roles.
 * @param {object} props
 * @param {React.ReactNode} props.children - The content to render if the user is authorized.
 * @param {string[]} [props.allowedRoles] - An array of roles allowed to access the route. If empty or undefined, only authentication is checked.
 */
export default function AuthGate({ children, allowedRoles = [] }) {
  const [authStatus, setAuthStatus] = useState("loading"); // 'loading', 'authorized', 'unauthenticated', 'unauthorized'
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const user = await User.me();
        if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
          setAuthStatus("unauthorized");
        } else {
          setAuthStatus("authorized");
        }
      } catch (error) {
        setAuthStatus("unauthenticated");
      }
    };
    checkAuth();
  }, [allowedRoles]);
  
  const handleLogin = async () => {
      await User.login();
  }

  if (authStatus === "loading") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Sparkles className="w-8 h-8 text-white animate-pulse" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Academy.io</h2>
          <p className="text-slate-600">Verifying your access...</p>
          <Loader2 className="w-6 h-6 animate-spin mx-auto mt-4 text-indigo-600" />
        </div>
      </div>
    );
  }

  if (authStatus === "unauthenticated") {
    return (
       <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-6">
        <div className="text-center bg-white p-10 rounded-2xl shadow-xl max-w-md w-full">
           <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Authentication Required</h2>
          <p className="text-slate-600 mb-6">You must be logged in to view this page. Please sign in to continue.</p>
          <Button onClick={handleLogin} className="w-full bg-gradient-to-r from-indigo-600 to-purple-600">
              Sign In
          </Button>
        </div>
      </div>
    );
  }
  
  if (authStatus === "unauthorized") {
       return (
       <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-6">
        <div className="text-center bg-white p-10 rounded-2xl shadow-xl max-w-md w-full">
           <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h2>
          <p className="text-slate-600 mb-6">You do not have the necessary permissions to view this page.</p>
          <Button onClick={() => navigate(createPageUrl('Home'))} variant="outline" className="w-full">
              Go to Homepage
          </Button>
        </div>
      </div>
    );
  }

  return children;
}