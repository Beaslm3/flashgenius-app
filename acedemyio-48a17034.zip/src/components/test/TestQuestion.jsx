import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function TestQuestion({ question, userAnswer, onAnswerChange }) {
  if (!question) return null;

  const renderQuestionType = () => {
    switch (question.type) {
      case "mcq":
        return (
          <RadioGroup value={userAnswer} onValueChange={(value) => onAnswerChange(question.id, value)} className="space-y-2">
            {question.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-slate-50">
                <RadioGroupItem value={option} id={`q-${question.id}-opt-${index}`} />
                <Label htmlFor={`q-${question.id}-opt-${index}`} className="flex-1 cursor-pointer">{option}</Label>
              </div>
            ))}
          </RadioGroup>
        );
      case "tf":
        return (
          <RadioGroup value={userAnswer} onValueChange={(value) => onAnswerChange(question.id, value)} className="space-y-2">
            <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-slate-50">
              <RadioGroupItem value="True" id={`q-${question.id}-true`} />
              <Label htmlFor={`q-${question.id}-true`} className="flex-1 cursor-pointer">True</Label>
            </div>
            <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-slate-50">
              <RadioGroupItem value="False" id={`q-${question.id}-false`} />
              <Label htmlFor={`q-${question.id}-false`} className="flex-1 cursor-pointer">False</Label>
            </div>
          </RadioGroup>
        );
      case "sa":
        return (
          <div>
            <Label htmlFor={`q-${question.id}-answer`}>Your Answer</Label>
            <Input
              id={`q-${question.id}-answer`}
              value={userAnswer}
              onChange={(e) => onAnswerChange(question.id, e.target.value)}
              placeholder="Type your short answer here..."
            />
          </div>
        );
      default:
        return <p>Unsupported question type.</p>;
    }
  };

  return (
    <Card className="shadow-xl">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-slate-800">{question.question}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {renderQuestionType()}
      </CardContent>
    </Card>
  );
}