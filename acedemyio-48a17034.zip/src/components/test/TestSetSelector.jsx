import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ClipboardCheck, Clock, Target, Mic, Type, List } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

const difficultyColors = {
  beginner: "bg-green-100 text-green-800 border-green-200",
  intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200",
  advanced: "bg-red-100 text-red-800 border-red-200"
};

export default function TestSetSelector({ flashcardSets, isLoading, onSelectSet, onBack }) {
  const [testMode, setTestMode] = useState("text");

  const handleStartTest = (set) => {
    onSelectSet(set, testMode);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <Card key={i} className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-8 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={onBack}
            className="bg-white/80 backdrop-blur-sm"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Select Test Subject</h1>
            <p className="text-slate-600 mt-1">Choose a flashcard set to test your knowledge</p>
          </div>
        </div>

        {/* Test Mode Selection */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-amber-500" />
              Test Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label>Test Mode</Label>
              <Select value={testMode} onValueChange={setTestMode}>
                <SelectTrigger className="w-64">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">
                    <div className="flex items-center gap-2">
                      <Type className="w-4 h-4" />
                      Text Input
                    </div>
                  </SelectItem>
                  <SelectItem value="voice">
                    <div className="flex items-center gap-2">
                      <Mic className="w-4 h-4" />
                      Voice Input
                    </div>
                  </SelectItem>
                  <SelectItem value="multiple-choice">
                    <div className="flex items-center gap-2">
                      <List className="w-4 h-4" />
                      Multiple Choice
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-slate-500">
                {testMode === "text" && "Type your answers manually"}
                {testMode === "voice" && "Use voice recognition for answers (with text backup)"}
                {testMode === "multiple-choice" && "Select from multiple choice options"}
              </p>
            </div>
          </CardContent>
        </Card>

        {flashcardSets.length === 0 ? (
          <Card className="bg-white/80 backdrop-blur-sm text-center p-12">
            <ClipboardCheck className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">No Tests Available</h3>
            <p className="text-slate-500 mb-6">Create some flashcard sets first to take tests!</p>
            <Button onClick={onBack} className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
              Go Back to Dashboard
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {flashcardSets.map((set, index) => (
              <motion.div
                key={set.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg font-bold text-slate-900 line-clamp-2">
                      {set.title}
                    </CardTitle>
                    <p className="text-slate-600 font-medium">{set.subject}</p>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-slate-500 mb-4 line-clamp-2">
                      {set.description}
                    </p>
                    <div className="flex items-center justify-between mb-4">
                      <Badge className={difficultyColors[set.difficulty]}>
                        {set.difficulty}
                      </Badge>
                      <div className="flex items-center gap-1 text-sm text-slate-500">
                        <Clock className="w-4 h-4" />
                        ~20 min
                      </div>
                    </div>
                    <Button
                      onClick={() => handleStartTest(set)}
                      className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white"
                    >
                      <Target className="w-4 h-4 mr-2" />
                      Start Test
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}