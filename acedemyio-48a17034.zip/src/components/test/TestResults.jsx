import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, RefreshCw } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function TestResults({ testResults, testMeta, onRetake }) {
  if (!testResults) return null;

  const { score, totalQuestions, correctCount, detailedResults } = testResults;
  const scoreColor = score >= 80 ? "text-green-600" : score >= 50 ? "text-yellow-600" : "text-red-600";

  return (
    <div className="p-8 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <Card className="shadow-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold">Test Complete!</CardTitle>
            <CardDescription>{testMeta.title}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="flex flex-col md:flex-row items-center justify-around gap-8 p-6 bg-slate-100 rounded-lg">
              <div className="text-center">
                <p className="text-lg font-medium text-slate-700">Your Score</p>
                <p className={`text-6xl font-bold ${scoreColor}`}>{score}%</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-medium text-slate-700">Correct Answers</p>
                <p className="text-4xl font-bold text-slate-800">{correctCount} / {totalQuestions}</p>
                <Progress value={score} className="w-48 mt-2" />
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Detailed Review</h3>
              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                {detailedResults.map((result, index) => (
                  <Card key={index} className={result.isCorrect ? "border-green-200" : "border-red-200"}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        {result.isCorrect ? (
                          <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                        ) : (
                          <XCircle className="w-6 h-6 text-red-600 mt-1 flex-shrink-0" />
                        )}
                        <div>
                          <p className="font-semibold text-slate-800">{result.question}</p>
                          <p className="text-sm mt-2">Your answer: <span className={result.isCorrect ? "text-green-700" : "text-red-700"}>{result.userAnswer || "No answer"}</span></p>
                          {!result.isCorrect && (
                            <p className="text-sm mt-1">Correct answer: <span className="text-green-700">{result.answer}</span></p>
                          )}
                           {result.type === 'sa' && result.feedback && <p className="text-sm mt-2 p-2 bg-blue-50 border border-blue-200 rounded-lg"><strong>AI Feedback:</strong> {result.feedback}</p>}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="text-center">
              <Button onClick={onRetake} size="lg"><RefreshCw className="w-4 h-4 mr-2" />Retake Test</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}