
import React, { useState, useEffect } from 'react';
import { User, Course, CourseEnrollment, Assignment } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Loader2, BookOpen, Clock, TrendingUp, PlayCircle, Edit } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from '@/components/ui/badge';


const CourseCard = ({ course, progress }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3 }}
  >
    <Card className="h-full flex flex-col group overflow-hidden">
      <div className="relative">
        <div className="aspect-video bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center">
            <PlayCircle className="w-12 h-12 text-indigo-600 opacity-70" />
        </div>
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300" />
      </div>
      <CardHeader>
        <CardTitle className="line-clamp-2">{course.title}</CardTitle>
        <CardDescription>{course.subject}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col justify-end">
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1 text-sm text-muted-foreground">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        <Link to={createPageUrl(`CourseViewer?id=${course.id}`)}>
          <Button className="w-full">
            <PlayCircle className="w-4 h-4 mr-2" />
            Continue Learning
          </Button>
        </Link>
      </CardContent>
    </Card>
  </motion.div>
);

export default function StudentDashboard() {
  const [user, setUser] = useState(null);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const enrollments = await CourseEnrollment.filter({ student_id: currentUser.id });
      
      if (enrollments.length > 0) {
        const courseIds = enrollments.map(e => e.course_id);
        const [courses, courseAssignments] = await Promise.all([
            Course.filter({ id: { $in: courseIds } }),
            Assignment.filter({ course_id: { $in: courseIds } })
        ]);
        
        const coursesWithProgress = courses.map(course => {
          const enrollment = enrollments.find(e => e.course_id === course.id);
          return { ...course, progress: enrollment?.progress || 0 };
        });
        
        setEnrolledCourses(coursesWithProgress);
        setAssignments(courseAssignments);
      } else {
        setEnrolledCourses([]);
        setAssignments([]);
      }
    } catch (e) {
      console.error("Failed to load student data:", e);
      setEnrolledCourses([]);
      setAssignments([]);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 space-y-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900">Welcome back, {user?.full_name?.split(' ')[0]}!</h1>
          <p className="text-lg text-muted-foreground mt-2">Ready to continue your learning journey?</p>
        </header>

        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold">My Courses</h2>
            <Link to={createPageUrl('Marketplace')}>
                <Button variant="outline">Browse New Courses</Button>
            </Link>
          </div>

          {enrolledCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {enrolledCourses.map(course => (
                <CourseCard key={course.id} course={course} progress={course.progress} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 border-2 border-dashed rounded-lg">
                <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No Courses Yet</h3>
                <p className="mt-1 text-sm text-gray-500">You haven't enrolled in any courses. Explore the marketplace to get started.</p>
                <div className="mt-6">
                    <Link to={createPageUrl('Marketplace')}>
                        <Button>
                            Explore Marketplace
                        </Button>
                    </Link>
                </div>
            </div>
          )}
        </section>

        <section>
            <h2 className="text-2xl font-semibold mb-4">Upcoming Assignments</h2>
            {assignments.length > 0 ? (
                <Card>
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Assignment</TableHead>
                                    <TableHead>Course</TableHead>
                                    <TableHead>Due Date</TableHead>
                                    <TableHead className="text-right">Status</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {assignments.map(assignment => {
                                    const courseTitle = enrolledCourses.find(c => c.id === assignment.course_id)?.title || 'N/A';
                                    return (
                                        <TableRow key={assignment.id}>
                                            <TableCell className="font-medium">{assignment.title}</TableCell>
                                            <TableCell>{courseTitle}</TableCell>
                                            <TableCell>{new Date(assignment.due_date).toLocaleDateString()}</TableCell>
                                            <TableCell className="text-right">
                                                {/* Placeholder status */}
                                                <Badge variant="outline">Not Started</Badge>
                                            </TableCell>
                                        </TableRow>
                                    )
                                })}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            ) : (
                <div className="text-center py-16 border-2 border-dashed rounded-lg">
                    <Edit className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-lg font-medium text-gray-900">No Assignments</h3>
                    <p className="mt-1 text-sm text-gray-500">You have no upcoming assignments. Great job!</p>
                </div>
            )}
        </section>
      </motion.div>
    </div>
  );
}
