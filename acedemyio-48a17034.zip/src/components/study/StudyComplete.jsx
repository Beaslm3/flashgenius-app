import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, RotateCcw, ArrowLeft, BookOpen, Download } from "lucide-react";
import { motion } from "framer-motion";

export default function StudyComplete({ studySession, flashcardSet, onRestart, onSelectNewSet, onBack }) {
  const accuracy = Math.round((studySession.correct / studySession.total) * 100);
  const grade = accuracy >= 90 ? "Excellent!" : accuracy >= 75 ? "Good Job!" : accuracy >= 60 ? "Keep Practicing!" : "Try Again!";
  const gradeColor = accuracy >= 90 ? "text-green-600" : accuracy >= 75 ? "text-blue-600" : accuracy >= 60 ? "text-amber-600" : "text-red-600";

  const handleExportResults = () => {
    const results = `Study Session Results
Set: ${flashcardSet.title}
Subject: ${flashcardSet.subject}
Total Cards: ${studySession.total}
Correct: ${studySession.correct}
Incorrect: ${studySession.incorrect}
Accuracy: ${accuracy}%
Grade: ${grade}`;

    const blob = new Blob([results], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${flashcardSet.title}_results.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-0">
            <CardHeader className="text-center pb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-3xl font-bold text-slate-900 mb-2">
                Study Complete!
              </CardTitle>
              <p className="text-slate-600">
                Great work on {flashcardSet.title}
              </p>
            </CardHeader>
            <CardContent className="pb-8">
              <div className="text-center mb-8">
                <div className={`text-4xl font-bold ${gradeColor} mb-2`}>
                  {accuracy}%
                </div>
                <div className={`text-xl font-semibold ${gradeColor}`}>
                  {grade}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-slate-900">{studySession.total}</div>
                  <div className="text-sm text-slate-600">Total Cards</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{studySession.correct}</div>
                  <div className="text-sm text-slate-600">Correct</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{studySession.incorrect}</div>
                  <div className="text-sm text-slate-600">Incorrect</div>
                </div>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={onRestart}
                  className="w-full gold-gradient shadow-lg hover:shadow-xl transition-all"
                  size="lg"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Study Again
                </Button>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <Button
                    onClick={onSelectNewSet}
                    variant="outline"
                    className="bg-white/80 backdrop-blur-sm"
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    New Set
                  </Button>
                  <Button
                    onClick={handleExportResults}
                    variant="outline"
                    className="bg-white/80 backdrop-blur-sm"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                  <Button
                    onClick={onBack}
                    variant="outline"
                    className="bg-white/80 backdrop-blur-sm"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}