
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RotateCcw, CheckCircle, XCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import FlashcardDisplay from "../flashcard/FlashcardDisplay";

const difficultyColors = {
  easy: "bg-green-100 text-green-800 border-green-200",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
  hard: "bg-red-100 text-red-800 border-red-200"
};

export default function FlashcardViewer({ flashcard, showAnswer, onRevealAnswer, onAnswerFeedback }) {
  if (!flashcard) return null;

  return (
    <div className="max-w-2xl mx-auto">
      <motion.div
        key={flashcard.id}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mb-8"
      >
        <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-0 min-h-96">
          <CardHeader className="text-center pb-4 border-b border-slate-200/50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-slate-700">
                {showAnswer ? "Answer" : "Question"}
              </CardTitle>
              <Badge className={difficultyColors[flashcard.difficulty]}>
                {flashcard.difficulty}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="text-center p-8">
            <div className="min-h-48 flex items-center justify-center">
              <AnimatePresence mode="wait">
                <FlashcardDisplay card={flashcard} showAnswer={showAnswer} />
              </AnimatePresence>
            </div>
            
            {!showAnswer ? (
              <Button
                onClick={onRevealAnswer}
                className="gold-gradient shadow-lg hover:shadow-xl transition-all"
                size="lg"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Show Answer
              </Button>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-slate-600 font-medium">How did you do?</p>
                <div className="flex gap-4 justify-center">
                  <Button
                    onClick={() => onAnswerFeedback(false)}
                    variant="outline"
                    className="border-red-200 text-red-700 hover:bg-red-50"
                    size="lg"
                  >
                    <XCircle className="w-5 h-5 mr-2" />
                    Incorrect
                  </Button>
                  <Button
                    onClick={() => onAnswerFeedback(true)}
                    className="bg-green-600 hover:bg-green-700 text-white"
                    size="lg"
                  >
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Correct
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
