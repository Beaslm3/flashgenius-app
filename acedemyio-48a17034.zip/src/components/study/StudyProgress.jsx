import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, XCircle, Target } from "lucide-react";

export default function StudyProgress({ currentCard, totalCards, correct, incorrect }) {
  const accuracy = correct + incorrect > 0 ? Math.round((correct / (correct + incorrect)) * 100) : 0;

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg mb-8">
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-slate-900">{currentCard}/{totalCards}</div>
            <div className="text-sm text-slate-600 flex items-center justify-center gap-1 mt-1">
              <Target className="w-4 h-4" />
              Progress
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{correct}</div>
            <div className="text-sm text-slate-600 flex items-center justify-center gap-1 mt-1">
              <CheckCircle className="w-4 h-4" />
              Correct
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{incorrect}</div>
            <div className="text-sm text-slate-600 flex items-center justify-center gap-1 mt-1">
              <XCircle className="w-4 h-4" />
              Incorrect
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-amber-600">{accuracy}%</div>
            <div className="text-sm text-slate-600 mt-1">Accuracy</div>
          </div>
        </div>
        
        <div className="mt-6">
          <div className="w-full bg-slate-200 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-amber-400 to-amber-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(currentCard / totalCards) * 100}%` }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}