import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, BookOpen, Brain, Clock, Star, Target } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

const difficultyColors = {
  beginner: "bg-green-100 text-green-800 border-green-200",
  intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200",
  advanced: "bg-red-100 text-red-800 border-red-200"
};

const subjectImages = {
  mathematics: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=200&fit=crop&crop=entropy',
  math: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=200&fit=crop&crop=entropy',
  science: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400&h=200&fit=crop&crop=entropy',
  biology: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&h=200&fit=crop&crop=entropy',
  chemistry: 'https://images.unsplash.com/photo-1554475901-4538ddfbccc2?w=400&h=200&fit=crop&crop=entropy',
  physics: 'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=400&h=200&fit=crop&crop=entropy',
  history: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=200&fit=crop&crop=entropy',
  geography: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400&h=200&fit=crop&crop=entropy',
  english: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=200&fit=crop&crop=entropy',
  literature: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=200&fit=crop&crop=entropy',
  coding: 'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=200&fit=crop&crop=entropy',
  programming: 'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=200&fit=crop&crop=entropy',
  art: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400&h=200&fit=crop&crop=entropy',
  music: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=200&fit=crop&crop=entropy',
  default: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=200&fit=crop&crop=entropy'
};

const getSubjectImage = (subject) => {
  const normalizedSubject = subject?.toLowerCase().replace(/\s+/g, '');
  return subjectImages[normalizedSubject] || subjectImages.default;
};

export default function StudySetSelector({ flashcardSets, isLoading, onSelectSet, onBack }) {
  const getSourceText = (sourceType) => {
    switch (sourceType) {
      case 'ai_generated':
        return 'AI Generated';
      case 'document_upload':
        return 'From Document';
      case 'image_query':
        return 'From Image';
      default:
        return 'Manual';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(9).fill(0).map((_, i) => (
              <Card key={i} className="h-80 bg-white/80 backdrop-blur-sm shadow-sm">
                <div className="h-40 bg-slate-200 rounded-t-lg animate-pulse"></div>
                <CardContent className="p-6 space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-10 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-6 mb-12">
          <Button
            variant="outline"
            size="icon"
            onClick={onBack}
            className="bg-white/80 backdrop-blur-sm shadow-sm hover:shadow-md transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-slate-900 mb-2">Choose Your Study Set</h1>
            <p className="text-lg text-slate-600">Select a flashcard set to begin your learning journey</p>
          </div>
        </div>

        {flashcardSets.length === 0 ? (
          <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0 text-center p-16 max-w-2xl mx-auto">
            <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <BookOpen className="w-12 h-12 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-slate-800 mb-4">No Study Sets Available</h3>
            <p className="text-slate-600 mb-8 text-lg leading-relaxed">
              Create your first flashcard set to start your learning adventure! Our AI-powered tools make it easy to generate professional study materials.
            </p>
            <Button onClick={onBack} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all">
              <BookOpen className="w-5 h-5 mr-2" />
              Create Your First Set
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {flashcardSets.map((set, index) => (
              <motion.div
                key={set.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex"
              >
                <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg hover:shadow-2xl transition-all duration-300 group cursor-pointer flex flex-col w-full hover:-translate-y-2">
                  <div className="relative h-40 rounded-t-lg overflow-hidden">
                    <img
                      src={set.cover_image_url || getSubjectImage(set.subject)}
                      alt={set.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
                    
                    {/* Floating badges */}
                    <div className="absolute top-3 left-3">
                      <Badge className={`${difficultyColors[set.difficulty]} border shadow-sm`}>
                        {set.difficulty}
                      </Badge>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-white/90 text-slate-700 border-0 shadow-sm">
                        {getSourceText(set.source_type)}
                      </Badge>
                    </div>
                    
                    {/* Subject overlay */}
                    <div className="absolute bottom-3 left-3">
                      <Badge className="bg-white/95 text-slate-800 border-0 shadow-sm backdrop-blur-sm">
                        {set.subject}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardContent className="p-6 flex-grow flex flex-col">
                    <div className="flex-grow">
                      <CardTitle className="text-xl font-bold text-slate-900 mb-3 line-clamp-2 leading-tight">
                        {set.title}
                      </CardTitle>
                      <p className="text-slate-600 text-sm mb-4 line-clamp-3 leading-relaxed">
                        {set.description || `Master ${set.subject} with this comprehensive study set designed to help you learn effectively.`}
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      {/* Study metrics */}
                      <div className="flex items-center justify-between text-sm text-slate-500">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>~15 min</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Target className="w-4 h-4" />
                          <span>85% avg</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4" />
                          <span>4.8</span>
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => onSelectSet(set)}
                        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all group-hover:scale-105"
                        size="lg"
                      >
                        <Brain className="w-5 h-5 mr-2" />
                        Start Studying
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}