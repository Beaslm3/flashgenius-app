import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, CheckCircle, RotateCcw } from "lucide-react";
import FlashcardDisplay from "./FlashcardDisplay"; // Updated import

export default function FlashcardPreview({ flashcardSet, flashcards, onBack, onComplete }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);

  const nextCard = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowAnswer(false);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setShowAnswer(false);
    }
  };

  const toggleAnswer = () => {
    setShowAnswer(prev => !prev);
  };
  
// ... keep existing code (handleExport) ...

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
// ... keep existing code (header) ...

        {/* Progress Bar */}
// ... keep existing code (progress bar) ...

        {/* Flashcard */}
        <div className="mb-8">
          <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-0 min-h-96">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-lg font-semibold text-slate-700">
                {showAnswer ? "Answer" : "Question"}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="min-h-48 flex items-center justify-center p-6">
                <FlashcardDisplay card={flashcards[currentIndex]} showAnswer={showAnswer} />
              </div>
              
              <Button
                onClick={toggleAnswer}
                variant="outline"
                className="mb-4"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                {showAnswer ? "Show Question" : "Show Answer"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Navigation */}
// ... keep existing code (navigation) ...
      </div>
    </div>
  );
}