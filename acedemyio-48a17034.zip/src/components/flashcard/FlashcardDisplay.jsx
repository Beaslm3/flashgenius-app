import React from 'react';
import { motion } from 'framer-motion';

export default function FlashcardDisplay({ card, showAnswer }) {
  if (!card) return null;

  const content = showAnswer ? card.answer : card.question;
  const imageUrl = showAnswer ? null : card.image_url;

  return (
    <motion.div
      key={showAnswer ? 'answer' : 'question'}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4 text-center"
    >
      {imageUrl && (
        <img 
          src={imageUrl} 
          alt="Question visual" 
          className="max-h-60 mx-auto rounded-lg shadow-md mb-6"
        />
      )}
      <p className="text-xl font-medium text-slate-900 leading-relaxed">
        {content}
      </p>
      {showAnswer && card.explanation && (
        <div className="text-sm text-slate-600 bg-slate-50 p-4 rounded-lg text-left">
          <strong className="text-slate-900">Explanation:</strong>
          <div className="mt-2">{card.explanation}</div>
        </div>
      )}
    </motion.div>
  );
}