import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, CheckCircle, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function FlashcardPreview({ flashcardSet, flashcards, onBack, onComplete }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);

  const nextCard = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowAnswer(false);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setShowAnswer(false);
    }
  };

  const toggleAnswer = () => {
    setShowAnswer(prev => !prev);
  };

  const handleExport = async () => {
    // Create CSV content with headers that Anki/Quizlet can understand
    const headers = 'Question,Answer,Explanation,Difficulty,Image URL\n';
    const csvContent = flashcards.map(card => 
      [
        `"${card.question.replace(/"/g, '""')}"`,
        `"${card.answer.replace(/"/g, '""')}"`,
        `"${(card.explanation || '').replace(/"/g, '""')}"`,
        card.difficulty,
        card.image_url || ''
      ].join(',')
    ).join('\n');

    const csv = headers + csvContent;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${flashcardSet.title.replace(/ /g, '_')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const currentCard = flashcards[currentIndex];

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={onBack} className="bg-white/80 backdrop-blur-sm"><ArrowLeft className="w-4 h-4" /></Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{flashcardSet.title}</h1>
              <p className="text-gray-600">{flashcards.length} cards created</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={handleExport} className="bg-white/80 backdrop-blur-sm"><Download className="w-4 h-4 mr-2" />Export CSV</Button>
            <Button onClick={onComplete} className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg"><CheckCircle className="w-4 h-4 mr-2" />Save & Finish</Button>
          </div>
        </header>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Card {currentIndex + 1} of {flashcards.length}</span>
            {currentCard?.difficulty && <Badge variant="outline" className="bg-white capitalize">{currentCard.difficulty}</Badge>}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-primary h-2.5 rounded-full transition-all duration-300" style={{ width: `${((currentIndex + 1) / flashcards.length) * 100}%` }}></div>
          </div>
        </div>

        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="relative mb-8 h-96"
        >
          <Card 
            className="bg-white shadow-xl border-0 h-full w-full flex flex-col items-center justify-center cursor-pointer p-6"
            onClick={toggleAnswer}
          >
            <AnimatePresence mode="wait">
              {!showAnswer ? (
                <motion.div
                  key="question"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="text-center space-y-4"
                >
                  {currentCard?.image_url && (
                    <img src={currentCard.image_url} alt="Flashcard visual" className="max-h-40 mx-auto rounded-lg shadow-md mb-4"/>
                  )}
                  <p className="text-xl font-semibold text-gray-800">{currentCard?.question}</p>
                </motion.div>
              ) : (
                <motion.div
                  key="answer"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="text-center space-y-4"
                >
                  <p className="text-xl font-semibold text-primary">{currentCard?.answer}</p>
                  {currentCard?.explanation && (
                    <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg border">
                      <strong>Explanation:</strong> {currentCard.explanation}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </Card>
        </motion.div>
        
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={prevCard} disabled={currentIndex === 0} className="bg-white">Previous</Button>
          <div className="flex gap-2">
            {flashcards.map((_, index) => (
              <button
                key={index}
                onClick={() => { setCurrentIndex(index); setShowAnswer(false); }}
                className={`w-2.5 h-2.5 rounded-full transition-all ${index === currentIndex ? "bg-primary scale-125" : "bg-gray-300 hover:bg-gray-400"}`}
                aria-label={`Go to card ${index + 1}`}
              />
            ))}
          </div>
          <Button variant="outline" onClick={nextCard} disabled={currentIndex === flashcards.length - 1} className="bg-white">Next</Button>
        </div>
      </div>
    </div>
  );
}