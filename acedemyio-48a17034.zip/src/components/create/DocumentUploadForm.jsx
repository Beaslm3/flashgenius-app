import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Upload, FileText, Loader2, File, ImageIcon, FileVideo, FileAudio } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const languages = [
  { code: "en", name: "English", flag: "🇺🇸", popular: true },
  { code: "es", name: "Español", flag: "🇪🇸", popular: true },
  { code: "fr", name: "Français", flag: "🇫🇷", popular: true },
  { code: "de", name: "Deutsch", flag: "🇩🇪", popular: true },
  { code: "it", name: "Italiano", flag: "🇮🇹", popular: true },
  { code: "pt", name: "Português", flag: "🇵🇹", popular: true },
  { code: "zh", name: "中文", flag: "🇨🇳", popular: true },
  { code: "ja", name: "日本語", flag: "🇯🇵", popular: true },
  { code: "ko", name: "한국어", flag: "🇰🇷", popular: true },
  { code: "ar", name: "العربية", flag: "🇸🇦", popular: true },
  { code: "ru", name: "Русский", flag: "🇷🇺" },
  { code: "hi", name: "हिन्दी", flag: "🇮🇳" },
  { code: "bn", name: "বাংলা", flag: "🇧🇩" },
  { code: "id", name: "Bahasa Indonesia", flag: "🇮🇩" },
  { code: "nl", name: "Nederlands", flag: "🇳🇱" },
  { code: "sv", name: "Svenska", flag: "🇸🇪" },
  { code: "tr", name: "Türkçe", flag: "🇹🇷" },
];

const getFileIcon = (fileName) => {
  if (!fileName) return <File className="w-8 h-8 text-gray-600" />;
  const extension = fileName.split('.').pop().toLowerCase();
  
  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension)) return <ImageIcon className="w-8 h-8 text-blue-600" />;
  if (['mp4', 'avi', 'mov', 'wmv', 'flv'].includes(extension)) return <FileVideo className="w-8 h-8 text-purple-600" />;
  if (['mp3', 'wav', 'aac', 'flac'].includes(extension)) return <FileAudio className="w-8 h-8 text-green-600" />;
  if (['pdf'].includes(extension)) return <FileText className="w-8 h-8 text-red-600" />;
  if (['doc', 'docx', 'txt', 'rtf'].includes(extension)) return <FileText className="w-8 h-8 text-blue-500" />;
  return <File className="w-8 h-8 text-gray-600" />;
};

export default function DocumentUploadForm({ onSubmit, isGenerating }) {
  const [formData, setFormData] = useState({
    file: null,
    subject: "",
    title: "",
    description: "",
    numQuestions: [15],
    difficulty: "intermediate",
    tags: [],
    language: "en"
  });
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
    else if (e.type === "dragleave") setDragActive(false);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFormData(prev => ({ ...prev, file: e.dataTransfer.files[0] }));
    }
  }, []);

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, file: e.target.files[0] }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      numQuestions: formData.numQuestions[0],
      tags: formData.tags.filter(tag => tag.trim())
    });
  };

  const handleTagsChange = (value) => {
    setFormData(prev => ({
      ...prev,
      tags: value.split(",").map(tag => tag.trim())
    }));
  };

  const popularLanguages = languages.filter(lang => lang.popular);
  const otherLanguages = languages.filter(lang => !lang.popular);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div
        className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
          dragActive 
            ? "border-primary bg-primary/10" 
            : "border-gray-300 hover:border-gray-400"
        }`}
        onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}
      >
        <input type="file" id="file-upload" onChange={handleFileSelect} className="hidden" />
        {formData.file ? (
          <div className="flex flex-col items-center justify-center gap-3">
            {getFileIcon(formData.file.name)}
            <div>
              <p className="font-medium text-gray-900">{formData.file.name}</p>
              <p className="text-sm text-gray-500">{(formData.file.size / 1024 / 1024).toFixed(2)} MB</p>
            </div>
            <label htmlFor="file-upload"><Button type="button" variant="link" size="sm" className="text-sm">Change file</Button></label>
          </div>
        ) : (
          <div>
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <label htmlFor="file-upload" className="cursor-pointer">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">
                <span className="text-primary">Click to upload</span> or drag and drop
              </h3>
            </label>
            <p className="text-gray-500 text-sm">PDF, DOCX, TXT, PNG, JPG, MP3, MP4, and more</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="subject-upload">Subject *</Label>
          <Input id="subject-upload" placeholder="e.g., Biology, History" value={formData.subject} onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))} required className="bg-gray-50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="language-upload">Language *</Label>
          <Select value={formData.language} onValueChange={(value) => setFormData(prev => ({ ...prev, language: value }))}>
            <SelectTrigger className="bg-gray-50"><SelectValue /></SelectTrigger>
            <SelectContent className="max-h-96">
              <div className="p-2 border-b">
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Popular Languages</p>
                {popularLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code} className="py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{lang.flag}</span><span className="font-medium">{lang.name}</span><Badge className="bg-primary/10 text-primary">Popular</Badge>
                    </div>
                  </SelectItem>
                ))}
              </div>
              <div className="p-2">
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">All Languages</p>
                {otherLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code} className="py-2">
                    <div className="flex items-center gap-3"><span className="text-lg">{lang.flag}</span><span>{lang.name}</span></div>
                  </SelectItem>
                ))}
              </div>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="space-y-2">
          <Label htmlFor="title-upload">Set Title</Label>
          <Input id="title-upload" placeholder="Leave blank to use filename" value={formData.title} onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))} className="bg-gray-50" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>Difficulty Level</Label>
          <Select value={formData.difficulty} onValueChange={(value) => setFormData(prev => ({ ...prev, difficulty: value }))}>
            <SelectTrigger className="bg-gray-50"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="beginner">Beginner</SelectItem>
              <SelectItem value="intermediate">Intermediate</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="tags-upload">Tags (comma-separated)</Label>
          <Input id="tags-upload" placeholder="e.g., exam prep, chapter 5" onChange={(e) => handleTagsChange(e.target.value)} className="bg-gray-50" />
        </div>
      </div>

      <div className="space-y-4">
        <Label>Number of Questions: <span className="font-bold">{formData.numQuestions[0]}</span></Label>
        <Slider value={formData.numQuestions} onValueChange={(value) => setFormData(prev => ({ ...prev, numQuestions: value }))} max={50} min={5} step={5} className="w-full" />
        <div className="flex justify-between text-sm text-gray-500">
          <span>5 questions</span>
          <span>50 questions</span>
        </div>
      </div>

      <Button type="submit" disabled={!formData.file || !formData.subject || isGenerating} className="w-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg hover:shadow-xl" size="lg">
        {isGenerating ? (
          <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Processing File...</>
        ) : (
          <><Upload className="w-5 h-5 mr-2" />Generate from File</>
        )}
      </Button>
    </form>
  );
}