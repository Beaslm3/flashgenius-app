import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Upload, FileText, Loader2, Image as ImageIcon, Camera } from "lucide-react";

export default function ImageQueryForm({ onSubmit, isGenerating }) {
  const [formData, setFormData] = useState({
    file: null,
    prompt: "",
    subject: "",
    title: "",
    numQuestions: [10],
    difficulty: "intermediate",
  });
  const [dragActive, setDragActive] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleFileChange = (file) => {
    if (file && file.type.startsWith("image/")) {
      setFormData(prev => ({ ...prev, file }));
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFileChange(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      numQuestions: formData.numQuestions[0],
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all ${
          dragActive 
            ? "border-amber-400 bg-amber-50" 
            : "border-slate-300 hover:border-slate-400"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input
          type="file"
          id="image-upload"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
        {imagePreview ? (
            <img src={imagePreview} alt="Preview" className="max-h-48 mx-auto rounded-lg shadow-md" />
        ) : (
          <div>
            <ImageIcon className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-700 mb-2">
              Upload Your Image
            </h3>
            <p className="text-slate-500 mb-4">
              Drag and drop or click to select
            </p>
            <label htmlFor="image-upload">
              <Button type="button" variant="outline" asChild>
                <span>Choose Image</span>
              </Button>
            </label>
          </div>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="prompt">Question or Prompt *</Label>
        <Textarea
          id="prompt"
          placeholder="e.g., 'Identify the different parts of this cell.' or 'Create questions about the historical context of this painting.'"
          value={formData.prompt}
          onChange={(e) => setFormData(prev => ({ ...prev, prompt: e.target.value }))}
          required
          className="bg-white/80 h-24"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="subject">Subject *</Label>
          <Input
            id="subject"
            placeholder="e.g., Anatomy, Art History"
            value={formData.subject}
            onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
            required
            className="bg-white/80"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="title">Set Title (Optional)</Label>
          <Input
            id="title"
            placeholder="Leave blank for auto-generation"
            value={formData.title}
            onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
            className="bg-white/80"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>Difficulty Level</Label>
          <Select
            value={formData.difficulty}
            onValueChange={(value) => setFormData(prev => ({ ...prev, difficulty: value }))}
          >
            <SelectTrigger className="bg-white/80">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="beginner">Beginner</SelectItem>
              <SelectItem value="intermediate">Intermediate</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-4">
            <Label>Number of Questions: {formData.numQuestions[0]}</Label>
            <Slider
            value={formData.numQuestions}
            onValueChange={(value) => setFormData(prev => ({ ...prev, numQuestions: value }))}
            max={50}
            min={1}
            step={1}
            className="w-full"
            />
        </div>
      </div>

      <Button
        type="submit"
        disabled={!formData.file || !formData.prompt || !formData.subject || isGenerating}
        className="w-full gold-gradient text-white shadow-lg hover:shadow-xl transition-all"
        size="lg"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Analyzing Image...
          </>
        ) : (
          <>
            <Camera className="w-5 h-5 mr-2" />
            Generate from Image
          </>
        )}
      </Button>
    </form>
  );
}