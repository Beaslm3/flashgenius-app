import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Sparkles, Loader2, Image as ImageIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import SubscriptionGate from "../subscription/SubscriptionGate";

const languages = [
  // Most Popular Languages (Top 10)
  { code: "en", name: "English", flag: "🇺🇸", popular: true },
  { code: "es", name: "Español", flag: "🇪🇸", popular: true },
  { code: "fr", name: "Français", flag: "🇫🇷", popular: true },
  { code: "de", name: "Deutsch", flag: "🇩🇪", popular: true },
  { code: "it", name: "Italiano", flag: "🇮🇹", popular: true },
  { code: "pt", name: "Português", flag: "🇵🇹", popular: true },
  { code: "zh", name: "中文", flag: "🇨🇳", popular: true },
  { code: "ja", name: "日本語", flag: "🇯🇵", popular: true },
  { code: "ko", name: "한국어", flag: "🇰🇷", popular: true },
  { code: "ar", name: "العربية", flag: "🇸🇦", popular: true },
  
  // Other major languages
  { code: "ru", name: "Русский", flag: "🇷🇺" },
  { code: "hi", name: "हिन्दी", flag: "🇮🇳" },
  { code: "bn", name: "বাংলা", flag: "🇧🇩" },
  { code: "id", name: "Bahasa Indonesia", flag: "🇮🇩" },
  { code: "nl", name: "Nederlands", flag: "🇳🇱" },
  { code: "sv", name: "Svenska", flag: "🇸🇪" },
  { code: "tr", name: "Türkçe", flag: "🇹🇷" },
];

export default function AIGenerationForm({ onSubmit, isGenerating }) {
  const [formData, setFormData] = useState({
    subject: "",
    title: "",
    description: "",
    numQuestions: [10],
    difficulty: "intermediate",
    specificTopics: "",
    language: "en",
    tags: [],
    generateVisuals: false,
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      numQuestions: formData.numQuestions[0],
      tags: formData.tags.filter(tag => tag.trim())
    });
  };

  const handleTagsChange = (value) => {
    setFormData(prev => ({
      ...prev,
      tags: value.split(",").map(tag => tag.trim())
    }));
  };

  const popularLanguages = languages.filter(lang => lang.popular);
  const otherLanguages = languages.filter(lang => !lang.popular);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="subject">Subject *</Label>
          <Input
            id="subject"
            placeholder="e.g., Biology, History, Mathematics"
            value={formData.subject}
            onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
            required
            className="bg-gray-50"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="language">Language *</Label>
          <Select
            value={formData.language}
            onValueChange={(value) => setFormData(prev => ({ ...prev, language: value }))}
          >
            <SelectTrigger className="bg-gray-50">
              <SelectValue>
                {languages.find(lang => lang.code === formData.language) && (
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{languages.find(lang => lang.code === formData.language)?.flag}</span>
                    <span>{languages.find(lang => lang.code === formData.language)?.name}</span>
                  </div>
                )}
              </SelectValue>
            </SelectTrigger>
            <SelectContent className="max-h-96">
              <div className="p-2 border-b">
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Popular Languages</p>
                {popularLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code} className="py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{lang.flag}</span>
                      <span className="font-medium">{lang.name}</span>
                      <Badge className="bg-primary/10 text-primary">Popular</Badge>
                    </div>
                  </SelectItem>
                ))}
              </div>
              <div className="p-2">
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">All Languages</p>
                {otherLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code} className="py-2">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{lang.flag}</span>
                      <span>{lang.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </div>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title">Set Title</Label>
        <Input
          id="title"
          placeholder="Leave blank for auto-generation"
          value={formData.title}
          onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
          className="bg-gray-50"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="specificTopics">Specific Topics / Paste Text (Optional)</Label>
        <Textarea
          id="specificTopics"
          placeholder="For a history course on WWII, you could list specific battles, key figures, or political events. You can also paste text here directly."
          value={formData.specificTopics}
          onChange={(e) => setFormData(prev => ({ ...prev, specificTopics: e.target.value }))}
          className="bg-gray-50 h-24"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>Difficulty Level</Label>
          <Select
            value={formData.difficulty}
            onValueChange={(value) => setFormData(prev => ({ ...prev, difficulty: value }))}
          >
            <SelectTrigger className="bg-gray-50"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="beginner">Beginner</SelectItem>
              <SelectItem value="intermediate">Intermediate</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="tags">Tags (comma-separated)</Label>
          <Input
            id="tags"
            placeholder="e.g., exam prep, quick review"
            onChange={(e) => handleTagsChange(e.target.value)}
            className="bg-gray-50"
            value={formData.tags.join(", ")}
          />
        </div>
      </div>

      <div className="space-y-4">
        <Label>Number of Questions: <span className="font-bold">{formData.numQuestions[0]}</span></Label>
        <Slider
          value={formData.numQuestions}
          onValueChange={(value) => setFormData(prev => ({ ...prev, numQuestions: value }))}
          max={50}
          min={5}
          step={5}
          className="w-full"
        />
        <div className="flex justify-between text-sm text-gray-500">
          <span>5 questions</span>
          <span>50 questions</span>
        </div>
      </div>
      
      <SubscriptionGate feature="visual_cards">
        <div className="space-y-4 rounded-lg border border-gray-200 p-4 bg-gray-50">
          <div className="flex items-center justify-between">
            <Label htmlFor="visual-questions" className="flex items-center gap-2 font-semibold text-gray-800">
              <ImageIcon className="w-5 h-5 text-primary" />
              Generate Visual Questions
            </Label>
            <Switch
              id="visual-questions"
              checked={formData.generateVisuals}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, generateVisuals: checked }))}
            />
          </div>
          <p className="text-sm text-gray-600">
            Enhance your flashcards by generating relevant images for questions. Great for visual learners!
          </p>
        </div>
      </SubscriptionGate>

      <Button
        type="submit"
        disabled={!formData.subject || isGenerating}
        className="w-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg hover:shadow-xl transition-all"
        size="lg"
      >
        {isGenerating ? (
          <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Generating...</>
        ) : (
          <><Sparkles className="w-5 h-5 mr-2" />Generate Flashcards</>
        )}
      </Button>
    </form>
  );
}