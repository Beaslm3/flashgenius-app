import React, { useState } from "react";
import { FlashcardSet, Flashcard } from "@/api/entities";
import { InvokeLLM, UploadFile, ExtractDataFromUploadedFile, GenerateImage } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Sparkles, Upload, Loader2, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

import AIGenerationForm from "../components/create/AIGenerationForm";
import DocumentUploadForm from "../components/create/DocumentUploadForm";
import FlashcardPreview from "../components/create/FlashcardPreview";
import SubscriptionGate from "../components/subscription/SubscriptionGate";

const languages = [
  { code: "en", name: "English" }, { code: "es", name: "Español (Spanish)" }, { code: "fr", name: "Français (French)" }, { code: "de", name: "Deutsch (German)" }, { code: "it", name: "Italiano (Italian)" }, { code: "pt", name: "Português (Portuguese)" }, { code: "nl", name: "Nederlands (Dutch)" }, { code: "ru", name: "Русский (Russian)" }, { code: "sv", name: "Svenska (Swedish)" }, { code: "no", name: "Norsk (Norwegian)" }, { code: "da", name: "Dansk (Danish)" }, { code: "fi", name: "Suomi (Finnish)" }, { code: "is", name: "Íslenska (Icelandic)" }, { code: "pl", name: "Polski (Polish)" }, { code: "uk", name: "Українська (Ukrainian)" }, { code: "cs", name: "Čeština (Czech)" }, { code: "ro", name: "Română (Romanian)" }, { code: "hu", name: "Magyar (Hungarian)" }, { code: "el", name: "Ελληνικά (Greek)" }, { code: "hr", name: "Hrvatski (Croatian)" }, { code: "sr", name: "Српски (Serbian)" }, { code: "bg", name: "Български (Bulgarian)" }, { code: "zh", name: "中文 (Chinese)" }, { code: "ja", name: "日本語 (Japanese)" }, { code: "ko", name: "한국어 (Korean)" }, { code: "hi", name: "हिन्दी (Hindi)" }, { code: "bn", name: "বাংলা (Bengali)" }, { code: "ur", name: "اردو (Urdu)" }, { code: "id", name: "Bahasa Indonesia (Indonesian)" }, { code: "ms", name: "Bahasa Melayu (Malay)" }, { code: "vi", name: "Tiếng Việt (Vietnamese)" }, { code: "th", name: "ภาษาไทย (Thai)" }, { code: "tl", name: "Tagalog (Filipino)" }, { code: "ar", name: "العربية (Arabic)" }, { code: "he", name: "עברית (Hebrew)" }, { code: "tr", name: "Türkçe (Turkish)" }, { code: "fa", name: "فارسی (Persian)" }, { code: "sw", name: "Kiswahili (Swahili)" }, { code: "lt", name: "Lietuvių (Lithuanian)" }, { code: "lv", name: "Latviešu (Latvian)" }, { code: "et", name: "Eesti (Estonian)" }, { code: "ga", name: "Gaeilge (Irish)" }
];

export default function Create() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("ai");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCards, setGeneratedCards] = useState([]);
  const [currentSet, setCurrentSet] = useState(null);
  const [error, setError] = useState(null);

  const handleAIGeneration = async (formData) => {
    setIsGenerating(true);
    setError(null);
    try {
      const languageName = languages.find(lang => lang.code === formData.language)?.name || 'English';
      
      // The SubscriptionGate component will handle visual generation access control in the UI
      
      let llmPrompt;
      let responseSchema;

      if (formData.generateVisuals) {
        llmPrompt = `Create ${formData.numQuestions} flashcards for the subject "${formData.subject}" at a ${formData.difficulty} level.
        CRITICAL: The question, answer, and explanation MUST be written in ${languageName}. Do not use English unless the language selected is English.
        For each flashcard, provide a question, a concise answer, and a DETAILED, VIVID description for an AI image generator to create a relevant image for the question.
        The image description MUST be in English.
        ${formData.specificTopics ? `Focus on these topics: ${formData.specificTopics}` : ''}
        Example: For a question in Spanish "¿Qué parte de la célula es esta?", the image description (in English) could be "A detailed diagram of an animal cell, with an arrow pointing to the mitochondria, labels are blurred out."`;
        
        responseSchema = {
          type: "object",
          properties: {
            flashcards: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  answer: { type: "string" },
                  image_description: { type: "string", description: "A detailed prompt for an AI image generator." },
                  explanation: { type: "string" },
                  difficulty: { type: "string", enum: ["easy", "medium", "hard"] }
                },
                required: ["question", "answer", "image_description"]
              }
            }
          }
        };
      } else {
        llmPrompt = `Create ${formData.numQuestions} flashcards for the subject "${formData.subject}" at ${formData.difficulty} level. 
        CRITICAL: The question, answer, and explanation MUST be written in ${languageName}. Do not use English unless the language selected is English.
        ${formData.specificTopics ? `Focus on these topics: ${formData.specificTopics}` : ''}
        Ensure variety in question types (definitions, concepts, applications, examples).`;

        responseSchema = {
          type: "object",
          properties: {
            flashcards: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  answer: { type: "string" },
                  explanation: { type: "string" },
                  difficulty: { type: "string", enum: ["easy", "medium", "hard"] }
                },
                required: ["question", "answer"]
              }
            }
          }
        };
      }

      const llmResponse = await InvokeLLM({
        prompt: llmPrompt,
        response_json_schema: responseSchema
      });

      if (!llmResponse || !llmResponse.flashcards || !Array.isArray(llmResponse.flashcards)) {
        throw new Error("The AI returned an invalid response. Please try again.");
      }

      const validCards = llmResponse.flashcards.filter(
        c => c && c.question && c.answer && c.question.trim() && c.answer.trim()
      );

      if (validCards.length === 0) {
        throw new Error("The AI failed to generate any valid flashcards. Please adjust your topic or try again.");
      }

      const setData = {
        title: formData.title || `${formData.subject} Study Set`,
        subject: formData.subject,
        description: formData.description || `AI-generated flashcards for ${formData.subject}`,
        difficulty: formData.difficulty,
        tags: formData.tags || [],
        source_type: "ai_generated",
      };

      const newSet = await FlashcardSet.create(setData);
      setCurrentSet(newSet);

      const cardsToCreate = [];
      for (const [index, card] of validCards.entries()) {
        let imageUrl = null;
        if (formData.generateVisuals && card.image_description) {
          try {
            const imageResponse = await GenerateImage({ prompt: card.image_description });
            imageUrl = imageResponse.url;
          } catch (imgError) {
             console.error("Error generating image, skipping:", imgError);
          }
        }

        cardsToCreate.push({
          set_id: newSet.id,
          question: card.question,
          answer: card.answer,
          explanation: card.explanation || "",
          difficulty: card.difficulty || "medium",
          order_index: index,
          image_url: imageUrl,
        });
      }
      
      const createdFlashcards = await Flashcard.bulkCreate(cardsToCreate);
      setGeneratedCards(createdFlashcards);

    } catch (error) {
      console.error("Error generating flashcards:", error);
      setError("Failed to generate flashcards. The AI might be having trouble. Please try a different topic or adjust your request. Details: " + error.message);
    }
    setIsGenerating(false);
  };

  const handleDocumentUpload = async (formData) => {
    setIsGenerating(true);
    setError(null);
    try {
      const uploadResponse = await UploadFile({ file: formData.file });
      
      const extractResponse = await ExtractDataFromUploadedFile({
        file_url: uploadResponse.file_url,
        json_schema: {
          type: "object",
          properties: {
            content: { type: "string", description: "The extracted text content from the file." }
          }
        }
      });
      
      const languageName = languages.find(lang => lang.code === formData.language)?.name || 'English';

      if (extractResponse.status === "success" && extractResponse.output) {
        const response = await InvokeLLM({
          prompt: `Based on the following document content, create ${formData.numQuestions} flashcards:

          ${extractResponse.output.content.substring(0, 15000)}

          Create comprehensive questions that test understanding of key concepts in the document.
          Make sure the questions are at a ${formData.difficulty} level.
          CRITICAL: The question, answer, and explanation MUST be written in ${languageName}.`,
          response_json_schema: {
            type: "object",
            properties: {
              flashcards: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    question: { type: "string" },
                    answer: { type: "string" },
                    explanation: { type: "string" },
                    difficulty: { type: "string", enum: ["easy", "medium", "hard"] }
                  },
                  required: ["question", "answer"]
                }
              }
            }
          }
        });

        if (!response || !response.flashcards || !Array.isArray(response.flashcards)) {
          throw new Error("The AI returned an invalid response from the file. Please try again.");
        }

        const validCards = response.flashcards.filter(
          c => c && c.question && c.answer && c.question.trim() && c.answer.trim()
        );

        if (validCards.length === 0) {
          throw new Error("The AI failed to generate any valid flashcards from the file. Please try a different file.");
        }

        const setData = {
          title: formData.title || `${formData.file.name} Study Set`,
          subject: formData.subject,
          description: formData.description || `Flashcards generated from ${formData.file.name}`,
          difficulty: formData.difficulty,
          tags: formData.tags || [],
          source_type: "document_upload",
          source_file_url: uploadResponse.file_url,
        };

        const newSet = await FlashcardSet.create(setData);
        setCurrentSet(newSet);

        const cardsToCreate = validCards.map((card, index) => ({
          set_id: newSet.id,
          question: card.question,
          answer: card.answer,
          explanation: card.explanation || "",
          difficulty: card.difficulty || "medium",
          order_index: index
        }));

        const createdFlashcards = await Flashcard.bulkCreate(cardsToCreate);
        setGeneratedCards(createdFlashcards);
      } else {
        throw new Error(extractResponse.details || "Failed to process the uploaded file. The file might be corrupted or in an unsupported format.");
      }
    } catch (error) {
      console.error("Error processing document:", error);
      setError(`Error processing file: ${error.message}. Please try a different file or check the file format.`);
    }
    setIsGenerating(false);
  };
  
  if (generatedCards.length > 0 && currentSet) {
    return (
      <FlashcardPreview
        flashcardSet={currentSet}
        flashcards={generatedCards}
        onBack={() => {
          setGeneratedCards([]);
          setCurrentSet(null);
          setError(null);
          setActiveTab("ai");
        }}
        onComplete={() => navigate(createPageUrl("Dashboard"))}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-4 mb-8"
        >
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="bg-white/80 backdrop-blur-sm"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Flashcard Studio</h1>
            <p className="text-gray-600 mt-1">Generate powerful study materials with AI from text or files.</p>
          </div>
        </motion.div>

        {error && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Alert variant="destructive" className="mb-6 bg-red-50/80 border-red-200 text-red-800">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle className="font-bold">Generation Failed</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          </motion.div>
        )}

        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
          <CardHeader className="border-b border-slate-200/50">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Sparkles className="w-5 h-5 text-primary" />
              Choose Creation Method
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 p-1 rounded-lg">
                <TabsTrigger value="ai" className="data-[state=active]:bg-white data-[state=active]:shadow-md flex items-center gap-2 py-2">
                  <Sparkles className="w-4 h-4" />
                  AI Generation
                </TabsTrigger>
                <TabsTrigger value="upload" className="data-[state=active]:bg-white data-[state=active]:shadow-md flex items-center gap-2 py-2">
                  <Upload className="w-4 h-4" />
                  File Upload
                </TabsTrigger>
              </TabsList>

              <TabsContent value="ai">
                <AIGenerationForm
                  onSubmit={handleAIGeneration}
                  isGenerating={isGenerating}
                />
              </TabsContent>

              <TabsContent value="upload">
                <DocumentUploadForm
                  onSubmit={handleDocumentUpload}
                  isGenerating={isGenerating}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {isGenerating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
          >
            <Card className="bg-white p-8 text-center shadow-2xl">
              <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Creating Your Flashcards</h3>
              <p className="text-gray-600">The AI is hard at work. This may take a moment...</p>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}