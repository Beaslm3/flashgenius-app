import React, { useState, useEffect } from "react";
import { Blog, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function BlogAdmin() {
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkUserAndFetchPosts = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
        if (user.role !== 'admin') {
          navigate(createPageUrl('Home'));
          return;
        }
        const allPosts = await Blog.list('-created_date');
        setPosts(allPosts);
      } catch (e) {
        navigate(createPageUrl('Home'));
      } finally {
        setIsLoading(false);
      }
    };
    checkUserAndFetchPosts();
  }, [navigate]);

  const handleDelete = async (postId) => {
    if (window.confirm("Are you sure you want to delete this post?")) {
      try {
        await Blog.delete(postId);
        setPosts(posts.filter(p => p.id !== postId));
      } catch (error) {
        console.error("Failed to delete post:", error);
        alert("Could not delete post. Please try again.");
      }
    }
  };
  
  if (isLoading) {
    return <div className="p-6">Loading...</div>;
  }
  
  if (currentUser?.role !== 'admin') {
    return <div className="p-6">Access Denied.</div>;
  }

  return (
    <div className="p-6 md:p-10">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Blog Management</h1>
          <Button onClick={() => navigate(createPageUrl('EditBlogPost'))}>
            <Plus className="w-4 h-4 mr-2" />
            Create New Post
          </Button>
        </div>
        <Card className="shadow-lg border-0">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Author</TableHead>
                  <TableHead>Created Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {posts.map(post => (
                  <TableRow key={post.id}>
                    <TableCell className="font-medium">{post.title}</TableCell>
                    <TableCell>
                      <Badge variant={post.status === 'published' ? 'default' : 'secondary'} className={post.status === 'published' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
                        {post.status === 'published' ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
                        {post.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{post.author_name}</TableCell>
                    <TableCell>{new Date(post.created_date).toLocaleDateString()}</TableCell>
                    <TableCell className="flex gap-2">
                      <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl(`EditBlogPost?id=${post.id}`))}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="destructive" size="icon" onClick={() => handleDelete(post.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}