import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Create from "./Create";

import Export from "./Export";

import Test from "./Test";

import Edit from "./Edit";

import Home from "./Home";

import CodeExporter from "./CodeExporter";

import Pricing from "./Pricing";

import Summarizer from "./Summarizer";

import Referrals from "./Referrals";

import Calculator from "./Calculator";

import ManualCreate from "./ManualCreate";

import App from "./App";

import CreateAssignment from "./CreateAssignment";

import CourseViewer from "./CourseViewer";

import Profile from "./Profile";

import CourseEditor from "./CourseEditor";

import StudyPlanner from "./StudyPlanner";

import ProgressReports from "./ProgressReports";

import Blog from "./Blog";

import BlogPost from "./BlogPost";

import BlogAdmin from "./BlogAdmin";

import EditBlogPost from "./EditBlogPost";

import AdminSettings from "./AdminSettings";

import Contact from "./Contact";

import LearningPathway from "./LearningPathway";

import AIHub from "./AIHub";

import CourseBuilder from "./CourseBuilder";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Create: Create,
    
    Export: Export,
    
    Test: Test,
    
    Edit: Edit,
    
    Home: Home,
    
    CodeExporter: CodeExporter,
    
    Pricing: Pricing,
    
    Summarizer: Summarizer,
    
    Referrals: Referrals,
    
    Calculator: Calculator,
    
    ManualCreate: ManualCreate,
    
    App: App,
    
    CreateAssignment: CreateAssignment,
    
    CourseViewer: CourseViewer,
    
    Profile: Profile,
    
    CourseEditor: CourseEditor,
    
    StudyPlanner: StudyPlanner,
    
    ProgressReports: ProgressReports,
    
    Blog: Blog,
    
    BlogPost: BlogPost,
    
    BlogAdmin: BlogAdmin,
    
    EditBlogPost: EditBlogPost,
    
    AdminSettings: AdminSettings,
    
    Contact: Contact,
    
    LearningPathway: LearningPathway,
    
    AIHub: AIHub,
    
    CourseBuilder: CourseBuilder,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Create" element={<Create />} />
                
                <Route path="/Export" element={<Export />} />
                
                <Route path="/Test" element={<Test />} />
                
                <Route path="/Edit" element={<Edit />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/CodeExporter" element={<CodeExporter />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/Summarizer" element={<Summarizer />} />
                
                <Route path="/Referrals" element={<Referrals />} />
                
                <Route path="/Calculator" element={<Calculator />} />
                
                <Route path="/ManualCreate" element={<ManualCreate />} />
                
                <Route path="/App" element={<App />} />
                
                <Route path="/CreateAssignment" element={<CreateAssignment />} />
                
                <Route path="/CourseViewer" element={<CourseViewer />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/CourseEditor" element={<CourseEditor />} />
                
                <Route path="/StudyPlanner" element={<StudyPlanner />} />
                
                <Route path="/ProgressReports" element={<ProgressReports />} />
                
                <Route path="/Blog" element={<Blog />} />
                
                <Route path="/BlogPost" element={<BlogPost />} />
                
                <Route path="/BlogAdmin" element={<BlogAdmin />} />
                
                <Route path="/EditBlogPost" element={<EditBlogPost />} />
                
                <Route path="/AdminSettings" element={<AdminSettings />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/LearningPathway" element={<LearningPathway />} />
                
                <Route path="/AIHub" element={<AIHub />} />
                
                <Route path="/CourseBuilder" element={<CourseBuilder />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}