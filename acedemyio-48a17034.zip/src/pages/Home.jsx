import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, BookOpen, CheckCircle, Sparkles, Target, Wand2 } from 'lucide-react';
import { createPageUrl } from '@/utils';

const FeatureCard = ({ icon, title, description }) => {
  const Icon = icon;
  return (
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0">
        <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 text-primary">
          <Icon className="h-6 w-6" />
        </div>
      </div>
      <div>
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <p className="mt-1 text-gray-600">{description}</p>
      </div>
    </div>
  );
};

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <main className="isolate">
        <div className="relative pt-14">
          <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80" aria-hidden="true">
            <div
              className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#809fff] to-[#cdaaff] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
              style={{
                clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
              }}
            />
          </div>
          <div className="py-24 sm:py-32">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
              <div className="mx-auto max-w-2xl text-center">
                <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
                  Unlock Your Potential with AI-Powered Learning
                </h1>
                <p className="mt-6 text-lg leading-8 text-gray-600">
                  Acedemy.io provides intelligent tools to help you create courses, generate study materials, and master any subject faster than ever before.
                </p>
                <div className="mt-10 flex items-center justify-center gap-x-6">
                  <Button size="lg" onClick={() => navigate(createPageUrl('AIHub'))}>
                    Start Learning Now
                  </Button>
                  <Button size="lg" variant="link" onClick={() => navigate(createPageUrl('CourseBuilder'))}>
                    Explore Features <span aria-hidden="true">→</span>
                  </Button>
                </div>
              </div>
              <div className="mt-16 flow-root sm:mt-24">
                <div className="-m-2 rounded-xl bg-gray-900/5 p-2 ring-1 ring-inset ring-gray-900/10 lg:-m-4 lg:rounded-2xl lg:p-4">
                  <img
                    src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop"
                    alt="App screenshot"
                    width={2432}
                    height={1442}
                    className="rounded-md shadow-2xl ring-1 ring-gray-900/10"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="mx-auto mt-16 max-w-7xl px-6 sm:mt-32 lg:px-8">
          <div className="mx-auto max-w-2xl lg:text-center">
            <h2 className="text-base font-semibold leading-7 text-primary">Your Complete Learning Toolkit</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Everything you need to study and create
            </p>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              From instant answers to complete course creation, our AI tools are designed to streamline your educational journey.
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
            <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
              <FeatureCard 
                icon={Brain}
                title="AI Learning Center"
                description="Get instant, expert-level answers and explanations on any topic. Your personal AI tutor, available 24/7."
              />
              <FeatureCard 
                icon={Wand2}
                title="AI Course Builder"
                description="Describe a topic, and our AI will generate a complete, structured course with modules, lessons, and quizzes."
              />
              <FeatureCard 
                icon={Sparkles}
                title="Smart Flashcards & Quizzes"
                description="Automatically generate study sets and tests from any text, document, or topic to reinforce your learning."
              />
              <FeatureCard 
                icon={Target}
                title="Progress Tracking"
                description="Monitor your learning, identify strengths and weaknesses, and stay motivated with detailed progress reports."
              />
            </dl>
          </div>
        </div>

        {/* Call to Action Section */}
        <div className="relative isolate mt-32 px-6 py-24 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                    Ready to get started?
                </h2>
                <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-gray-600">
                    Jump into the AI Learning Center and experience the future of education today.
                </p>
                <div className="mt-10 flex items-center justify-center gap-x-6">
                    <Button size="lg" onClick={() => navigate(createPageUrl('AIHub'))}>
                        Go to AI Learning Center
                    </Button>
                </div>
            </div>
        </div>
      </main>
    </div>
  );
}