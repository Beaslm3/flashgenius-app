import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from '@/layout';

// Import Pages
import Home from './Home';
import Dashboard from './Dashboard';
import Create from './Create';
import Edit from './Edit';
import Study from './Study';
import Test from './Test';
import Pricing from './Pricing';
import Summarizer from './Summarizer';
import Referrals from './Referrals';
import Calculator from './Calculator';
import AIHub from './AIHub'; // Changed from UniversalHelper
import CourseViewer from './CourseViewer';
import Profile from './Profile';
import CourseBuilder from './CourseBuilder';
import CourseEditor from './CourseEditor';
import StudyPlanner from './StudyPlanner';
import ProgressReports from './ProgressReports';
import Blog from './Blog';
import BlogPost from './BlogPost';
import BlogAdmin from './BlogAdmin';
import EditBlogPost from './EditBlogPost';
import AdminSettings from './AdminSettings';
import Contact from './Contact';
import LearningPathway from './LearningPathway';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Home" element={<Home />} />
          <Route path="/Dashboard" element={<Dashboard />} />
          <Route path="/Create" element={<Create />} />
          <Route path="/Edit" element={<Edit />} />
          <Route path="/Study" element={<Study />} />
          <Route path="/Test" element={<Test />} />
          <Route path="/Pricing" element={<Pricing />} />
          <Route path="/Summarizer" element={<Summarizer />} />
          <Route path="/Referrals" element={<Referrals />} />
          <Route path="/Calculator" element={<Calculator />} />
          <Route path="/AIHub" element={<AIHub />} />
          <Route path="/CourseViewer" element={<CourseViewer />} />
          <Route path="/Profile" element={<Profile />} />
          <Route path="/CourseBuilder" element={<CourseBuilder />} />
          <Route path="/CourseEditor" element={<CourseEditor />} />
          <Route path="/StudyPlanner" element={<StudyPlanner />} />
          <Route path="/ProgressReports" element={<ProgressReports />} />
          <Route path="/Blog" element={<Blog />} />
          <Route path="/BlogPost" element={<BlogPost />} />
          <Route path="/BlogAdmin" element={<BlogAdmin />} />
          <Route path="/EditBlogPost" element={<EditBlogPost />} />
          <Route path="/AdminSettings" element={<AdminSettings />} />
          <Route path="/Contact" element={<Contact />} />
          <Route path="/LearningPathway" element={<LearningPathway />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;