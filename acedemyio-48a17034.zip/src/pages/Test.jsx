
import React, { useState, useEffect } from "react";
import { FlashcardSet, Flashcard, TestSession } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Clock, CheckCircle, AlertCircle, Trophy, Target, Sparkles, Loader2, FileText, Upload, Brain } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { InvokeLLM, UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { motion, AnimatePresence } from "framer-motion";
import TestQuestion from "../components/test/TestQuestion";
import TestResults from "../components/test/TestResults";

const GenerationScreen = ({ onGenerate, isGenerating }) => {
    const [sourceType, setSourceType] = useState("topic");
    const [file, setFile] = useState(null);
    const [topic, setTopic] = useState("");
    const [text, setText] = useState("");
    const [numQuestions, setNumQuestions] = useState(10);
    const [difficulty, setDifficulty] = useState("intermediate");

    const handleGenerateClick = () => {
        onGenerate({ sourceType, file, topic, text, numQuestions, difficulty });
    };

    return (
        <Card className="max-w-2xl mx-auto shadow-2xl">
            <CardHeader>
                <CardTitle className="flex items-center gap-3 text-2xl"><Sparkles className="w-6 h-6 text-primary" />AI Test Generator</CardTitle>
                <CardDescription>Create interactive quizzes from documents, topics, or text, inspired by Revisely.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Tabs value={sourceType} onValueChange={setSourceType}>
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="document">From Document</TabsTrigger>
                        <TabsTrigger value="topic">From Topic</TabsTrigger>
                        <TabsTrigger value="text">From Text</TabsTrigger>
                    </TabsList>
                    <TabsContent value="document" className="pt-4"><Label>Upload your study material (PDF, TXT)</Label><Input type="file" onChange={(e) => setFile(e.target.files[0])} accept=".pdf,.txt,.md" /></TabsContent>
                    <TabsContent value="topic" className="pt-4"><Label>Enter a topic</Label><Input placeholder="e.g., The American Revolution" value={topic} onChange={(e) => setTopic(e.target.value)} /></TabsContent>
                    <TabsContent value="text" className="pt-4"><Label>Paste your text</Label><Input placeholder="Paste your article or notes here..." value={text} onChange={(e) => setText(e.target.value)} /></TabsContent>
                </Tabs>
                <div className="grid grid-cols-2 gap-4">
                    <div><Label>Number of Questions</Label><Input type="number" value={numQuestions} onChange={(e) => setNumQuestions(Number(e.target.value))} min="5" max="25" /></div>
                    <div><Label>Difficulty</Label><Select value={difficulty} onValueChange={setDifficulty}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="easy">Easy</SelectItem><SelectItem value="intermediate">Intermediate</SelectItem><SelectItem value="hard">Hard</SelectItem></SelectContent></Select></div>
                </div>
                <Button onClick={handleGenerateClick} disabled={isGenerating} size="lg" className="w-full">{isGenerating ? <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Generating Test...</> : "Generate Test"}</Button>
            </CardContent>
        </Card>
    );
};

export default function TestPage() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    
    const [questions, setQuestions] = useState([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [userAnswers, setUserAnswers] = useState({});
    const [testState, setTestState] = useState("generate"); // generate, taking, completed
    const [testResults, setTestResults] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [error, setError] = useState(null);
    const [testMeta, setTestMeta] = useState({ title: "Practice Test" });

    const handleGenerateTest = async (options) => {
        setIsGenerating(true);
        setError(null);
        let content = "";
        let title = "Practice Test";

        try {
            if (options.sourceType === "topic") {
                if (!options.topic) throw new Error("Please provide a topic.");
                content = `Generate a test about ${options.topic}.`;
                title = `${options.topic} Test`;
            } else if (options.sourceType === "text") {
                if (!options.text) throw new Error("Please paste some text.");
                content = options.text;
                title = "Test from Text";
            } else if (options.sourceType === "document") {
                if (!options.file) throw new Error("Please upload a file.");
                const uploadRes = await UploadFile({ file: options.file });
                const extractRes = await ExtractDataFromUploadedFile({ file_url: uploadRes.file_url, json_schema: { type: "object", properties: { content: { type: "string" } } } });
                if (extractRes.status !== 'success' || !extractRes.output.content) throw new Error("Failed to extract content.");
                content = extractRes.output.content;
                title = `${options.file.name} Test`;
            }

            const prompt = `Based on the following content, generate a ${options.difficulty} level test with ${options.numQuestions} questions. Mix multiple-choice (mcq), true/false (tf), and short answer (sa) questions.
            For short answer questions, provide a concise, ideal answer.
            Content: """${content}"""`;
            
            const responseSchema = {
                type: "object",
                properties: {
                    questions: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                type: { type: "string", enum: ["mcq", "tf", "sa"] },
                                question: { type: "string" },
                                options: { type: "array", items: { type: "string" } },
                                answer: { type: "string" }
                            },
                            required: ["type", "question", "answer"]
                        }
                    }
                },
                required: ["questions"]
            };

            const response = await InvokeLLM({ prompt, response_json_schema: responseSchema });
            setQuestions(response.questions.map((q, i) => ({ ...q, id: `q-${i}` })));
            setTestMeta({ title });
            setTestState("taking");

        } catch (err) {
            setError(err.message || "Failed to generate test.");
        }
        setIsGenerating(false);
    };

    const handleAnswerChange = (questionId, answer) => setUserAnswers(prev => ({ ...prev, [questionId]: answer }));
    const nextQuestion = () => setCurrentQuestionIndex(prev => Math.min(prev + 1, questions.length - 1));
    const prevQuestion = () => setCurrentQuestionIndex(prev => Math.max(prev - 1, 0));

    const handleSubmitTest = async () => {
        let correctAnswers = 0;
        let detailedResults = [];

        for (const q of questions) {
            const userAnswer = userAnswers[q.id];
            let isCorrect = false;
            let feedback = "";

            if (!userAnswer) {
                isCorrect = false;
                feedback = "No answer provided.";
            } else if (q.type === 'sa') {
                const evalPrompt = `Evaluate this answer for a short-answer question.
                Question: "${q.question}"
                Ideal Answer: "${q.answer}"
                Student's Answer: "${userAnswer}"
                Is the student's answer correct or very close to the ideal answer?`;
                const evalResponse = await InvokeLLM({
                    prompt: evalPrompt,
                    response_json_schema: { type: "object", properties: { is_correct: { type: "boolean" }, feedback: { type: "string" } } }
                });
                isCorrect = evalResponse.is_correct;
                feedback = evalResponse.feedback;
            } else {
                isCorrect = userAnswer.toLowerCase().trim() === q.answer.toLowerCase().trim();
                feedback = isCorrect ? "Correct!" : `The correct answer is ${q.answer}.`;
            }
            if (isCorrect) correctAnswers++;
            detailedResults.push({ ...q, userAnswer, isCorrect, feedback });
        }

        setTestResults({
            score: Math.round((correctAnswers / questions.length) * 100),
            totalQuestions: questions.length,
            correctCount: correctAnswers,
            detailedResults
        });
        setTestState("completed");
    };

    if (testState === "generate") {
        return <div className="p-8 bg-slate-50 min-h-screen flex items-center justify-center"><GenerationScreen onGenerate={handleGenerateTest} isGenerating={isGenerating} /></div>;
    }
    
    if (testState === "completed") {
        return <TestResults testResults={testResults} testMeta={testMeta} onRetake={() => setTestState("generate")} />;
    }

    return (
        <div className="p-6 bg-slate-50 min-h-screen">
            <div className="max-w-4xl mx-auto">
                <div className="flex justify-between items-center mb-4">
                    <h1 className="text-2xl font-bold text-slate-900">{testMeta.title}</h1>
                    <p className="font-semibold">Question {currentQuestionIndex + 1} of {questions.length}</p>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2 mb-8"><div className="bg-primary h-2 rounded-full" style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}></div></div>

                <AnimatePresence mode="wait">
                    <motion.div key={currentQuestionIndex} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} transition={{ duration: 0.3 }}>
                        <TestQuestion
                            question={questions[currentQuestionIndex]}
                            userAnswer={userAnswers[questions[currentQuestionIndex]?.id] || ""}
                            onAnswerChange={handleAnswerChange}
                        />
                    </motion.div>
                </AnimatePresence>

                <div className="flex items-center justify-between mt-8">
                    <Button variant="outline" onClick={prevQuestion} disabled={currentQuestionIndex === 0}>Previous</Button>
                    {currentQuestionIndex === questions.length - 1 ? (
                        <Button onClick={handleSubmitTest}>Submit Test</Button>
                    ) : (
                        <Button onClick={nextQuestion}>Next</Button>
                    )}
                </div>
            </div>
        </div>
    );
}
