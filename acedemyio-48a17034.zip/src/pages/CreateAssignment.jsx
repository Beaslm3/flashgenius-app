import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ArrowLeft, PlusCircle, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User, Course, Assignment } from '@/api/entities';
import { UploadFile } from '@/api/integrations';

export default function CreateAssignment() {
    const navigate = useNavigate();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [selectedCourse, setSelectedCourse] = useState('');
    const [attachment, setAttachment] = useState(null);
    const [courses, setCourses] = useState([]);
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const loadData = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                const teacherCourses = await Course.filter({ created_by: currentUser.id });
                setCourses(teacherCourses);
            } catch (error) {
                console.error("Failed to load user and course data", error);
            }
        };
        loadData();
    }, []);

    const handleFileChange = (e) => {
        setAttachment(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!title || !selectedCourse || !dueDate || !user) {
            alert('Please fill out all required fields.');
            return;
        }

        setIsLoading(true);
        try {
            let fileUrl = '';
            if (attachment) {
                const uploadResponse = await UploadFile({ file: attachment });
                fileUrl = uploadResponse.file_url;
            }

            await Assignment.create({
                title,
                description,
                course_id: selectedCourse,
                due_date: new Date(dueDate).toISOString(),
                file_url: fileUrl,
                teacher_id: user.id
            });

            alert('Assignment created successfully!');
            navigate(createPageUrl('TeacherPortal'));

        } catch (error) {
            console.error('Failed to create assignment:', error);
            alert('An error occurred while creating the assignment.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-8">
                <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('TeacherPortal'))}>
                    <ArrowLeft className="w-4 h-4" />
                </Button>
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Create New Assignment</h1>
                    <p className="text-slate-600 mt-1">Design and distribute assignments to your students.</p>
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Assignment Details</CardTitle>
                    <CardDescription>Fill in the details below to create a new assignment.</CardDescription>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="title">Assignment Title *</Label>
                            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="course">Course *</Label>
                            <Select onValueChange={setSelectedCourse} required>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select a course" />
                                </SelectTrigger>
                                <SelectContent>
                                    {courses.map(course => (
                                        <SelectItem key={course.id} value={course.id}>{course.title}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="description">Description</Label>
                            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Provide instructions, context, or guidelines for the assignment." />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <Label htmlFor="due-date">Due Date *</Label>
                                <Input id="due-date" type="datetime-local" value={dueDate} onChange={(e) => setDueDate(e.target.value)} required />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="attachment">Attach File (Optional)</Label>
                                <Input id="attachment" type="file" onChange={handleFileChange} />
                            </div>
                        </div>

                        <div className="flex justify-end pt-4">
                            <Button type="submit" disabled={isLoading}>
                                {isLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Creating...
                                    </>
                                ) : (
                                    <>
                                        <PlusCircle className="mr-2 h-4 w-4" />
                                        Create Assignment
                                    </>
                                )}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}