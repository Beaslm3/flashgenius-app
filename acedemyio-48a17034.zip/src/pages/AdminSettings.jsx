import React, { useState, useEffect } from 'react';
import { PaymentMethod, ContactMessage, User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Plus, Trash2, Edit, Save, CreditCard, MessageSquare, KeyRound, Link as LinkIcon, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AdminSettings() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  
  // Payment methods state
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [newMethod, setNewMethod] = useState({ method_name: '', display_name: '', description: '', processing_fee: 0, is_active: true });
  const [isAddingMethod, setIsAddingMethod] = useState(false);
  
  // Stripe configuration state
  const [stripeConfig, setStripeConfig] = useState({ pro_link: '', premium_link: '' });
  const [stripeMethodId, setStripeMethodId] = useState(null);
  const [isSavingStripe, setIsSavingStripe] = useState(false);
  
  // Customer messages state
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const checkUserAndFetchData = async () => {
      try {
        const user = await User.me();
        if (user.role !== 'admin') {
          navigate(createPageUrl('Home'));
          return;
        }
        setCurrentUser(user);
        await Promise.all([
          loadPaymentMethods(),
          loadMessages()
        ]);
      } catch (e) {
        navigate(createPageUrl('Home'));
      } finally {
        setIsLoading(false);
      }
    };
    checkUserAndFetchData();
  }, [navigate]);

  const loadPaymentMethods = async () => {
    const methods = await PaymentMethod.list();
    setPaymentMethods(methods);
    
    // Find and load Stripe config
    const stripeMethod = methods.find(m => m.method_name === 'stripe');
    if (stripeMethod) {
      setStripeMethodId(stripeMethod.id);
      setStripeConfig(stripeMethod.configuration || { pro_link: '', premium_link: '' });
    }
  };

  const loadMessages = async () => {
    const msgs = await ContactMessage.list('-created_date');
    setMessages(msgs);
  };

  const handleAddMethod = async () => {
    if (!newMethod.method_name || !newMethod.display_name) {
      alert("Method Name and Display Name are required.");
      return;
    }
    setIsAddingMethod(true);
    await PaymentMethod.create(newMethod);
    setNewMethod({ method_name: '', display_name: '', description: '', processing_fee: 0, is_active: true });
    await loadPaymentMethods();
    setIsAddingMethod(false);
  };

  const handleDeleteMethod = async (id) => {
    if (window.confirm("Are you sure? This cannot be undone.")) {
      await PaymentMethod.delete(id);
      await loadPaymentMethods();
    }
  };

  const handleSaveStripeConfig = async () => {
    setIsSavingStripe(true);
    try {
      if (stripeMethodId) {
        // Update existing Stripe method
        await PaymentMethod.update(stripeMethodId, { configuration: stripeConfig });
      } else {
        // Create new Stripe method
        await PaymentMethod.create({
          method_name: 'stripe',
          display_name: 'Stripe (Credit/Debit Card)',
          is_active: true,
          configuration: stripeConfig
        });
      }
      alert("Stripe configuration saved!");
      await loadPaymentMethods();
    } catch(err) {
      alert("Failed to save Stripe configuration.");
      console.error(err);
    } finally {
      setIsSavingStripe(false);
    }
  };

  if (isLoading) return <div className="p-6"><Loader2 className="animate-spin" /> Loading...</div>;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Admin Settings</h1>
      
      <Tabs defaultValue="payments">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="payments">Payment Methods</TabsTrigger>
          <TabsTrigger value="stripe">Stripe Integration</TabsTrigger>
          <TabsTrigger value="messages">Customer Messages</TabsTrigger>
        </TabsList>
        
        <TabsContent value="payments" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Manage Payment Methods</CardTitle>
              <CardDescription>Add or remove payment options available to customers.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Add New Method Form */}
              <div className="border p-4 rounded-lg space-y-4">
                <h3 className="font-semibold flex items-center gap-2"><Plus />Add New Manual Payment Method</h3>
                 {/* ... Form inputs for newMethod ... */}
                 <Button onClick={handleAddMethod} disabled={isAddingMethod}>
                   {isAddingMethod ? <><Loader2 className="animate-spin mr-2"/>Adding...</> : "Add Payment Method"}
                 </Button>
              </div>
              
              {/* Current Methods List */}
              <div>
                <h3 className="font-semibold mb-2">Current Payment Methods</h3>
                <div className="space-y-2">
                  {paymentMethods.map(method => (
                    <div key={method.id} className="flex justify-between items-center p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-5 h-5"/>
                        <div>
                          <p className="font-medium">{method.display_name} ({method.method_name})</p>
                          <p className="text-sm text-gray-500">{method.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant={method.is_active ? "default" : "secondary"}>
                          {method.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                        <Button variant="destructive" size="icon" onClick={() => handleDeleteMethod(method.id)}>
                          <Trash2 className="w-4 h-4"/>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="stripe" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><KeyRound/>Stripe Configuration</CardTitle>
              <CardDescription>Connect Stripe payment links to your pricing tiers. These links are generated from your Stripe dashboard.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
               <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
                  <div className="flex">
                    <div className="py-1"><AlertCircle className="h-5 w-5 text-blue-700 mr-3" /></div>
                    <div>
                      <p className="font-bold text-blue-800">How this works</p>
                      <p className="text-sm text-blue-700">1. Create a "Payment Link" for each product in your Stripe account. <br/> 2. Copy the URL of the link. <br/> 3. Paste it into the corresponding field below and save.</p>
                    </div>
                  </div>
                </div>

              <div>
                <Label htmlFor="pro-link" className="flex items-center gap-1 font-semibold"><LinkIcon className="w-4 h-4" />Pro Tier Stripe Link</Label>
                <Input 
                  id="pro-link" 
                  value={stripeConfig.pro_link} 
                  onChange={(e) => setStripeConfig({...stripeConfig, pro_link: e.target.value})}
                  placeholder="https://buy.stripe.com/..."
                />
              </div>
              <div>
                <Label htmlFor="premium-link" className="flex items-center gap-1 font-semibold"><LinkIcon className="w-4 h-4" />Premium Tier Stripe Link</Label>
                <Input 
                  id="premium-link"
                  value={stripeConfig.premium_link} 
                  onChange={(e) => setStripeConfig({...stripeConfig, premium_link: e.target.value})}
                  placeholder="https://buy.stripe.com/..."
                />
              </div>
              <Button onClick={handleSaveStripeConfig} disabled={isSavingStripe}>
                {isSavingStripe ? <><Loader2 className="animate-spin mr-2"/>Saving...</> : <><Save className="w-4 h-4 mr-2"/>Save Stripe Configuration</>}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="messages" className="mt-6">
            {/* ... existing Customer Messages UI ... */}
        </TabsContent>
      </Tabs>
    </div>
  );
}