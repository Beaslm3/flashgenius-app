import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Course } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Save, Plus, Trash2, GripVertical, Eye, BookOpen, Clock, AlertTriangle, CheckCircle, BrainCircuit } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Label } from "@/components/ui/label";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import ReactMarkdown from 'react-markdown';

const ModuleEditor = ({ module, index, onUpdate, onDelete, onRegenerate }) => {
  const [isRegenerating, setIsRegenerating] = useState(false);

  const handleRegenerateClick = async (e) => {
    e.stopPropagation();
    setIsRegenerating(true);
    await onRegenerate(index);
    setIsRegenerating(false);
  };

  return (
    <AccordionItem value={module.id || `item-${index}`}>
      <AccordionTrigger className="hover:bg-gray-50 px-4 rounded-t-lg">
        <div className="flex items-center gap-4 w-full">
          <GripVertical className="h-5 w-5 text-gray-400 cursor-move flex-shrink-0" />
          <div className="flex-grow text-left">
            <p className="text-lg font-semibold">{module.module_title}</p>
            <p className="text-sm text-gray-500 font-normal">{module.module_description}</p>
          </div>
        </div>
      </AccordionTrigger>
      <AccordionContent className="border-t bg-white p-6 space-y-4">
          <div>
            <Label>Module Title</Label>
            <Input value={module.module_title} onChange={(e) => onUpdate(index, "module_title", e.target.value)} />
          </div>
          <div>
            <Label>Module Description</Label>
            <Textarea value={module.module_description} onChange={(e) => onUpdate(index, "module_description", e.target.value)} />
          </div>
          <div>
            <Label>Lesson Content (Markdown supported)</Label>
            <Textarea value={module.content || ""} onChange={(e) => onUpdate(index, "content", e.target.value)} rows={15} className="font-mono" />
          </div>
          <div className="flex items-center justify-between">
            <Button variant="destructive" size="sm" onClick={() => onDelete(index)}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Module
            </Button>
            <Button variant="outline" size="sm" onClick={handleRegenerateClick} disabled={isRegenerating}>
                {isRegenerating ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                    <BrainCircuit className="h-4 w-4 mr-2" />
                )}
              Regenerate Content
            </Button>
          </div>
      </AccordionContent>
    </AccordionItem>
  );
};

export default function CourseEditorPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const courseId = searchParams.get("id");

  const [course, setCourse] = useState(null);
  const [syllabus, setSyllabus] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("syllabus");
  const [showPublishConfirm, setShowPublishConfirm] = useState(false);

  useEffect(() => {
    if (!courseId) { navigate(createPageUrl("CourseBuilder")); return; }
    loadCourse();
  }, [courseId, navigate]);

  const loadCourse = async () => {
    setIsLoading(true);
    try {
      const fetchedCourse = await Course.get(courseId);
      setCourse(fetchedCourse);
      setSyllabus(fetchedCourse.syllabus || []);
    } catch (err) { setError("Failed to load course."); } 
    finally { setIsLoading(false); }
  };

  const handleSyllabusChange = (index, field, value) => {
    const updatedSyllabus = [...syllabus];
    updatedSyllabus[index][field] = value;
    setSyllabus(updatedSyllabus);
  };

  const addModule = () => {
    const newModule = { id: `module_${Date.now()}`, module_title: "New Module", module_description: "A new module description.", content: "# New Module Content" };
    setSyllabus([...syllabus, newModule]);
  };

  const deleteModule = (index) => {
    if (window.confirm("Are you sure you want to delete this module? This action cannot be undone.")) {
        setSyllabus(syllabus.filter((_, i) => i !== index));
    }
  };

  const regenerateModuleContent = async (index) => {
    const moduleToRegen = syllabus[index];
    try {
      const regeneratedContent = await InvokeLLM({
        prompt: `You are an expert instructional designer. Regenerate the lesson content for a module titled "${moduleToRegen.module_title}" with the description "${moduleToRegen.module_description}". The course is on "${course.subject}" for a ${course.level} audience. Produce detailed, high-quality content in Markdown format.`,
        response_json_schema: { type: "object", properties: { lesson_content: { type: "string" } } }
      });
      handleSyllabusChange(index, 'content', regeneratedContent.lesson_content);
    } catch(err) {
      alert("Failed to regenerate content. Please try again.");
    }
  };

  const handleSaveCourse = async (publish = false) => {
    setIsSaving(true);
    try {
      const status = publish ? 'published' : course.status || 'draft';
      await Course.update(courseId, { ...course, syllabus, status });
      alert(`Course ${status} successfully!`);
      if (publish) navigate(createPageUrl("Dashboard"));
    } catch (err) { setError("Failed to save course."); } 
    finally { setIsSaving(false); setShowPublishConfirm(false); }
  };

  if (isLoading) return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="flex h-screen items-center justify-center text-red-600">{error}</div>;

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Dashboard"))}><ArrowLeft className="h-4 w-4" /></Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900 truncate">{course?.title}</h1>
                <Badge variant={course?.status === 'published' ? 'default' : 'secondary'}>{course?.status || 'draft'}</Badge>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={() => navigate(createPageUrl(`CourseViewer?id=${courseId}`))}><Eye className="mr-2 h-4 w-4" />Preview</Button>
              <Button onClick={() => handleSaveCourse(false)} disabled={isSaving} variant="outline">{isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Save Draft</Button>
              <Button onClick={() => setShowPublishConfirm(true)} disabled={isSaving || course.status === 'published'}>{isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}Publish</Button>
            </div>
          </div>
        </div>
      </header>

      {showPublishConfirm && (
        <div className="fixed inset-0 bg-black/50 z-30 flex items-center justify-center p-4">
            <Card className="max-w-md">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><AlertTriangle className="text-yellow-500" />Confirm Publication</CardTitle>
                    <CardDescription>Are you sure you want to publish this course? Once published, it will be live and visible to students.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p>Please review your course settings and syllabus carefully before proceeding. This action cannot be easily undone.</p>
                </CardContent>
                <div className="p-6 pt-0 flex justify-end gap-3">
                    <Button variant="outline" onClick={() => setShowPublishConfirm(false)}>Cancel</Button>
                    <Button onClick={() => handleSaveCourse(true)}>Yes, Publish Course</Button>
                </div>
            </Card>
        </div>
      )}

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 grid w-full grid-cols-2">
            <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="syllabus">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Course Modules</CardTitle>
                  <CardDescription>Edit your AI-generated modules or create new ones.</CardDescription>
                </div>
                <Button onClick={addModule} variant="outline"><Plus className="mr-2 h-4 w-4" />Add Module</Button>
              </CardHeader>
              <CardContent>
                {syllabus.length > 0 ? (
                    <Accordion type="single" collapsible className="w-full">
                        {syllabus.map((module, index) => (
                          <ModuleEditor key={module.id || index} module={module} index={index} onUpdate={handleSyllabusChange} onDelete={deleteModule} onRegenerate={regenerateModuleContent} />
                        ))}
                    </Accordion>
                ) : <p className="text-center text-gray-500 py-8">No modules yet. Add one to get started.</p>}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader><CardTitle>Course Settings</CardTitle><CardDescription>Update general course information.</CardDescription></CardHeader>
              <CardContent className="space-y-4">
                <div><Label>Course Title</Label><Input value={course?.title || ""} onChange={(e) => setCourse({ ...course, title: e.target.value })} /></div>
                <div><Label>Course Description</Label><Textarea value={course?.meta_description || ""} onChange={(e) => setCourse({ ...course, meta_description: e.target.value })} /></div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div><Label>Subject</Label><Input value={course?.subject || ""} onChange={(e) => setCourse({ ...course, subject: e.target.value })} /></div>
                  <div><Label>Level</Label><Input value={course?.level || ""} onChange={(e) => setCourse({ ...course, level: e.target.value })} /></div>
                  <div><Label>Language</Label><Input value={course?.language || ""} onChange={(e) => setCourse({ ...course, language: e.target.value })} /></div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}