import React, { useState, useEffect } from "react";
import { User, Subscription, PaymentMethod } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Sparkles, Crown, Building, ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const pricingPlans = [
  {
    id: "free",
    name: "Free",
    price: "$0",
    period: "forever",
    description: "For individuals starting their learning journey with core AI tools.",
    features: [
      "AI Learning Center (Basic)",
      "Standard AI Flashcard Generation",
      "Standard AI Summarizer",
      "Standard AI Math Solver",
      "Community Support"
    ],
    cardClasses: "bg-white/80",
    icon: Star,
    iconBgColor: "bg-slate-100",
    iconColor: "text-slate-600"
  },
  {
    id: "pro",
    name: "Pro",
    price: "$12",
    period: "month",
    description: "For serious learners who need professional-grade AI tools.",
    popular: true,
    features: [
      "Everything in Free, plus:",
      "**Professional AI Course Builder**",
      "**Visual Flashcards (AI Images)**",
      "**Advanced AI Summarizer** (All Modes)",
      "**Advanced AI Math Tutor** (Graphing & Steps)",
      "**AI Progress Report Generator**",
      "Support for **50+ Languages**",
      "Export to PDF, CSV, & Word",
      "XP Points & Achievement System",
    ],
    cardClasses: "bg-white/90",
    icon: Sparkles,
    iconBgColor: "bg-blue-100",
    iconColor: "text-blue-600"
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: "Contact Us",
    period: "",
    description: "For institutions seeking custom deployments and support.",
    features: [
      "Everything in Pro, plus:",
      "Team Collaboration Tools",
      "Advanced Admin & Analytics Dashboard",
      "Single Sign-On (SSO) Integration",
      "Dedicated Account Manager",
      "On-Premise Deployment Options",
      "Priority Email & Chat Support",
    ],
    cardClasses: "bg-white/80",
    icon: Building,
    iconBgColor: "bg-emerald-100",
    iconColor: "text-emerald-600"
  }
];

const planPrices = {
    pro: 12.00,
    enterprise: 49.99 
};

export default function Pricing() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [stripeLinks, setStripeLinks] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPageData();
    window.scrollTo(0, 0);
  }, []);

  const loadPageData = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);

      const [userSubs, paymentMethods] = await Promise.all([
         Subscription.filter({ user_id: user.id }),
         PaymentMethod.filter({ method_name: 'stripe', is_active: true })
      ]);
      
      if (userSubs.length > 0) setSubscription(userSubs[0]);
      else setSubscription(null);

      if (paymentMethods.length > 0) setStripeLinks(paymentMethods[0].configuration || {});

    } catch (error) {
      console.log("User not logged in or error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpgrade = (planId) => {
    if (!currentUser) {
      alert("Please sign in to upgrade your plan.");
      return;
    }
    
    if (planId === 'enterprise') {
        navigate(createPageUrl('Contact'));
        return;
    }

    const stripeLink = stripeLinks[`${planId}_link`];
    if (stripeLink) window.location.href = stripeLink;
    else alert("Payment for this plan is not configured yet. Please contact support.");
  };
  
  const handlePayWithXP = async (planId) => {
    if (!currentUser) {
        alert("Please sign in to upgrade your plan.");
        return;
    }

    if (planId !== "pro") return;

    setIsLoading(true);

    try {
        const price = planPrices[planId];
        const xpCost = price * 100; // 100 XP = $1
        if (!price || (currentUser.total_xp_points || 0) < xpCost) {
            alert(`You need ${xpCost} XP points for this plan. You have ${currentUser.total_xp_points || 0} XP.`);
            setIsLoading(false);
            return;
        }

        await User.updateMyUserData({ 
            total_xp_points: (currentUser.total_xp_points || 0) - xpCost
        });

        const newSubscription = {
            user_id: currentUser.id, plan_type: planId, status: "active",
            start_date: new Date().toISOString().split('T')[0],
            end_date: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        };

        if (subscription) await Subscription.update(subscription.id, newSubscription);
        else await Subscription.create(newSubscription);

        alert(`Successfully subscribed to the ${pricingPlans.find(p => p.id === planId)?.name} plan!`);
        loadPageData();
    } catch (error) {
        console.error("Error upgrading subscription with XP:", error);
        alert("Failed to upgrade subscription with XP. Please try again.");
    } finally {
        setIsLoading(false);
    }
  };

  const getCurrentPlan = () => {
    if (!subscription) return "free";
    return subscription.plan_type;
  };

  const isCurrentPlan = (planId) => getCurrentPlan() === planId;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Dashboard"))} className="bg-white/80 backdrop-blur-sm"><ArrowLeft className="w-4 h-4" /></Button>
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold text-slate-900 mb-2">Simple, Transparent Pricing</h1>
            <p className="text-xl text-slate-600">Choose the plan that powers your learning goals</p>
          </div>
        </div>

        {currentUser && (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg mb-8">
                <CardContent className="p-6 grid md:grid-cols-2 gap-6 items-center">
                    <div>
                        <h3 className="font-semibold text-slate-900">Current Plan</h3>
                        <p className="text-slate-600">You're on the <strong>{pricingPlans.find(p => p.id === getCurrentPlan())?.name}</strong> plan.</p>
                    </div>
                    <div className="text-center">
                        <h3 className="font-semibold text-slate-900">Your XP Points Balance</h3>
                        <p className="text-3xl font-bold text-purple-600">{currentUser.total_xp_points || 0} XP</p>
                        <p className="text-xs text-slate-500">100 XP = $1 towards a Pro subscription</p>
                    </div>
                </CardContent>
            </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {pricingPlans.map((plan, index) => {
            const price = planPrices[plan.id];
            const xpCost = price ? price * 100 : 0;
            const canAffordXP = currentUser && xpCost && (currentUser.total_xp_points || 0) >= xpCost;

            return (
                <motion.div key={plan.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="relative h-full">
                {plan.popular && (<div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10"><div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-2 rounded-full shadow-lg"><div className="flex items-center gap-2"><Sparkles className="w-4 h-4" /><span className="font-semibold text-sm">Most Popular</span></div></div></div>)}
                <Card className={`shadow-lg hover:shadow-2xl transition-all duration-300 h-full flex flex-col ${plan.popular ? 'transform scale-105' : ''} ${plan.cardClasses} ${isCurrentPlan(plan.id) ? 'ring-2 ring-green-500 ring-opacity-50' : ''}`}>
                    <CardHeader className="text-center pb-4">
                        <div className={`w-16 h-16 ${plan.iconBgColor} rounded-2xl flex items-center justify-center mx-auto mb-4 ${plan.popular ? 'ring-2 ring-blue-200' : ''}`}><plan.icon className={`w-8 h-8 ${plan.iconColor}`} /></div>
                        <CardTitle className="text-2xl font-bold text-slate-900">{plan.name}</CardTitle>
                        <div className="text-4xl font-bold text-slate-900 mb-2">{plan.price}{plan.period && (<span className="text-lg font-normal text-slate-500">/{plan.period}</span>)}</div>
                        <p className="text-slate-600 text-sm h-12">{plan.description}</p>
                    </CardHeader>

                    <CardContent className="pt-0 flex-grow flex flex-col justify-between">
                    <ul className="space-y-3 mb-6">
                        {plan.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                              <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className={`text-slate-700 ${feature.includes('**') ? 'font-semibold text-blue-600' : ''}`}>{feature.replace(/\*\*/g, '')}</span>
                          </li>
                        ))}
                    </ul>
                    <div className="space-y-2">
                        {isCurrentPlan(plan.id) ? ( <Button disabled className="w-full bg-green-600 hover:bg-green-600">Current Plan</Button> ) : 
                         plan.id === 'free' ? ( <Button onClick={() => navigate(createPageUrl("Dashboard"))} className="w-full">Start Learning</Button> ) : 
                         ( <>
                            <Button onClick={() => handleUpgrade(plan.id)} disabled={isLoading || !currentUser} className={`w-full ${plan.popular ? 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700' : 'bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700'} text-white shadow-lg transition-all`}>
                                {plan.price === 'Contact Us' ? 'Contact Sales' : 'Upgrade Now'}
                            </Button>
                            {currentUser && xpCost > 0 && plan.id === 'pro' && (
                                <Button onClick={() => handlePayWithXP(plan.id)} disabled={isLoading || !canAffordXP} variant="outline" className="w-full border-purple-300 text-purple-700 hover:bg-purple-50">Pay with {xpCost} XP</Button>
                            )}
                           </>
                         )}
                    </div>
                    </CardContent>
                </Card>
                </motion.div>
            )
          })}
        </div>
        
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader><CardTitle className="text-2xl font-bold text-slate-900 text-center">Frequently Asked Questions</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div><h4 className="font-semibold text-slate-900 mb-2">Can I change my plan anytime?</h4><p className="text-slate-600 text-sm">Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.</p></div>
              <div><h4 className="font-semibold text-slate-900 mb-2">What happens to my data if I downgrade?</h4><p className="text-slate-600 text-sm">Your existing content remains accessible, but you may lose access to premium features like the AI Course Builder and Visual Flashcards.</p></div>
              <div><h4 className="font-semibold text-slate-900 mb-2">Do you offer refunds?</h4><p className="text-slate-600 text-sm">We offer a 7-day money-back guarantee for all paid plans. No questions asked.</p></div>
              <div><h4 className="font-semibold text-slate-900 mb-2">How do XP Points work?</h4><p className="text-slate-600 text-sm">Earn XP by completing learning pathways and achieving milestones. You can use your XP to pay for a Pro subscription.</p></div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}