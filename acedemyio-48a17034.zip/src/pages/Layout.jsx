
import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { BookOpen, Plus, Brain, ClipboardCheck, Calculator, FileText, Crown, Gift, LogIn, User as UserIcon, LogOut, Settings, LayoutDashboard, Sparkles, Target, Rss, Edit3, Wand2 } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import NiaAssistant from "@/components/ai/NiaAssistant";

const mainNav = [
  { title: "Home", url: createPageUrl("Home"), icon: Sparkles },
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { title: "AI Learning Center", url: createPageUrl("AIHub"), icon: Brain },
  { title: "Course Builder", url: createPageUrl("CourseBuilder"), icon: Wand2 },
  { title: "Flashcard Creator", url: createPageUrl("Create"), icon: Plus },
  { title: "Progress Reports", url: createPageUrl("ProgressReports"), icon: Target },
];

const aiToolsNav = [
  { title: "AI Summarizer", url: createPageUrl("Summarizer"), icon: FileText },
  { title: "AI Calculator", url: createPageUrl("Calculator"), icon: Calculator },
  { title: "Take a Test", url: createPageUrl("Test"), icon: ClipboardCheck },
];

const creatorToolsNav = [
  { title: "Course Editor", url: createPageUrl("CourseEditor"), icon: Edit3 },
];

const otherNav = [
  { title: "Refer & Earn", url: createPageUrl("Referrals"), icon: Gift },
  { title: "Pricing", url: createPageUrl("Pricing"), icon: Crown },
];

const adminNav = [
  { title: "Blog Admin", url: createPageUrl("BlogAdmin"), icon: Rss },
  { title: "Admin Settings", url: createPageUrl("AdminSettings"), icon: Settings },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (e) {
        setCurrentUser(null);
      }
    };
    fetchUser();
    
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const handleLogin = async () => {
    await User.login();
  };
  
  const handleLogout = async () => {
    await User.logout();
    sessionStorage.removeItem('hasRedirected');
    setCurrentUser(null);
    navigate(createPageUrl("Home"));
  };
  
  const isEditorPage = location.pathname.toLowerCase().startsWith('/courseeditor');
  if (isEditorPage) return <>{children}</>;

  const showSidebar = currentUser && !['/home', '/', '/blog', '/contact', '/pricing'].includes(location.pathname.toLowerCase()) && !location.pathname.toLowerCase().startsWith('/blogpost');

  const GlobalStyles = () => (
    <style>
      {`
        :root {
          --background: 0 0% 100%;
          --foreground: 224 71.4% 4.1%;
          --card: 0 0% 100%;
          --card-foreground: 224 71.4% 4.1%;
          --popover: 0 0% 100%;
          --popover-foreground: 224 71.4% 4.1%;
          --primary: 220 83.2% 53.3%;
          --primary-foreground: 210 20% 98%;
          --secondary: 220 14.3% 95.9%;
          --secondary-foreground: 220.9 39.3% 11%;
          --muted: 220 14.3% 95.9%;
          --muted-foreground: 220 8.9% 46.1%;
          --accent: 220 14.3% 95.9%;
          --accent-foreground: 220.9 39.3% 11%;
          --destructive: 0 84.2% 60.2%;
          --destructive-foreground: 210 20% 98%;
          --border: 220 13% 91%;
          --input: 220 13% 91%;
          --ring: 220 83.2% 53.3%;
          --radius: 0.5rem;
        }
        
        body {
          background-color: hsl(var(--background));
          color: hsl(var(--foreground));
        }

        .study-pattern {
          background-color: #F8F9FA;
        }
      `}
    </style>
  );

  const PublicHeader = () => (
    <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md border-b border-slate-200/60 z-50">
      <div className="max-w-7xl mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          <Link to={createPageUrl("Home")} className="flex items-center gap-3">
            <div className="w-9 h-9 bg-primary rounded-lg flex items-center justify-center shadow">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold text-slate-900">Acedemy.io</h1>
          </Link>
          
          <div className="hidden md:flex items-center gap-6">
            <Link to={createPageUrl("AIHub")} className="text-slate-600 hover:text-primary font-medium transition-colors">AI Tools</Link>
            <Link to={createPageUrl("CourseBuilder")} className="text-slate-600 hover:text-primary font-medium transition-colors">Courses</Link>
            <Link to={createPageUrl("Pricing")} className="text-slate-600 hover:text-primary font-medium transition-colors">Pricing</Link>
            <Link to={createPageUrl("Blog")} className="text-slate-600 hover:text-primary font-medium transition-colors">Blog</Link>
            <Link to={createPageUrl("Contact")} className="text-slate-600 hover:text-primary font-medium transition-colors">Contact</Link>
          </div>
          
          <div className="flex items-center gap-2">
            {currentUser ? (
              <>
                <Button variant="ghost" onClick={() => navigate(createPageUrl('Dashboard'))}>
                  Dashboard
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={currentUser.profile_picture_url} alt={currentUser.full_name} />
                        <AvatarFallback>{currentUser.full_name?.charAt(0)}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <p className="text-sm font-medium leading-none">{currentUser.full_name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{currentUser.email}</p>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onSelect={() => navigate(createPageUrl('Dashboard'))}><LayoutDashboard className="mr-2 h-4 w-4" /><span>Dashboard</span></DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => navigate(createPageUrl('Profile'))}><UserIcon className="mr-2 h-4 w-4" /><span>Profile</span></DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onSelect={handleLogout}><LogOut className="mr-2 h-4 w-4" /><span>Log out</span></DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Button variant="ghost" onClick={handleLogin}>Sign In</Button>
                <Button onClick={handleLogin}>Get Started</Button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );

  if (!showSidebar) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalStyles />
        <PublicHeader />
        <main className="pt-16">{children}</main>
        {currentUser && <NiaAssistant />}
      </div>
    );
  }

  const renderNavGroup = (items) => items.map((item) => (
    <SidebarMenuItem key={item.title}>
      <SidebarMenuButton 
        asChild 
        className={`hover:bg-accent transition-all duration-200 rounded-lg py-2 px-3 ${
          location.pathname === item.url.split('?')[0] ? 'bg-secondary text-primary font-semibold' : 'text-muted-foreground hover:text-foreground'
        }`}
      >
        <Link to={item.url} className="flex items-center gap-3">
          <item.icon className="w-5 h-5" />
          <span className="font-medium text-sm">{item.title}</span>
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  ));

  return (
    <SidebarProvider>
      <GlobalStyles />
      <div className="min-h-screen flex w-full bg-slate-50">
        <Sidebar className="border-r bg-card w-64">
          <SidebarHeader className="border-b p-4 h-16 flex items-center">
            <Link to={createPageUrl("Home")} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
              <div className="w-9 h-9 bg-primary rounded-lg flex items-center justify-center shadow">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <h2 className="font-bold text-lg text-foreground">Acedemy.io</h2>
            </Link>
          </SidebarHeader>
          
          <SidebarContent className="p-4 flex flex-col justify-between">
            <div className="space-y-4">
              <SidebarGroup>
                <SidebarMenu className="space-y-1">{renderNavGroup(mainNav)}</SidebarMenu>
              </SidebarGroup>
              <SidebarGroup>
                <SidebarGroupLabel>AI Tools</SidebarGroupLabel>
                <SidebarMenu className="space-y-1">{renderNavGroup(aiToolsNav)}</SidebarMenu>
              </SidebarGroup>
              <SidebarGroup>
                <SidebarGroupLabel>Creator Tools</SidebarGroupLabel>
                <SidebarMenu className="space-y-1">{renderNavGroup(creatorToolsNav)}</SidebarMenu>
              </SidebarGroup>
              <SidebarGroup>
                <SidebarGroupLabel>Other</SidebarGroupLabel>
                <SidebarMenu className="space-y-1">{renderNavGroup(otherNav)}</SidebarMenu>
              </SidebarGroup>
              {currentUser?.role === 'admin' && (
                <SidebarGroup>
                  <SidebarGroupLabel>Admin</SidebarGroupLabel>
                  <SidebarMenu className="space-y-1">{renderNavGroup(adminNav)}</SidebarMenu>
                </SidebarGroup>
              )}
            </div>
          </SidebarContent>

          <SidebarFooter className="border-t p-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full justify-start text-left h-auto p-2">
                  <div className="flex items-center gap-3 w-full">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={currentUser?.profile_picture_url} alt={currentUser?.full_name} />
                      <AvatarFallback>{currentUser?.full_name?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 truncate">
                      <p className="text-sm font-semibold truncate">{currentUser?.full_name}</p>
                      <p className="text-xs text-muted-foreground capitalize truncate">{currentUser?.email}</p>
                    </div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuItem onSelect={() => navigate(createPageUrl('Profile'))}><UserIcon className="mr-2 h-4 w-4" /><span>Profile</span></DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={handleLogout}><LogOut className="mr-2 h-4 w-4" /><span>Log out</span></DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-card border-b px-6 py-3 md:hidden h-16 flex items-center">
            <SidebarTrigger />
            <h1 className="text-xl font-bold text-foreground ml-4">Acedemy.io</h1>
          </header>
          <div className="flex-1 overflow-y-auto study-pattern">{children}</div>
        </main>
      </div>
      
      {/* Nia Assistant - Always Available */}
      <NiaAssistant />
    </SidebarProvider>
  );
}
