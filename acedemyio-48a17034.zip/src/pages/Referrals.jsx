
import React, { useState, useEffect } from "react";
import { User, Referral } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, Gift, UserPlus, CheckCircle, ArrowRight, Star } from "lucide-react";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { motion } from "framer-motion";

export default function Referrals() {
    const [currentUser, setCurrentUser] = useState(null);
    const [referralLink, setReferralLink] = useState("");
    const [referrals, setReferrals] = useState([]);
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        loadUserData();
    }, []);

    useEffect(() => {
        if (currentUser && referrals.length > 0) {
            processCompletedReferrals();
        }
    }, [currentUser, referrals]);

    const loadUserData = async () => {
        try {
            const user = await User.me();
            setCurrentUser(user);
            setReferralLink(`${window.location.origin}/signup?ref=${user.referral_code}`);
            
            const userReferrals = await Referral.filter({ referrer_id: user.id });
            setReferrals(userReferrals);
        } catch (error) {
            console.error("Error loading user data:", error);
        }
    };

    const processCompletedReferrals = async () => {
        const unprocessed = referrals.filter(r => r.status === 'completed' && !r.credit_awarded);
        if (unprocessed.length === 0) return;

        const creditsEarned = unprocessed.length * 50;
        const newTotal = (currentUser.credits || 0) + creditsEarned;

        await User.updateMyUserData({ credits: newTotal });

        for (const ref of unprocessed) {
            await Referral.update(ref.id, { credit_awarded: true });
        }
        
        alert(`Congratulations! You've earned ${creditsEarned} credits for ${unprocessed.length} successful referrals.`);
        loadUserData(); // To refresh data on page
    };

    const copyToClipboard = () => {
        navigator.clipboard.writeText(referralLink);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50 p-6">
            <div className="max-w-5xl mx-auto">
                <motion.div 
                    initial={{ opacity: 0, y: -30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-center mb-12"
                >
                    <div className="inline-block bg-gradient-to-r from-purple-600 to-indigo-600 p-4 rounded-full mb-4 shadow-lg">
                        <Gift className="w-10 h-10 text-white" />
                    </div>
                    <h1 className="text-5xl font-bold text-slate-900 mb-4">Refer & Earn Rewards</h1>
                    <p className="text-xl text-slate-600 max-w-2xl mx-auto">
                        Share the power of AI learning with your friends and get rewarded for every successful referral.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-3 gap-8 mb-12 text-center">
                    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                        <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg h-full">
                            <CardHeader>
                                <UserPlus className="w-10 h-10 mx-auto text-purple-600 mb-2" />
                                <CardTitle className="text-2xl">Share Your Link</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-600">Copy your unique referral link and share it with friends via email, social media, or text.</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                        <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg h-full">
                            <CardHeader>
                                <CheckCircle className="w-10 h-10 mx-auto text-indigo-600 mb-2" />
                                <CardTitle className="text-2xl">Friend Signs Up</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-600">Your friend signs up for Acedemy.io using your link and starts their learning journey.</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}>
                        <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg h-full">
                            <CardHeader>
                                <Star className="w-10 h-10 mx-auto text-amber-500 mb-2" />
                                <CardTitle className="text-2xl">You Get Rewarded</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-600">You receive 50 credits (worth $50) for each friend that signs up. Use credits to pay for your subscription.</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                <Card className="bg-white/80 backdrop-blur-md border-0 shadow-2xl overflow-hidden">
                    <div className="grid md:grid-cols-2">
                        <div className="p-8 md:p-12 flex flex-col justify-center">
                            <CardTitle className="text-3xl font-bold mb-4">Your Referral Link</CardTitle>
                            <CardDescription className="text-slate-600 mb-6">
                                Share this link to start earning. The more you share, the more rewards you can unlock!
                            </CardDescription>
                            <div className="flex gap-2">
                                <Input 
                                    value={referralLink} 
                                    readOnly 
                                    className="text-lg bg-slate-50 h-14" 
                                />
                                <Button onClick={copyToClipboard} size="lg" className="h-14 w-32 bg-indigo-600 hover:bg-indigo-700">
                                    {copied ? <CheckCircle className="w-5 h-5 mr-2" /> : <Copy className="w-5 h-5 mr-2" />}
                                    {copied ? "Copied!" : "Copy"}
                                </Button>
                            </div>
                            <div className="mt-8 flex gap-4">
                                <Button variant="outline" className="w-full">Share on Twitter</Button>
                                <Button variant="outline" className="w-full">Share on Facebook</Button>
                            </div>
                        </div>
                        <div className="bg-gradient-to-br from-purple-600 to-indigo-700 p-8 md:p-12 text-white flex flex-col justify-center items-center text-center">
                            <h3 className="text-2xl font-bold mb-2">Total Referrals</h3>
                            <p className="text-7xl font-extrabold mb-4">{referrals.length}</p>
                            <h3 className="text-2xl font-bold mb-2">Credits Earned</h3>
                            <p className="text-7xl font-extrabold text-amber-300">{currentUser?.credits || 0}</p>
                        </div>
                    </div>
                </Card>

                <div className="mt-12">
                    <h2 className="text-3xl font-bold text-center mb-6">Your Referral History</h2>
                    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                        <CardContent className="p-6">
                            {referrals.length > 0 ? (
                                <ul className="space-y-4">
                                    {referrals.map((referral) => (
                                        <li key={referral.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                                            <div>
                                                <p className="font-semibold text-slate-800">Referred User ID: {referral.referred_id.substring(0, 8)}...</p>
                                                <p className="text-sm text-slate-500">Date: {new Date(referral.created_date).toLocaleDateString()}</p>
                                            </div>
                                            <Badge variant={referral.status === "completed" ? "default" : "secondary"} className={`${referral.status === "completed" ? "bg-green-100 text-green-800" : ""}`}>
                                                {referral.status}
                                            </Badge>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-center text-slate-500 py-8">You haven't referred anyone yet. Start sharing your link!</p>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
