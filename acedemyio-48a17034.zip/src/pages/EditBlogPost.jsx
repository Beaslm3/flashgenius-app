import React, { useState, useEffect } from 'react';
import { Blog, User } from '@/api/entities';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { InvokeLLM, GenerateImage } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { ArrowLeft, Loader2, AlertCircle, Sparkles, Wand2, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const generateSlug = (title) => {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
};

export default function EditBlogPost() {
  const navigate = useNavigate();
  const location = useLocation();
  const [post, setPost] = useState({
    title: '',
    slug: '',
    content: '',
    cover_image_url: '',
    meta_description: '',
    seo_keywords: [],
    status: 'draft',
    author_name: '',
    author_profile_picture_url: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [error, setError] = useState(null);
  const [postId, setPostId] = useState(null);
  const [aiPrompt, setAiPrompt] = useState("");
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const id = searchParams.get('id');

    const initialize = async () => {
      try {
        const user = await User.me();
        if (user.role !== 'admin') {
          navigate(createPageUrl('Home'));
          return;
        }
        setPost(prev => ({ ...prev, author_name: user.full_name, author_profile_picture_url: user.profile_picture_url || '' }));

        if (id) {
          setPostId(id);
          const existingPost = await Blog.get(id);
          setPost(existingPost);
        }
      } catch (err) {
        setError('Failed to load data. You may not have permission to be here.');
        console.error(err);
      } finally {
        setIsPageLoading(false);
      }
    };

    initialize();
  }, [location.search, navigate]);

  const handleTitleChange = (e) => {
    const newTitle = e.target.value;
    setPost({ ...post, title: newTitle, slug: generateSlug(newTitle) });
  };

  const handleAiGenerate = async () => {
    if (!aiPrompt) return;
    setIsAiGenerating(true);
    setError(null);
    try {
      // First, generate the blog content
      const blogContentPrompt = `Generate a complete, professional blog post based on the following topic: "${aiPrompt}". 

      The blog post should be:
      - Well-researched and informative
      - SEO-optimized with proper structure
      - Engaging and professional in tone
      - At least 800-1200 words
      - Include practical examples and actionable insights
      - Use proper headings, subheadings, and formatting

      Your response must be a JSON object with the following structure:
      {
        "title": "A compelling, SEO-friendly title that includes primary keywords",
        "content": "The full blog post content in well-formatted Markdown. Include H2 and H3 headings, bullet points, numbered lists, and bold text where appropriate. Make it comprehensive and valuable.",
        "metaDescription": "A compelling meta description under 160 characters that encourages clicks from search results",
        "seoKeywords": ["primary-keyword", "secondary-keyword", "long-tail-keyword", "related-term", "topic-variant"],
        "imagePrompt": "A detailed, professional prompt for generating a high-quality blog cover image. Include style (modern, clean, professional), colors, composition, and specific visual elements that relate to the topic. Be very descriptive."
      }`;

      const responseSchema = {
        type: "object",
        properties: {
          title: { type: "string" },
          content: { type: "string" },
          metaDescription: { type: "string" },
          seoKeywords: { type: "array", items: { type: "string" } },
          imagePrompt: { type: "string" }
        },
        required: ["title", "content", "metaDescription", "seoKeywords", "imagePrompt"]
      };

      const blogData = await InvokeLLM({
        prompt: blogContentPrompt,
        response_json_schema: responseSchema,
        add_context_from_internet: true
      });

      if (!blogData) {
        throw new Error("AI failed to generate blog content or returned an invalid structure.");
      }

      // Generate the cover image
      let imageUrl = post.cover_image_url;
      if (blogData.imagePrompt) {
        try {
          const { url } = await GenerateImage({ 
            prompt: `Professional blog cover image: ${blogData.imagePrompt}. High quality, clean design, suitable for a professional blog post. 16:9 aspect ratio, modern and visually appealing.` 
          });
          imageUrl = url;
        } catch (imageError) {
          console.warn("Failed to generate image, using fallback:", imageError);
          // Use a professional fallback image
          imageUrl = 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80';
        }
      }

      setPost(prev => ({
        ...prev,
        title: blogData.title,
        slug: generateSlug(blogData.title),
        content: blogData.content,
        meta_description: blogData.metaDescription,
        seo_keywords: blogData.seoKeywords,
        cover_image_url: imageUrl,
      }));

    } catch (err) {
      setError(err.message || 'An error occurred during AI generation. Please try again.');
      console.error("AI Generation Error:", err);
    } finally {
      setIsAiGenerating(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      const dataToSave = {
        ...post,
        seo_keywords: Array.isArray(post.seo_keywords)
          ? post.seo_keywords
          : post.seo_keywords.split(',').map(k => k.trim()).filter(k => k.length > 0),
      };
      if (postId) {
        await Blog.update(postId, dataToSave);
      } else {
        await Blog.create(dataToSave);
      }
      navigate(createPageUrl('BlogAdmin'));
    } catch (err) {
      setError(err.message || 'An error occurred while saving the post.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePreview = () => {
    if (post.slug) {
      window.open(createPageUrl(`BlogPost?slug=${post.slug}`), '_blank');
    }
  };

  if (isPageLoading) {
    return <div className="p-6">Loading editor...</div>;
  }

  return (
    <div className="p-6 md:p-10 bg-gradient-to-br from-slate-50 to-indigo-50 min-h-screen">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('BlogAdmin'))}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">
            {postId ? 'Edit Blog Post' : 'Create New Blog Post'}
          </h1>
          {post.slug && (
            <Button variant="outline" onClick={handlePreview}>
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </Button>
          )}
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* AI Content Generation Card */}
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wand2 className="w-6 h-6 text-purple-500" />
                AI Blog Post Generator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="ai-prompt">Blog Topic</Label>
                <Textarea
                  id="ai-prompt"
                  placeholder="e.g., 'How AI is revolutionizing personalized education and adaptive learning'"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  className="h-24"
                />
                <p className="text-sm text-slate-500 mt-2">
                  Describe the topic you want to write about. The AI will create a complete article with SEO optimization and a professional cover image.
                </p>
              </div>
              <Button 
                type="button" 
                onClick={handleAiGenerate} 
                disabled={isAiGenerating || !aiPrompt}
                className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600"
              >
                {isAiGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Complete Article...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Blog Post & Image
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Basic Information */}
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader><CardTitle>Basic Information</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input id="title" value={post.title} onChange={handleTitleChange} required />
              </div>
              <div>
                <Label htmlFor="slug">URL Slug</Label>
                <Input id="slug" value={post.slug} onChange={(e) => setPost({ ...post, slug: e.target.value })} required />
                <p className="text-sm text-slate-500 mt-1">
                  Blog will be accessible at: /BlogPost?slug={post.slug}
                </p>
              </div>
              <div>
                <Label htmlFor="cover_image_url">Cover Image URL</Label>
                <Input id="cover_image_url" value={post.cover_image_url} onChange={(e) => setPost({ ...post, cover_image_url: e.target.value })} />
                {post.cover_image_url && (
                  <img src={post.cover_image_url} alt="Cover preview" className="mt-4 rounded-lg shadow-md max-w-sm h-auto object-cover" />
                )}
              </div>
            </CardContent>
          </Card>

          {/* Content */}
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader><CardTitle>Content</CardTitle></CardHeader>
            <CardContent>
              <ReactQuill 
                theme="snow" 
                value={post.content} 
                onChange={(content) => setPost({ ...post, content })} 
                className="bg-white h-96 mb-12" 
                modules={{
                  toolbar: [
                    [{ 'header': [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                    ['blockquote', 'code-block'],
                    ['link', 'image'],
                    ['clean']
                  ]
                }}
              />
            </CardContent>
          </Card>

          {/* SEO & Publishing */}
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader><CardTitle>SEO & Publishing</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="meta_description">Meta Description</Label>
                <Textarea 
                  id="meta_description" 
                  value={post.meta_description} 
                  onChange={(e) => setPost({ ...post, meta_description: e.target.value })} 
                  required 
                  maxLength={160}
                />
                <p className="text-sm text-slate-500 mt-1">
                  {post.meta_description.length}/160 characters
                </p>
              </div>
              <div>
                <Label htmlFor="seo_keywords">SEO Keywords (comma-separated)</Label>
                <Input 
                  id="seo_keywords" 
                  value={Array.isArray(post.seo_keywords) ? post.seo_keywords.join(', ') : post.seo_keywords} 
                  onChange={(e) => setPost({ ...post, seo_keywords: e.target.value })} 
                />
              </div>
              <div>
                <Label htmlFor="status">Publication Status</Label>
                <Select value={post.status} onValueChange={(value) => setPost({ ...post, status: value })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="author_name">Author Name</Label>
                <Input id="author_name" value={post.author_name} onChange={(e) => setPost({ ...post, author_name: e.target.value })} />
              </div>
            </CardContent>
          </Card>

          <Button 
            type="submit" 
            disabled={isLoading} 
            className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600" 
            size="lg"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Blog Post'
            )}
          </Button>
        </form>
      </motion.div>
    </div>
  );
}