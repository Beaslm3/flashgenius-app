import React, { useState, useEffect } from "react";
import { Course, FlashcardSet, Flashcard, User, CourseEnrollment } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  BookOpen, 
  Play, 
  Clock, 
  Users, 
  Award, 
  CheckCircle, 
  ArrowLeft, 
  Download,
  Share,
  Star,
  Target,
  Brain,
  FileText,
  ImageIcon,
  Loader2,
  ExternalLink,
  ChevronRight,
  ChevronDown,
  PlayCircle
} from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";

const LessonViewer = ({ lesson, onComplete }) => {
  const [showContent, setShowContent] = useState(false);

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader 
        className="cursor-pointer hover:bg-slate-50 transition-colors"
        onClick={() => setShowContent(!showContent)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
              <PlayCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">{lesson.title}</CardTitle>
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <Clock className="w-3 h-3" />
                {lesson.duration || "15 min"}
              </div>
            </div>
          </div>
          {showContent ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
        </div>
      </CardHeader>
      
      <AnimatePresence>
        {showContent && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            <CardContent className="pt-0">
              {lesson.generated_images?.length > 0 && (
                <div className="mb-4">
                  <img 
                    src={lesson.generated_images[0]} 
                    alt={lesson.title}
                    className="w-full h-48 object-cover rounded-lg shadow-md"
                  />
                </div>
              )}
              
              <div className="prose prose-slate max-w-none mb-6">
                <ReactMarkdown>{lesson.content}</ReactMarkdown>
              </div>
              
              {lesson.key_points?.length > 0 && (
                <div className="bg-slate-50 rounded-lg p-4 mb-4">
                  <h4 className="font-semibold text-slate-900 mb-2">Key Points</h4>
                  <ul className="space-y-1">
                    {lesson.key_points.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {lesson.speaker_notes && (
                <div className="bg-amber-50 rounded-lg p-4 mb-4">
                  <h4 className="font-semibold text-slate-900 mb-2">Instructor Notes</h4>
                  <p className="text-sm text-slate-700">{lesson.speaker_notes}</p>
                </div>
              )}
              
              <div className="flex justify-end">
                <Button onClick={() => onComplete(lesson.id)} className="bg-green-600 hover:bg-green-700">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark Complete
                </Button>
              </div>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
};

const ModuleViewer = ({ module, onTakeQuiz, onLessonComplete }) => {
  const [expandedLessons, setExpandedLessons] = useState({});

  const toggleLesson = (lessonId) => {
    setExpandedLessons(prev => ({
      ...prev,
      [lessonId]: !prev[lessonId]
    }));
  };

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-6">
        <h3 className="text-xl font-bold text-slate-900 mb-2">{module.module_title}</h3>
        <p className="text-slate-600 mb-4">{module.module_description}</p>
        <div className="flex items-center gap-4 text-sm text-slate-500">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {module.estimated_time || "1 hour"}
          </div>
          <div className="flex items-center gap-1">
            <BookOpen className="w-4 h-4" />
            {module.lessons?.length || 3} lessons
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {module.lessons?.map((lesson, idx) => (
          <LessonViewer
            key={lesson.id || idx}
            lesson={lesson}
            onComplete={onLessonComplete}
          />
        ))}
      </div>

      {module.quiz_id && (
        <div className="bg-white/80 backdrop-blur-sm rounded-lg p-4 border-2 border-dashed border-indigo-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-500 rounded-lg flex items-center justify-center">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-slate-900">Module Quiz</h4>
                <p className="text-sm text-slate-600">Test your understanding of this module</p>
              </div>
            </div>
            <Button onClick={() => onTakeQuiz(module.quiz_id)} className="bg-amber-600 hover:bg-amber-700">
              Take Quiz
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default function CourseViewerPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const courseId = searchParams.get('id');

  const [course, setCourse] = useState(null);
  const [enrollment, setEnrollment] = useState(null);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (!courseId) {
          setError("No course ID provided");
          return;
        }

        const courseData = await Course.get(courseId);
        setCourse(courseData);

        // Check if user is enrolled
        const enrollments = await CourseEnrollment.filter({
          course_id: courseId,
          student_id: currentUser.id
        });

        if (enrollments.length > 0) {
          setEnrollment(enrollments[0]);
        } else {
          // Auto-enroll for now
          const newEnrollment = await CourseEnrollment.create({
            course_id: courseId,
            student_id: currentUser.id,
            enrollment_date: new Date().toISOString(),
            progress: 0
          });
          setEnrollment(newEnrollment);
        }

      } catch (error) {
        console.error("Error fetching course:", error);
        setError("Failed to load course. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [courseId, navigate]);

  const handleTakeQuiz = (quizId) => {
    navigate(createPageUrl(`Test?set=${quizId}`));
  };

  const handleLessonComplete = async (lessonId) => {
    // Update progress
    if (enrollment) {
      const totalLessons = course.syllabus.reduce((acc, module) => acc + (module.lessons?.length || 0), 0);
      const newProgress = Math.min(100, enrollment.progress + (100 / totalLessons));
      
      try {
        await CourseEnrollment.update(enrollment.id, {
          progress: newProgress,
          last_accessed: new Date().toISOString()
        });
        
        setEnrollment(prev => ({
          ...prev,
          progress: newProgress,
          last_accessed: new Date().toISOString()
        }));
      } catch (error) {
        console.error("Error updating progress:", error);
      }
    }
  };

  const handleTakeFinalExam = () => {
    if (course.final_assessment_id) {
      navigate(createPageUrl(`Test?set=${course.final_assessment_id}`));
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-slate-600">Loading course...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-slate-900 mb-2">Course Not Found</h3>
          <p className="text-slate-600 mb-4">The course you're looking for doesn't exist.</p>
          <Button onClick={() => navigate(createPageUrl("Dashboard"))}>
            Return to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="bg-white/80 backdrop-blur-sm"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-slate-900">{course.title}</h1>
            <p className="text-slate-600 mt-1">{course.subject} • {course.level} Level</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="bg-white/80">
              <Share className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button variant="outline" className="bg-white/80">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        {enrollment && (
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-slate-900">Your Progress</h3>
                  <p className="text-sm text-slate-600">
                    {Math.round(enrollment.progress)}% Complete
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-slate-900">
                    {Math.round(enrollment.progress)}%
                  </div>
                </div>
              </div>
              <Progress value={enrollment.progress} className="h-3" />
            </CardContent>
          </Card>
        )}

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm shadow-sm">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="content">Course Content</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-8">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>About This Course</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-700 mb-4">{course.description || course.meta_description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-slate-500" />
                        <span className="text-sm text-slate-600">
                          Duration: {course.estimated_duration || "Self-paced"}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-slate-500" />
                        <span className="text-sm text-slate-600">
                          Level: {course.level}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-slate-500" />
                        <span className="text-sm text-slate-600">
                          {course.syllabus?.length || 0} Modules
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-slate-500" />
                        <span className="text-sm text-slate-600">
                          Certificate Included
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {course.learning_objectives?.length > 0 && (
                  <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                    <CardHeader>
                      <CardTitle>Learning Objectives</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {course.learning_objectives.map((objective, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-slate-700">{objective}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}
              </div>

              <div className="space-y-6">
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>Course Stats</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Modules</span>
                      <span className="font-semibold">{course.syllabus?.length || 0}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Lessons</span>
                      <span className="font-semibold">
                        {course.syllabus?.reduce((acc, m) => acc + (m.lessons?.length || 0), 0) || 0}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Quizzes</span>
                      <span className="font-semibold">
                        {course.syllabus?.filter(m => m.quiz_id).length || 0}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Difficulty</span>
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= (course.difficulty_rating || 3)
                                ? "text-amber-400 fill-current"
                                : "text-slate-300"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {course.final_assessment_id && (
                  <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200 shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-500 rounded-lg flex items-center justify-center">
                          <Award className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900">Final Assessment</h3>
                          <p className="text-sm text-slate-600">Complete to earn certificate</p>
                        </div>
                      </div>
                      <Button
                        onClick={handleTakeFinalExam}
                        className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
                      >
                        Take Final Exam
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="content" className="mt-8">
            <div className="space-y-8">
              {course.syllabus?.map((module, idx) => (
                <div key={module.id || idx}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                      {idx + 1}
                    </div>
                    <h2 className="text-2xl font-bold text-slate-900">
                      Module {idx + 1}: {module.module_title}
                    </h2>
                  </div>
                  
                  <ModuleViewer
                    module={module}
                    onTakeQuiz={handleTakeQuiz}
                    onLessonComplete={handleLessonComplete}
                  />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="resources" className="mt-8">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Download Resources</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="w-4 h-4 mr-2" />
                    Course Syllabus (PDF)
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Course Slides (PowerPoint)
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Study Guide (PDF)
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Additional Support</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Brain className="w-4 h-4 mr-2" />
                    AI Tutor Chat
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="w-4 h-4 mr-2" />
                    Discussion Forum
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    External Resources
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}