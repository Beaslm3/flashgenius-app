import React, { useState, useEffect } from "react";
import { Blog } from "@/api/entities";
import { useLocation, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ReactMarkdown from 'react-markdown';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, User as UserIcon, ArrowLeft, Share2, BookmarkPlus } from "lucide-react";
import { motion } from "framer-motion";

export default function BlogPostPage() {
  const location = useLocation();
  const [post, setPost] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const urlParams = new URLSearchParams(location.search);
        const slug = urlParams.get('slug');
        
        if (!slug) {
          setError("Blog post not found.");
          setIsLoading(false);
          return;
        }

        const results = await Blog.filter({ slug: slug, status: 'published' });
        if (results.length > 0) {
          setPost(results[0]);
          document.title = `${results[0].title} | Acedemy.io Blog`;
          if (results[0].meta_description) {
            const metaDesc = document.querySelector('meta[name="description"]');
            if (metaDesc) {
              metaDesc.content = results[0].meta_description;
            } else {
              const meta = document.createElement('meta');
              meta.name = 'description';
              meta.content = results[0].meta_description;
              document.head.appendChild(meta);
            }
          }
        } else {
          setError("Blog post not found.");
        }
      } catch (err) {
        setError("Failed to fetch the blog post.");
        console.error(err);
      }
      setIsLoading(false);
    };
    fetchPost();
  }, [location.search]);

  const handleShare = async () => {
    if (navigator.share && post) {
      try {
        await navigator.share({
          title: post.title,
          text: post.meta_description,
          url: window.location.href
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading article...</p>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-6">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">Article Not Found</h1>
          <p className="text-slate-600 mb-6">{error || "The article you're looking for doesn't exist."}</p>
          <Link to={createPageUrl("Blog")}>
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50">
      {/* Hero Section with Fixed Image Display */}
      <div className="relative h-96 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 to-slate-800/60 z-10"></div>
        <img 
          src={post.cover_image_url || 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80'} 
          alt={post.title}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.target.src = 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80';
          }}
        />
        <div className="absolute inset-0 z-20 flex items-center justify-center">
          <div className="text-center text-white max-w-4xl mx-auto px-6">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight"
            >
              {post.title}
            </motion.h1>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="flex items-center justify-center gap-6 text-white/90"
            >
              <div className="flex items-center gap-2">
                <UserIcon className="w-5 h-5" />
                <span className="font-medium">{post.author_name || 'Acedemy.io Team'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{new Date(post.created_date).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</span>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Back Button */}
        <div className="absolute top-6 left-6 z-30">
          <Link to={createPageUrl("Blog")}>
            <Button variant="outline" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
        </div>
        
        {/* Share Button */}
        <div className="absolute top-6 right-6 z-30">
          <Button 
            onClick={handleShare}
            variant="outline" 
            className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      {/* Article Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-8 md:p-12">
              <div className="prose prose-lg max-w-none">
                <ReactMarkdown
                  components={{
                    h1: ({children}) => <h1 className="text-3xl font-bold text-slate-900 mb-6">{children}</h1>,
                    h2: ({children}) => <h2 className="text-2xl font-semibold text-slate-800 mb-4 mt-8">{children}</h2>,
                    h3: ({children}) => <h3 className="text-xl font-semibold text-slate-800 mb-3 mt-6">{children}</h3>,
                    p: ({children}) => <p className="text-slate-700 leading-relaxed mb-4">{children}</p>,
                    ul: ({children}) => <ul className="list-disc pl-6 mb-4 space-y-2">{children}</ul>,
                    ol: ({children}) => <ol className="list-decimal pl-6 mb-4 space-y-2">{children}</ol>,
                    li: ({children}) => <li className="text-slate-700">{children}</li>,
                    strong: ({children}) => <strong className="font-semibold text-slate-900">{children}</strong>,
                    em: ({children}) => <em className="italic text-slate-800">{children}</em>,
                    blockquote: ({children}) => (
                      <blockquote className="border-l-4 border-indigo-500 pl-6 my-6 text-slate-600 italic bg-indigo-50 py-4 rounded-r-lg">
                        {children}
                      </blockquote>
                    ),
                    code: ({children}) => (
                      <code className="bg-slate-100 text-slate-800 px-2 py-1 rounded text-sm font-mono">
                        {children}
                      </code>
                    ),
                    pre: ({children}) => (
                      <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto my-4">
                        {children}
                      </pre>
                    )
                  }}
                >
                  {post.content}
                </ReactMarkdown>
              </div>
              
              {/* Tags */}
              {post.seo_keywords && post.seo_keywords.length > 0 && (
                <div className="mt-8 pt-8 border-t border-slate-200">
                  <h4 className="text-sm font-semibold text-slate-600 mb-3">Tags:</h4>
                  <div className="flex flex-wrap gap-2">
                    {post.seo_keywords.map((keyword, index) => (
                      <span 
                        key={index}
                        className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium"
                      >
                        #{keyword}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}