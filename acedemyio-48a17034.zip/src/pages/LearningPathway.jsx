import React, { useState, useEffect } from "react";
import { Course, ProgressReport, FlashcardSet, Flashcard } from "@/api/entities";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, CheckCircle, BookOpen, Target, PlayCircle, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function LearningPathwayPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [report, setReport] = useState(null);
  const [course, setCourse] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      const urlParams = new URLSearchParams(location.search);
      const reportId = urlParams.get('reportId');
      const courseId = urlParams.get('courseId');

      if (!reportId || !courseId) {
        setIsLoading(false);
        return;
      }

      try {
        const [reportData, courseData] = await Promise.all([
          ProgressReport.get(reportId),
          Course.get(courseId)
        ]);
        setReport(reportData);
        setCourse(courseData);
      } catch (error) {
        console.error("Failed to fetch learning pathway data:", error);
      }
      setIsLoading(false);
    };
    fetchData();
  }, [location.search]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!report || !course) {
    return (
      <div className="min-h-screen flex items-center justify-center text-center p-6">
        <div>
          <h2 className="text-2xl font-bold text-red-600">Error</h2>
          <p className="text-slate-600 mt-2">Could not load the learning pathway. Please go back and try again.</p>
          <Button onClick={() => navigate(createPageUrl("ProgressReports"))} className="mt-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Reports
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("ProgressReports"))}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to All Reports
        </Button>

        <Card className="mb-8 bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-slate-900">{course.title}</CardTitle>
            <p className="text-slate-600 mt-1">{course.meta_description}</p>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm font-medium text-slate-700">Overall Progress</span>
              <span className="text-sm font-bold text-indigo-600">0%</span> {/* This would be dynamic */}
            </div>
            <Progress value={0} />
          </CardContent>
        </Card>

        <h2 className="text-2xl font-bold text-slate-800 mb-4">Modules</h2>
        
        <Accordion type="single" collapsible className="w-full space-y-4">
          {course.syllabus && course.syllabus.map((module, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg rounded-xl">
              <AccordionTrigger className="p-6 text-lg font-semibold hover:no-underline">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 font-bold">
                    {index + 1}
                  </div>
                  {module.module}
                </div>
              </AccordionTrigger>
              <AccordionContent className="p-6 pt-0">
                <div className="prose prose-slate max-w-none mb-6">
                  <ReactMarkdown>{module.content}</ReactMarkdown>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Target className="w-5 h-5 text-amber-500"/>
                        <p className="font-semibold text-slate-800">Practice Activities</p>
                    </div>
                    <Button asChild>
                      <Link to={createPageUrl(`Test?set=${module.test_set_id}`)}>
                        <PlayCircle className="mr-2 h-4 w-4" />
                        Take Unit Quiz
                      </Link>
                    </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}