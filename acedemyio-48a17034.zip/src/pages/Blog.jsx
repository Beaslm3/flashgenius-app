import React, { useState, useEffect } from "react";
import { Blog } from "@/api/entities";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Calendar, User as UserIcon } from "lucide-react";
import { motion } from "framer-motion";

const BlogCard = ({ post }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -5, transition: { duration: 0.2 } }}
    className="h-full"
  >
    <Link to={createPageUrl(`BlogPost?slug=${post.slug}`)} className="block h-full">
      <Card className="h-full flex flex-col overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm">
        <img src={post.cover_image_url} alt={post.title} className="w-full h-48 object-cover" />
        <CardHeader>
          <CardTitle className="text-xl font-bold text-slate-900 leading-tight">{post.title}</CardTitle>
          <div className="flex items-center gap-4 text-sm text-slate-500 pt-2">
            <div className="flex items-center gap-2">
              <UserIcon className="w-4 h-4" />
              <span>{post.author_name}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{new Date(post.created_date).toLocaleDateString()}</span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-slate-600 line-clamp-3">{post.meta_description}</p>
        </CardContent>
        <div className="p-6 pt-0 mt-auto">
           <div className="flex items-center gap-2 text-blue-600 font-semibold">
              Read More <ArrowRight className="w-4 h-4" />
           </div>
        </div>
      </Card>
    </Link>
  </motion.div>
);

export default function BlogPage() {
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      setIsLoading(true);
      try {
        const publishedPosts = await Blog.filter({ status: 'published' }, '-created_date');
        setPosts(publishedPosts);
      } catch (error) {
        console.error("Failed to fetch blog posts:", error);
      }
      setIsLoading(false);
    };
    fetchPosts();
  }, []);

  if (isLoading) {
    return (
        <div className="p-6 md:p-12">
            <h1 className="text-4xl font-bold text-center mb-12">Loading Posts...</h1>
        </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-slate-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-extrabold text-slate-900 tracking-tight">The Acedemy.io Blog</h1>
          <p className="mt-4 text-xl text-slate-600 max-w-2xl mx-auto">
            Insights on AI-powered learning, study techniques, and the future of education.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map(post => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </div>
  );
}