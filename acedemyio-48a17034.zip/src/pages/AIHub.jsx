import React, { useState, useEffect, useRef } from "react";
import { User, Course, Summary, FlashcardSet, Flashcard } from "@/api/entities";
import { InvokeLLM, UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Send, Mic, MicOff, Upload, Loader2, Brain, Sparkles, Globe, BookOpen, Calculator, Atom, History, 
  Code, Palette, Music, Heart, Leaf, FileText, Copy, CheckCircle, LayoutDashboard
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Label } from "@/components/ui/label";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";

const subjects = [
  { id: "math", name: "Mathematics", icon: Calculator }, { id: "science", name: "Science", icon: Atom }, 
  { id: "history", name: "History", icon: History }, { id: "coding", name: "Programming", icon: Code }, 
  { id: "english", name: "English/Literature", icon: BookOpen }, { id: "art", name: "Art & Design", icon: Palette },
  { id: "music", name: "Music", icon: Music }, { id: "health", name: "Health & PE", icon: Heart }, 
  { id: "biology", name: "Biology", icon: Leaf }, { id: "general", name: "General Knowledge", icon: Globe }
];

const ageLevels = [
  { id: "elementary", name: "Elementary" }, { id: "middle", name: "Middle School" }, 
  { id: "high", name: "High School" }, { id: "college", name: "College" }, { id: "adult", name: "Adult Learner" }
];

const languages = [ { code: "en", name: "English" }, { code: "es", name: "Español" }, { code: "fr", name: "Français" }, { code: "de", name: "Deutsch" }, { code: "it", name: "Italiano" }, { code: "pt", name: "Português" }, { code: "zh", name: "中文" }];

export default function AIHubPage() {
    const navigate = useNavigate();
    const [question, setQuestion] = useState("");
    const [selectedSubject, setSelectedSubject] = useState("general");
    const [selectedAge, setSelectedAge] = useState("middle");
    const [selectedLanguage, setSelectedLanguage] = useState("en");
    const [conversation, setConversation] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [user, setUser] = useState(null);
    const conversationEndRef = useRef(null);

    useEffect(() => { loadUser(); }, []);
    useEffect(() => { conversationEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [conversation]);

    const loadUser = async () => {
      try { setUser(await User.me()); } catch (error) { console.error("Not logged in:", error); }
    };

    const handleLogin = async () => { await User.login(); };
    
    const addProgressMessage = (type, subject) => {
        const progressMessage = { id: Date.now(), role: "ai", content: `🔄 Creating ${type} for ${subject}...`, isProgress: true };
        setConversation(prev => [...prev, progressMessage]);
        return progressMessage.id;
    };

    const updateProgressMessage = (id, content, isSuccess = true, actions = null) => {
        setConversation(prev => prev.map(msg => msg.id === id ? { ...msg, content, actions, isProgress: false } : msg));
    };

    const createCourseFromTopic = async (subject, content) => {
        const progressId = addProgressMessage("course", subject);
        setIsGenerating(true);
        try {
            const courseOutline = await InvokeLLM({
                prompt: `You are an expert instructional designer. Create a comprehensive course outline for a course on "${subject}" based on the following context: ${content}. The target audience is ${selectedAge} level. The course must be in ${selectedLanguage}. Generate a title, a short description, and a syllabus with 4-6 module titles and their brief descriptions.`,
                response_json_schema: { type: "object", properties: { title: { type: "string" }, description: { type: "string" }, syllabus: { type: "array", items: { type: "object", properties: { module_title: { type: "string" }, module_description: { type: "string" } } } } } }
            });
            const newCourse = await Course.create({ title: courseOutline.title, subject, meta_description: courseOutline.description, syllabus: courseOutline.syllabus, level: selectedAge, language: selectedLanguage, status: 'draft' });
            updateProgressMessage(progressId, `✅ Course "${newCourse.title}" created!`, true, [{ icon: BookOpen, label: "Edit Course", action: () => navigate(createPageUrl(`CourseEditor?id=${newCourse.id}`)) }]);
        } catch (error) { updateProgressMessage(progressId, "❌ Error creating course.", false); } 
        finally { setIsGenerating(false); }
    };
    
    const generateSmartActions = (response, subject) => [
        { icon: Copy, label: "Create Flashcards", action: () => { /* Stub */ alert("Flashcard creation from here coming soon!"); } },
        { icon: FileText, label: "Create Summary", action: () => { /* Stub */ alert("Summary creation from here coming soon!"); } },
        { icon: BookOpen, label: "Generate Course", action: () => createCourseFromTopic(subject, response) },
        { icon: CheckCircle, label: "Take Quiz", action: () => { /* Stub */ alert("Quiz creation from here coming soon!"); } }
    ];

    const handleSubmit = async () => {
        if (!question.trim() && uploadedFiles.length === 0) return;
        if (!user) { handleLogin(); return; }

        const userMessage = { id: Date.now(), role: "user", content: question, files: uploadedFiles };
        setConversation(prev => [...prev, userMessage]);
        setQuestion("");
        setUploadedFiles([]);
        setIsLoading(true);

        try {
            const selectedSubjectInfo = subjects.find(s => s.id === selectedSubject);
            const systemPrompt = `You are "Acedemy.io AI", a professional, encouraging, and highly knowledgeable AI tutor. Respond in ${selectedLanguage}. The user is at a ${selectedAge} level, studying ${selectedSubjectInfo.name}. Be clear, structured, and use Markdown.`;
            const response = await InvokeLLM({ prompt: `${systemPrompt}\n\nUser question: "${question}"`, add_context_from_internet: true });
            const aiMessage = { id: Date.now() + 1, role: "ai", content: response, actions: generateSmartActions(response, selectedSubjectInfo.name) };
            setConversation(prev => [...prev, aiMessage]);
        } catch (error) {
            console.error("Error getting AI response:", error);
            setConversation(prev => [...prev, { id: Date.now() + 1, role: "error", content: "Sorry, I encountered an error. Please try again." }]);
        }
        setIsLoading(false);
    };

    const selectedSubjectInfo = subjects.find(s => s.id === selectedSubject);

    return (
        <div className="flex h-[calc(100vh-4rem)] bg-white">
            {/* Settings Panel */}
            <aside className="w-80 border-r p-6 space-y-6 bg-slate-50 overflow-y-auto">
                <h2 className="text-xl font-bold">AI Learning Center</h2>
                <Card className="bg-white">
                    <CardHeader><CardTitle className="text-base">Customize Your Tutor</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <Label>Subject</Label>
                            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{subjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Learning Level</Label>
                            <Select value={selectedAge} onValueChange={setSelectedAge}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{ageLevels.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Language</Label>
                            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{languages.map(l => <SelectItem key={l.code} value={l.code}>{l.name}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                    </CardContent>
                </Card>
            </aside>

            {/* Main Chat Area */}
            <main className="flex-1 flex flex-col">
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {conversation.length === 0 && (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
                            <Sparkles className="w-16 h-16 mb-4 text-gray-300" />
                            <h3 className="text-2xl font-semibold text-gray-800">Ask me anything</h3>
                            <p>I can help you learn, create study materials, and build entire courses.</p>
                        </div>
                    )}
                    <AnimatePresence>
                        {conversation.map((message) => (
                            <motion.div
                                key={message.id}
                                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                                {message.role === 'ai' && <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0"><Sparkles className="w-5 h-5 text-primary" /></div>}
                                <div className={`max-w-2xl rounded-lg p-4 shadow-sm ${message.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
                                    <div className="prose prose-sm max-w-none prose-p:my-2 text-foreground"><ReactMarkdown>{message.content}</ReactMarkdown></div>
                                    {message.actions && (
                                        <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t">
                                            {message.actions.map((action, idx) => (
                                                <Button key={idx} size="sm" variant="outline" onClick={action.action} className="bg-white" disabled={isGenerating}>
                                                    <action.icon className="w-3 h-3 mr-2" />{action.label}
                                                </Button>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                    {isLoading && (
                        <div className="flex justify-start gap-3"><div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center"><Loader2 className="w-5 h-5 text-primary animate-spin" /></div><div className="bg-secondary rounded-lg p-4"><p>Thinking...</p></div></div>
                    )}
                    <div ref={conversationEndRef} />
                </div>
                <div className="border-t p-4 bg-white">
                    <div className="relative">
                        <Textarea
                            placeholder={`Ask anything about ${selectedSubjectInfo.name}...`}
                            value={question}
                            onChange={(e) => setQuestion(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSubmit())}
                            className="pr-20 resize-none" rows={2}
                            disabled={isLoading || isGenerating}
                        />
                        <div className="absolute right-2 bottom-2 flex gap-1">
                            <Button size="icon" variant="ghost"><Upload className="w-4 h-4" /></Button>
                            <Button size="icon" onClick={handleSubmit} disabled={isLoading || isGenerating || !question.trim()}><Send className="w-4 h-4" /></Button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}