
import React, { useState, useEffect } from "react";
import { FlashcardSet, Flashcard, Course, Summary, TestSession } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Download, FileText, Presentation, BookOpen, Eye, Loader2, CheckCircle, Image as ImageIcon, Palette, Type, Layout, RefreshCw, Download as DownloadIcon } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { InvokeLLM, GenerateImage } from "@/api/integrations";

const bookSizes = [
  { id: "6x9", name: '6" × 9"', description: "Standard fiction/non-fiction", dimensions: "15.24cm × 22.86cm", aspectRatio: "6:9" },
  { id: "5.5x8.5", name: '5.5" × 8.5"', description: "Compact book size", dimensions: "13.97cm × 21.59cm", aspectRatio: "5.5:8.5" },
  { id: "8x10", name: '8" × 10"', description: "Textbook/workbook", dimensions: "20.32cm × 25.4cm", aspectRatio: "4:5" },
  { id: "7x10", name: '7" × 10"', description: "Educational materials", dimensions: "17.78cm × 25.4cm", aspectRatio: "7:10" },
  { id: "8.5x11", name: '8.5" × 11"', description: "Standard letter size", dimensions: "21.59cm × 27.94cm", aspectRatio: "8.5:11" },
  { id: "5x8", name: '5" × 8"', description: "Pocket book size", dimensions: "12.7cm × 20.32cm", aspectRatio: "5:8" }
];

const fontOptions = [
  { id: "times", name: "Times New Roman", description: "Classic serif font", preview: "serif" },
  { id: "georgia", name: "Georgia", description: "Modern serif font", preview: "serif" },
  { id: "arial", name: "Arial", description: "Clean sans-serif", preview: "sans-serif" },
  { id: "calibri", name: "Calibri", description: "Modern sans-serif", preview: "sans-serif" },
  { id: "garamond", name: "Garamond", description: "Elegant serif", preview: "serif" },
  { id: "helvetica", name: "Helvetica", description: "Professional sans-serif", preview: "sans-serif" }
];

const coverStyles = [
  { 
    id: "modern", 
    name: "Modern Minimal", 
    description: "Clean, professional design",
    colors: ["#2563eb", "#1e40af", "#1d4ed8"],
    layout: "minimal"
  },
  { 
    id: "academic", 
    name: "Academic", 
    description: "Traditional scholarly look",
    colors: ["#374151", "#4b5563", "#6b7280"],
    layout: "traditional"
  },
  { 
    id: "creative", 
    name: "Creative", 
    description: "Artistic and engaging",
    colors: ["#7c3aed", "#8b5cf6", "#a78bfa"],
    layout: "artistic"
  },
  { 
    id: "business", 
    name: "Business", 
    description: "Corporate and formal",
    colors: ["#059669", "#10b981", "#34d399"],
    layout: "corporate"
  },
  { 
    id: "textbook", 
    name: "Textbook", 
    description: "Educational format",
    colors: ["#dc2626", "#ef4444", "#f87171"],
    layout: "educational"
  },
  { 
    id: "elegant", 
    name: "Elegant", 
    description: "Sophisticated design",
    colors: ["#7c2d12", "#ea580c", "#fb923c"],
    layout: "elegant"
  }
];

export default function Export() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const type = searchParams.get('type');
    const id = searchParams.get('id');
    
    const [item, setItem] = useState(null);
    const [cards, setCards] = useState([]);
    const [testSessions, setTestSessions] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [exportLoading, setExportLoading] = useState(null);
    const [coverPreview, setCoverPreview] = useState(null);
    const [generatedCoverUrl, setGeneratedCoverUrl] = useState(null);
    
    // Export settings
    const [exportSettings, setExportSettings] = useState({
        bookSize: "6x9",
        fontSize: 12,
        fontFamily: "times",
        coverStyle: "modern",
        includeTableOfContents: true,
        includePageNumbers: true,
        separateCover: true,
        customTitle: "",
        customSubtitle: "",
        authorName: "",
        coverPrompt: ""
    });

    useEffect(() => {
        loadItem();
    }, [type, id]);

    useEffect(() => {
        generateCoverPreview();
    }, [exportSettings.coverStyle, exportSettings.customTitle, exportSettings.customSubtitle, exportSettings.authorName, item]);

    const loadItem = async () => {
        if (!type || !id) return;
        
        setIsLoading(true);
        try {
            let itemData = null;
            let cardsData = [];

            if (type === 'flashcards') {
                itemData = await FlashcardSet.get(id);
                cardsData = await Flashcard.filter({ set_id: id }, "order_index");
                const sessions = await TestSession.filter({ set_id: id }, "-created_date");
                setTestSessions(sessions);
            } else if (type === 'course') {
                itemData = await Course.get(id);
            } else if (type === 'summary') {
                itemData = await Summary.get(id);
            }

            setItem(itemData);
            setCards(cardsData);
            
            setExportSettings(prev => ({
                ...prev,
                customTitle: itemData?.title || "",
                authorName: "FlashGenius"
            }));
        } catch (error) {
            console.error("Error loading item:", error);
        }
        setIsLoading(false);
    };

    const generateCoverPreview = () => {
        if (!item) return;
        
        const selectedStyle = coverStyles.find(s => s.id === exportSettings.coverStyle);
        const selectedSize = bookSizes.find(s => s.id === exportSettings.bookSize);
        
        setCoverPreview({
            title: exportSettings.customTitle || item.title,
            subtitle: exportSettings.customSubtitle,
            author: exportSettings.authorName || "FlashGenius",
            style: selectedStyle,
            size: selectedSize,
            subject: item.subject
        });
    };

    const generateAICover = async () => {
        setExportLoading('ai-cover');
        try {
            const selectedStyle = coverStyles.find(s => s.id === exportSettings.coverStyle);
            const title = exportSettings.customTitle || item.title;
            
            const prompt = exportSettings.coverPrompt || 
                `Create a professional book cover for "${title}". 
                ${exportSettings.customSubtitle ? `Subtitle: "${exportSettings.customSubtitle}".` : ''}
                Style: ${selectedStyle.name} - ${selectedStyle.description}. 
                Subject: ${item.subject}. 
                Colors: Professional ${selectedStyle.colors[0]} color scheme.
                The cover should be ${selectedStyle.layout}, elegant, and suitable for ${type === 'flashcards' ? 'educational flashcards' : type}.
                Include space for title and author name. High quality, professional design suitable for print.
                Aspect ratio for ${bookSizes.find(s => s.id === exportSettings.bookSize)?.name} book size.`;

            const coverResponse = await GenerateImage({ prompt });
            setGeneratedCoverUrl(coverResponse.url);
            
        } catch (error) {
            console.error("Error generating AI cover:", error);
            alert("Failed to generate AI cover. Please try again.");
        }
        setExportLoading(null);
    };

    const downloadCover = async (url, filename) => {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            const downloadUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(downloadUrl);
        } catch (error) {
            console.error("Error downloading cover:", error);
            alert("Failed to download cover. Please try again.");
        }
    };

    const exportContent = async (format) => {
        if (!item) return;
        
        setExportLoading(format);
        try {
            let content = '';
            let documentTitle = exportSettings.customTitle || item.title;
            
            // Build comprehensive content
            if (type === 'flashcards') {
                content = `FLASHCARD SET EXPORT
                
Title: ${documentTitle}
${exportSettings.customSubtitle ? `Subtitle: ${exportSettings.customSubtitle}` : ''}
Subject: ${item.subject}
Difficulty: ${item.difficulty}
Author: ${exportSettings.authorName}
Generated by: FlashGenius AI Platform
Total Cards: ${cards.length}

${item.description ? `Description: ${item.description}` : ''}

FLASHCARD COLLECTION:

${cards.map((card, index) => `
CARD ${index + 1}
Question: ${card.question}
Answer: ${card.answer}
${card.explanation ? `Explanation: ${card.explanation}` : ''}
Difficulty: ${card.difficulty || 'Medium'}
---
`).join('\n')}

© ${new Date().getFullYear()} ${exportSettings.authorName}. Generated with FlashGenius AI.`;

            } else if (type === 'course') {
                content = `COURSE EXPORT

Title: ${documentTitle}
${exportSettings.customSubtitle ? `Subtitle: ${exportSettings.customSubtitle}` : ''}
Subject: ${item.subject}
Language: ${item.language}
Author: ${exportSettings.authorName}

${item.word_document_content || 'Course content ready for professional formatting.'}

© ${new Date().getFullYear()} ${exportSettings.authorName}. Generated with FlashGenius AI.`;

            } else if (type === 'summary') {
                content = `SUMMARY EXPORT

Title: ${documentTitle}
${exportSettings.customSubtitle ? `Subtitle: ${exportSettings.customSubtitle}` : ''}
Author: ${exportSettings.authorName}
Language: ${item.language || 'English'}

${item.summarized_content}

© ${new Date().getFullYear()} ${exportSettings.authorName}. Generated with FlashGenius AI.`;
            }

            const selectedSize = bookSizes.find(s => s.id === exportSettings.bookSize);
            const selectedFont = fontOptions.find(f => f.id === exportSettings.fontFamily);

            let formattingPrompt = '';
            
            if (format === 'pdf' || format === 'kdp') {
                formattingPrompt = `Format this content into a professional ${format.toUpperCase()} document with these specifications:

📖 BOOK SPECIFICATIONS:
- Trim Size: ${selectedSize.name} (${selectedSize.dimensions})
- Font: ${selectedFont.name}, ${exportSettings.fontSize}pt
- Professional margins: 0.75" inside, 0.5" outside, top, bottom
- ${format === 'kdp' ? 'Bleed: 0.125" on all sides for print' : ''}
- ${exportSettings.includePageNumbers ? 'Page numbers: Bottom center' : 'No page numbers'}

📚 DOCUMENT STRUCTURE:
${exportSettings.includeTableOfContents ? '- Professional table of contents with page numbers' : ''}
- Title page with all metadata
- Copyright page with publication info
- Professional chapter divisions
- Consistent formatting throughout
- Proper headers and footers

📝 FORMATTING REQUIREMENTS:
- Use ${selectedFont.name} font family
- Body text: ${exportSettings.fontSize}pt
- Headings: Progressive sizing (18pt, 16pt, 14pt)
- Professional line spacing (1.15)
- Justified text alignment
- Chapter breaks on new pages
- Consistent paragraph spacing

${format === 'kdp' ? `
🖨️ AMAZON KDP PRINT REQUIREMENTS:
- All fonts must be embedded
- Images at 300 DPI minimum
- Proper bleed margins
- Print-ready formatting
- Professional book structure
- ISBN placement ready
` : ''}

CONTENT TO FORMAT:
${content}`;

            } else if (format === 'word') {
                formattingPrompt = `Convert to Microsoft Word format with:
- Professional document structure
- ${selectedFont.name} font, ${exportSettings.fontSize}pt
- Proper styles (Heading 1, 2, 3, Normal)
- ${exportSettings.includeTableOfContents ? 'Automatic table of contents' : ''}
- Professional margins and spacing
- Page layout optimized for ${selectedSize.description}

Content: ${content}`;
            }

            const formattedContent = await InvokeLLM({
                prompt: formattingPrompt,
                add_context_from_internet: false
            });

            // Create and download the file
            const blob = new Blob([formattedContent], { 
                type: format === 'word' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : 'application/pdf'
            });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const cleanTitle = documentTitle.replace(/[^a-z0-9\s]/gi, '').replace(/\s+/g, '_').toLowerCase();
            a.download = `${cleanTitle}_${format === 'kdp' ? 'amazon_kdp' : format}.${format === 'word' ? 'docx' : 'pdf'}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            // Auto-download cover if separate cover is enabled and we have one
            if (exportSettings.separateCover && generatedCoverUrl && (format === 'pdf' || format === 'kdp')) {
                setTimeout(() => {
                    downloadCover(generatedCoverUrl, `${cleanTitle}_cover.png`);
                }, 1000);
            }

        } catch (error) {
            console.error(`Error exporting as ${format}:`, error);
            alert(`Failed to export as ${format}. Please try again.`);
        }
        setExportLoading(null);
    };

    const exportTest = async (format) => {
        if (testSessions.length === 0) {
            alert("No test data available for export.");
            return;
        }

        setExportLoading(`test-${format}`);
        try {
            const latestTest = testSessions[0];
            const testContent = `TEST RESULTS REPORT

Title: ${item.title} - Test Results
Subject: ${item.subject}
Date: ${new Date(latestTest.created_date).toLocaleDateString()}
Student Performance Report

SUMMARY:
- Total Score: ${latestTest.score}%
- Questions Answered: ${latestTest.total_questions}
- Correct Answers: ${latestTest.correct_answers}
- Incorrect Answers: ${latestTest.total_questions - latestTest.correct_answers}
- Time Taken: ${Math.floor(latestTest.time_taken / 60)} minutes ${latestTest.time_taken % 60} seconds
- Accuracy Rate: ${Math.round((latestTest.correct_answers / latestTest.total_questions) * 100)}%

DETAILED RESULTS:
${latestTest.answers?.map((answer, index) => `
Question ${index + 1}:
Your Answer: ${answer.user_answer}
Correct Answer: ${answer.correct_answer}
Result: ${answer.is_correct ? '✅ CORRECT' : '❌ INCORRECT'}
${answer.explanation ? `Explanation: ${answer.explanation}` : ''}
`).join('\n') || 'Detailed answers not available'}

Generated by FlashGenius AI Platform
© ${new Date().getFullYear()} FlashGenius. All rights reserved.`;

            const prompt = `Format this test result data into a professional ${format.toUpperCase()} report with tables, charts, and professional formatting: ${testContent}`;
            const formattedTest = await InvokeLLM({ prompt });

            const blob = new Blob([formattedTest], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const cleanTitle = item.title.replace(/[^a-z0-9\s]/gi, '').replace(/\s+/g, '_').toLowerCase();
            a.download = `${cleanTitle}_test_results.${format === 'pdf' ? 'pdf' : 'docx'}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

        } catch (error) {
            console.error("Error exporting test:", error);
            alert("Failed to export test results. Please try again.");
        }
        setExportLoading(null);
    };

    // Cover Preview Component
    const CoverPreview = ({ preview, size, isAI = false, url = null }) => {
        if (!preview) return null;

        const aspectRatio = size?.aspectRatio || "2:3";
        const [width, height] = aspectRatio.split(':').map(Number);
        const displayHeight = 300;
        const displayWidth = (displayHeight * width) / height;

        if (isAI && url) {
            return (
                <div className="relative group">
                    <img 
                        src={url} 
                        alt="AI Generated Cover" 
                        className="rounded-lg shadow-xl border border-slate-200"
                        style={{ width: displayWidth, height: displayHeight, objectFit: 'cover' }}
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all rounded-lg flex items-center justify-center">
                        <Button
                            onClick={() => downloadCover(url, `${preview.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_cover.png`)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity bg-white text-slate-800 hover:bg-slate-100"
                            size="sm"
                        >
                            <DownloadIcon className="w-4 h-4 mr-1" />
                            Download
                        </Button>
                    </div>
                </div>
            );
        }

        return (
            <div 
                className="relative rounded-lg shadow-xl border border-slate-200 overflow-hidden"
                style={{ 
                    width: displayWidth, 
                    height: displayHeight,
                    background: `linear-gradient(135deg, ${preview.style.colors[0]}, ${preview.style.colors[1]})`
                }}
            >
                <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-transparent" />
                <div className="relative h-full flex flex-col justify-between p-6 text-white">
                    <div>
                        <div className="text-xs font-semibold uppercase tracking-wider opacity-80 mb-2">
                            {preview.subject}
                        </div>
                        <h3 className="text-lg font-bold leading-tight mb-2 text-shadow">
                            {preview.title}
                        </h3>
                        {preview.subtitle && (
                            <p className="text-sm opacity-90 text-shadow">
                                {preview.subtitle}
                            </p>
                        )}
                    </div>
                    <div>
                        <div className="text-sm font-medium text-shadow">
                            {preview.author}
                        </div>
                        <div className="text-xs opacity-70 mt-1">
                            FlashGenius AI
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-6" />
                    <h2 className="text-xl font-semibold text-slate-800 mb-2">Loading Export Studio</h2>
                    <p className="text-slate-600">Preparing your content for professional export...</p>
                </div>
            </div>
        );
    }

    if (!item) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
                <Card className="text-center p-8 max-w-md">
                    <CardContent>
                        <h2 className="text-xl font-semibold text-slate-800 mb-2">Content Not Found</h2>
                        <p className="text-slate-600 mb-4">The requested content could not be found.</p>
                        <Button onClick={() => navigate(createPageUrl("Dashboard"))}>
                            Return to Dashboard
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
            <div className="max-w-7xl mx-auto p-6">
                {/* Professional Header */}
                <div className="flex items-center gap-6 mb-8">
                    <Button
                        variant="outline"
                        size="icon"
                        onClick={() => navigate(createPageUrl("Dashboard"))}
                        className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all"
                    >
                        <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div className="flex-1">
                        <h1 className="text-4xl font-bold text-slate-900 mb-2">Professional Export Studio</h1>
                        <p className="text-lg text-slate-600">Transform your content into publication-ready materials</p>
                    </div>
                    <div className="text-right">
                        <Badge variant="outline" className="bg-white/80 text-slate-700 px-4 py-2">
                            {type === 'flashcards' ? '📚 Flashcards' : type === 'course' ? '🎓 Course' : '📄 Summary'}
                        </Badge>
                    </div>
                </div>

                <div className="grid lg:grid-cols-4 gap-8">
                    {/* Export Settings Panel */}
                    <div className="lg:col-span-1">
                        <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0 sticky top-6">
                            <CardHeader className="pb-4">
                                <CardTitle className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                                        <Layout className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                        <span className="text-lg font-bold">Export Settings</span>
                                        <p className="text-sm text-slate-500 font-normal">Customize your publication</p>
                                    </div>
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <Tabs defaultValue="format" className="w-full">
                                    <TabsList className="grid w-full grid-cols-3 bg-slate-100">
                                        <TabsTrigger value="format" className="text-xs">Format</TabsTrigger>
                                        <TabsTrigger value="design" className="text-xs">Design</TabsTrigger>
                                        <TabsTrigger value="cover" className="text-xs">Cover</TabsTrigger>
                                    </TabsList>
                                    
                                    <TabsContent value="format" className="space-y-4 mt-6">
                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">Book Size</Label>
                                            <Select 
                                                value={exportSettings.bookSize} 
                                                onValueChange={(value) => setExportSettings(prev => ({...prev, bookSize: value}))}
                                            >
                                                <SelectTrigger className="bg-white border-slate-200">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {bookSizes.map(size => (
                                                        <SelectItem key={size.id} value={size.id}>
                                                            <div className="flex flex-col">
                                                                <span className="font-medium">{size.name}</span>
                                                                <span className="text-xs text-slate-500">{size.description}</span>
                                                            </div>
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">Font Family</Label>
                                            <Select 
                                                value={exportSettings.fontFamily} 
                                                onValueChange={(value) => setExportSettings(prev => ({...prev, fontFamily: value}))}
                                            >
                                                <SelectTrigger className="bg-white border-slate-200">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {fontOptions.map(font => (
                                                        <SelectItem key={font.id} value={font.id}>
                                                            <div className="flex flex-col">
                                                                <span className="font-medium" style={{ fontFamily: font.preview }}>{font.name}</span>
                                                                <span className="text-xs text-slate-500">{font.description}</span>
                                                            </div>
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">
                                                Font Size: <span className="text-indigo-600 font-bold">{exportSettings.fontSize}pt</span>
                                            </Label>
                                            <Slider
                                                value={[exportSettings.fontSize]}
                                                onValueChange={(value) => setExportSettings(prev => ({...prev, fontSize: value[0]}))}
                                                max={18}
                                                min={8}
                                                step={1}
                                                className="w-full"
                                            />
                                            <div className="flex justify-between text-xs text-slate-500">
                                                <span>8pt</span>
                                                <span>18pt</span>
                                            </div>
                                        </div>
                                    </TabsContent>
                                    
                                    <TabsContent value="design" className="space-y-4 mt-6">
                                        <div className="space-y-4">
                                            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                                                <div>
                                                    <Label className="text-sm font-medium">Table of Contents</Label>
                                                    <p className="text-xs text-slate-500">Professional navigation</p>
                                                </div>
                                                <Switch
                                                    checked={exportSettings.includeTableOfContents}
                                                    onCheckedChange={(checked) => setExportSettings(prev => ({...prev, includeTableOfContents: checked}))}
                                                />
                                            </div>
                                            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                                                <div>
                                                    <Label className="text-sm font-medium">Page Numbers</Label>
                                                    <p className="text-xs text-slate-500">Professional pagination</p>
                                                </div>
                                                <Switch
                                                    checked={exportSettings.includePageNumbers}
                                                    onCheckedChange={(checked) => setExportSettings(prev => ({...prev, includePageNumbers: checked}))}
                                                />
                                            </div>
                                            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                                                <div>
                                                    <Label className="text-sm font-medium">Separate Cover</Label>
                                                    <p className="text-xs text-slate-500">Download cover separately</p>
                                                </div>
                                                <Switch
                                                    checked={exportSettings.separateCover}
                                                    onCheckedChange={(checked) => setExportSettings(prev => ({...prev, separateCover: checked}))}
                                                />
                                            </div>
                                        </div>

                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">Custom Title</Label>
                                            <Input
                                                value={exportSettings.customTitle}
                                                onChange={(e) => setExportSettings(prev => ({...prev, customTitle: e.target.value}))}
                                                placeholder={item.title}
                                                className="bg-white border-slate-200"
                                            />
                                        </div>

                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">Subtitle (Optional)</Label>
                                            <Input
                                                value={exportSettings.customSubtitle}
                                                onChange={(e) => setExportSettings(prev => ({...prev, customSubtitle: e.target.value}))}
                                                placeholder="Professional subtitle..."
                                                className="bg-white border-slate-200"
                                            />
                                        </div>

                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">Author Name</Label>
                                            <Input
                                                value={exportSettings.authorName}
                                                onChange={(e) => setExportSettings(prev => ({...prev, authorName: e.target.value}))}
                                                placeholder="Your name"
                                                className="bg-white border-slate-200"
                                            />
                                        </div>
                                    </TabsContent>
                                    
                                    <TabsContent value="cover" className="space-y-4 mt-6">
                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">Cover Style</Label>
                                            <Select 
                                                value={exportSettings.coverStyle} 
                                                onValueChange={(value) => setExportSettings(prev => ({...prev, coverStyle: value}))}
                                            >
                                                <SelectTrigger className="bg-white border-slate-200">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {coverStyles.map(style => (
                                                        <SelectItem key={style.id} value={style.id}>
                                                            <div className="flex items-center gap-3">
                                                                <div 
                                                                    className="w-4 h-4 rounded-full"
                                                                    style={{ backgroundColor: style.colors[0] }}
                                                                />
                                                                <div>
                                                                    <span className="font-medium">{style.name}</span>
                                                                    <p className="text-xs text-slate-500">{style.description}</p>
                                                                </div>
                                                            </div>
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div className="space-y-3">
                                            <Label className="text-sm font-semibold text-slate-700">AI Cover Prompt</Label>
                                            <Textarea
                                                value={exportSettings.coverPrompt}
                                                onChange={(e) => setExportSettings(prev => ({...prev, coverPrompt: e.target.value}))}
                                                placeholder="Describe your ideal cover design..."
                                                rows={3}
                                                className="bg-white border-slate-200"
                                            />
                                        </div>

                                        <Button
                                            onClick={generateAICover}
                                            disabled={exportLoading === 'ai-cover'}
                                            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all"
                                        >
                                            {exportLoading === 'ai-cover' ? (
                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            ) : (
                                                <Palette className="w-4 h-4 mr-2" />
                                            )}
                                            Generate AI Cover
                                        </Button>
                                    </TabsContent>
                                </Tabs>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Main Content Area */}
                    <div className="lg:col-span-3 space-y-8">
                        {/* Cover Preview Section */}
                        <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                                        <Eye className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                        <span className="text-xl font-bold">Cover Preview</span>
                                        <p className="text-sm text-slate-500 font-normal">See how your cover will look</p>
                                    </div>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-col lg:flex-row gap-8 items-center">
                                    <div className="flex flex-col items-center space-y-4">
                                        <h3 className="text-lg font-semibold text-slate-800">Style Preview</h3>
                                        <CoverPreview 
                                            preview={coverPreview} 
                                            size={bookSizes.find(s => s.id === exportSettings.bookSize)}
                                        />
                                        <Badge variant="outline" className="bg-white text-slate-600">
                                            {coverStyles.find(s => s.id === exportSettings.coverStyle)?.name}
                                        </Badge>
                                    </div>
                                    
                                    {generatedCoverUrl && (
                                        <div className="flex flex-col items-center space-y-4">
                                            <div className="flex items-center gap-2">
                                                <h3 className="text-lg font-semibold text-slate-800">AI Generated Cover</h3>
                                                <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                                                    ✨ AI Created
                                                </Badge>
                                            </div>
                                            <CoverPreview 
                                                preview={coverPreview} 
                                                size={bookSizes.find(s => s.id === exportSettings.bookSize)}
                                                isAI={true}
                                                url={generatedCoverUrl}
                                            />
                                            <Button
                                                onClick={() => downloadCover(generatedCoverUrl, `${(exportSettings.customTitle || item.title).replace(/[^a-z0-9]/gi, '_').toLowerCase()}_cover.png`)}
                                                variant="outline"
                                                className="bg-white hover:bg-slate-50"
                                            >
                                                <DownloadIcon className="w-4 h-4 mr-2" />
                                                Download Cover
                                            </Button>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Export Options */}
                        <div className="grid md:grid-cols-2 gap-6">
                            {/* Standard Exports */}
                            <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3">
                                        <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                                            <Download className="w-4 h-4 text-white" />
                                        </div>
                                        Standard Formats
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <Button
                                        onClick={() => exportContent('pdf')}
                                        className="w-full h-16 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white shadow-lg hover:shadow-xl transition-all"
                                        disabled={exportLoading === 'pdf'}
                                    >
                                        {exportLoading === 'pdf' ? (
                                            <Loader2 className="w-5 h-5 mr-3 animate-spin" />
                                        ) : (
                                            <FileText className="w-5 h-5 mr-3" />
                                        )}
                                        <div className="text-left">
                                            <div className="font-semibold">Export as PDF</div>
                                            <div className="text-xs opacity-90">Professional formatting</div>
                                        </div>
                                    </Button>
                                    
                                    <Button
                                        onClick={() => exportContent('word')}
                                        className="w-full h-16 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg hover:shadow-xl transition-all"
                                        disabled={exportLoading === 'word'}
                                    >
                                        {exportLoading === 'word' ? (
                                            <Loader2 className="w-5 h-5 mr-3 animate-spin" />
                                        ) : (
                                            <FileText className="w-5 h-5 mr-3" />
                                        )}
                                        <div className="text-left">
                                            <div className="font-semibold">Export as Word</div>
                                            <div className="text-xs opacity-90">Editable document</div>
                                        </div>
                                    </Button>
                                </CardContent>
                            </Card>

                            {/* Professional Publishing */}
                            <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200 shadow-xl">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3 text-amber-800">
                                        <div className="w-8 h-8 bg-gradient-to-r from-amber-600 to-orange-600 rounded-lg flex items-center justify-center">
                                            <BookOpen className="w-4 h-4 text-white" />
                                        </div>
                                        Amazon KDP Publishing
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="bg-amber-100/80 backdrop-blur-sm p-4 rounded-lg mb-4">
                                        <div className="flex items-center gap-2 mb-3">
                                            <CheckCircle className="w-5 h-5 text-amber-600" />
                                            <span className="font-semibold text-amber-800">Print-Ready Requirements</span>
                                        </div>
                                        <div className="grid grid-cols-2 gap-3 text-sm text-amber-700">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3" />
                                                <span>{bookSizes.find(s => s.id === exportSettings.bookSize)?.name} trim</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3" />
                                                <span>Professional margins</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3" />
                                                <span>Embedded fonts</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3" />
                                                <span>300 DPI ready</span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <Button
                                        onClick={() => exportContent('kdp')}
                                        className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white h-16 shadow-lg hover:shadow-xl transition-all"
                                        disabled={exportLoading === 'kdp'}
                                    >
                                        {exportLoading === 'kdp' ? (
                                            <Loader2 className="w-5 h-5 mr-3 animate-spin" />
                                        ) : (
                                            <BookOpen className="w-5 h-5 mr-3" />
                                        )}
                                        <div className="text-left">
                                            <div className="font-semibold">Export for Amazon KDP</div>
                                            <div className="text-xs opacity-90">Print-ready with separate cover</div>
                                        </div>
                                    </Button>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Test Export (for flashcards) */}
                        {type === 'flashcards' && testSessions.length > 0 && (
                            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 shadow-xl">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3 text-green-800">
                                        <div className="w-8 h-8 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg flex items-center justify-center">
                                            <FileText className="w-4 h-4 text-white" />
                                        </div>
                                        Test Results Export
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-green-700 mb-4">Export your latest test results and performance analytics</p>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <Button
                                            onClick={() => exportTest('pdf')}
                                            className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-xl transition-all"
                                            disabled={exportLoading === 'test-pdf'}
                                        >
                                            {exportLoading === 'test-pdf' ? (
                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            ) : (
                                                <FileText className="w-4 h-4 mr-2" />
                                            )}
                                            Test Results PDF
                                        </Button>
                                        <Button
                                            onClick={() => exportTest('word')}
                                            className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-xl transition-all"
                                            disabled={exportLoading === 'test-word'}
                                        >
                                            {exportLoading === 'test-word' ? (
                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            ) : (
                                                <FileText className="w-4 h-4 mr-2" />
                                            )}
                                            Test Results Word
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
