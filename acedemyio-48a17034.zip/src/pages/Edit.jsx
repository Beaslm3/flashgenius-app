import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { FlashcardSet, Flashcard } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Plus, Trash2, Edit3 } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function EditPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const setId = searchParams.get('set');

  const [flashcardSet, setFlashcardSet] = useState(null);
  const [flashcards, setFlashcards] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!setId) {
      navigate(createPageUrl("Dashboard"));
      return;
    }
    loadData();
  }, [setId, navigate]);

  const loadData = async () => {
    try {
      const set = await FlashcardSet.get(setId);
      const cards = await Flashcard.filter({ set_id: setId }, "order_index");
      setFlashcardSet(set);
      setFlashcards(cards);
    } catch (error) {
      console.error("Error loading data:", error);
      navigate(createPageUrl("Dashboard"));
    }
    setIsLoading(false);
  };

  const handleSetChange = (field, value) => {
    setFlashcardSet(prev => ({ ...prev, [field]: value }));
  };

  const handleCardChange = (index, field, value) => {
    setFlashcards(prev => prev.map((card, i) => 
      i === index ? { ...card, [field]: value } : card
    ));
  };

  const addNewCard = () => {
    const newCard = {
      set_id: setId,
      question: "",
      answer: "",
      explanation: "",
      difficulty: "medium",
      order_index: flashcards.length
    };
    setFlashcards(prev => [...prev, newCard]);
  };

  const deleteCard = async (index) => {
    const card = flashcards[index];
    
    // If card has an ID, delete from database
    if (card.id) {
      try {
        await Flashcard.delete(card.id);
      } catch (error) {
        console.warn("Could not delete card from database:", error.message);
        // Continue anyway - remove from local state
      }
    }
    
    // Remove from local state
    setFlashcards(prev => prev.filter((_, i) => i !== index));
  };

  const saveChanges = async () => {
    setIsSaving(true);
    try {
      // Update the flashcard set
      await FlashcardSet.update(setId, {
        title: flashcardSet.title,
        subject: flashcardSet.subject,
        description: flashcardSet.description,
        difficulty: flashcardSet.difficulty
      });

      // Update or create flashcards
      for (let i = 0; i < flashcards.length; i++) {
        const card = { ...flashcards[i], order_index: i };
        
        if (card.id) {
          // Update existing card
          try {
            await Flashcard.update(card.id, {
              question: card.question,
              answer: card.answer,
              explanation: card.explanation,
              difficulty: card.difficulty,
              order_index: card.order_index
            });
          } catch (error) {
            console.warn("Could not update card:", error.message);
          }
        } else {
          // Create new card
          try {
            await Flashcard.create(card);
          } catch (error) {
            console.warn("Could not create card:", error.message);
          }
        }
      }

      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      console.error("Error saving changes:", error);
      alert("Failed to save changes. Please try again.");
    }
    setIsSaving(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-1/3 mb-8"></div>
            <div className="space-y-4">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="h-32 bg-slate-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!flashcardSet) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">Flashcard Set Not Found</h1>
          <Button onClick={() => navigate(createPageUrl("Dashboard"))}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="bg-white/80 backdrop-blur-sm"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Edit Flashcard Set</h1>
              <p className="text-slate-600 mt-1">Make changes to your flashcards</p>
            </div>
          </div>
          <Button
            onClick={saveChanges}
            disabled={isSaving}
            className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
          >
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </div>

        {/* Set Details */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-8">
          <CardHeader>
            <CardTitle>Set Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Title</label>
              <Input
                value={flashcardSet.title}
                onChange={(e) => handleSetChange('title', e.target.value)}
                placeholder="Set title"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Subject</label>
              <Input
                value={flashcardSet.subject}
                onChange={(e) => handleSetChange('subject', e.target.value)}
                placeholder="Subject"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Description</label>
              <Textarea
                value={flashcardSet.description}
                onChange={(e) => handleSetChange('description', e.target.value)}
                placeholder="Description"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Flashcards */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-900">Flashcards ({flashcards.length})</h2>
            <Button onClick={addNewCard} variant="outline" className="bg-white/80 backdrop-blur-sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Card
            </Button>
          </div>

          {flashcards.map((card, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Card {index + 1}</CardTitle>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => deleteCard(index)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Question</label>
                  <Textarea
                    value={card.question}
                    onChange={(e) => handleCardChange(index, 'question', e.target.value)}
                    placeholder="Enter the question"
                    rows={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Answer</label>
                  <Textarea
                    value={card.answer}
                    onChange={(e) => handleCardChange(index, 'answer', e.target.value)}
                    placeholder="Enter the answer"
                    rows={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Explanation (Optional)</label>
                  <Textarea
                    value={card.explanation}
                    onChange={(e) => handleCardChange(index, 'explanation', e.target.value)}
                    placeholder="Additional explanation or context"
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>
          ))}

          {flashcards.length === 0 && (
            <Card className="bg-white/80 backdrop-blur-sm text-center p-12">
              <Edit3 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-600 mb-2">No Flashcards Yet</h3>
              <p className="text-slate-500 mb-6">Add your first flashcard to get started!</p>
              <Button onClick={addNewCard} className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                <Plus className="w-4 h-4 mr-2" />
                Add First Card
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}