import React, { useState } from "react";
import { FlashcardSet, Flashcard } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Plus, Trash2, Send, Eye, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function ManualCreate() {
    const navigate = useNavigate();
    const [setInfo, setSetInfo] = useState({
        title: "",
        subject: "",
        description: "",
        difficulty: "intermediate",
        tags: []
    });
    const [flashcards, setFlashcards] = useState([
        { question: "", answer: "", explanation: "" }
    ]);
    const [isCreating, setIsCreating] = useState(false);
    const [createdSet, setCreatedSet] = useState(null);
    const [shareEmails, setShareEmails] = useState("");

    const addFlashcard = () => {
        setFlashcards([...flashcards, { question: "", answer: "", explanation: "" }]);
    };

    const removeFlashcard = (index) => {
        if (flashcards.length > 1) {
            setFlashcards(flashcards.filter((_, i) => i !== index));
        }
    };

    const updateFlashcard = (index, field, value) => {
        const updated = flashcards.map((card, i) => 
            i === index ? { ...card, [field]: value } : card
        );
        setFlashcards(updated);
    };

    const handleTagsChange = (value) => {
        setSetInfo(prev => ({
            ...prev,
            tags: value.split(",").map(tag => tag.trim()).filter(tag => tag)
        }));
    };

    const handleCreateSet = async () => {
        if (!setInfo.title || !setInfo.subject) {
            alert("Please fill in the title and subject.");
            return;
        }

        const validCards = flashcards.filter(card => card.question.trim() && card.answer.trim());
        if (validCards.length === 0) {
            alert("Please create at least one flashcard with question and answer.");
            return;
        }

        setIsCreating(true);
        try {
            // Create the flashcard set
            const newSet = await FlashcardSet.create({
                ...setInfo,
                source_type: 'manual'
            });

            // Create the flashcards
            const cardsToCreate = validCards.map((card, index) => ({
                set_id: newSet.id,
                question: card.question,
                answer: card.answer,
                explanation: card.explanation || "",
                difficulty: "medium",
                order_index: index
            }));

            await Flashcard.bulkCreate(cardsToCreate);
            setCreatedSet({ ...newSet, flashcards: cardsToCreate });
        } catch (error) {
            console.error("Error creating flashcard set:", error);
            alert("Failed to create flashcard set. Please try again.");
        } finally {
            setIsCreating(false);
        }
    };

    const handleShareSet = async () => {
        if (!shareEmails.trim()) {
            alert("Please enter email addresses to share with.");
            return;
        }

        const emails = shareEmails.split(",").map(email => email.trim()).filter(email => email);
        
        // Here you would implement the sharing functionality
        // For now, we'll just show a success message
        alert(`Flashcard set shared with: ${emails.join(", ")}`);
        setShareEmails("");
    };

    if (createdSet) {
        return (
            <div className="p-6 max-w-4xl mx-auto">
                <div className="flex items-center gap-4 mb-8">
                    <Button variant="outline" size="icon" onClick={() => setCreatedSet(null)}>
                        <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">Flashcard Set Created!</h1>
                        <p className="text-slate-600 mt-1">Your flashcard set is ready to use and share</p>
                    </div>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>{createdSet.title}</CardTitle>
                        <p className="text-slate-600">{createdSet.description}</p>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-3 gap-4 mb-6">
                            <div className="bg-blue-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-blue-900">Subject</h3>
                                <p className="text-blue-700">{createdSet.subject}</p>
                            </div>
                            <div className="bg-green-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-green-900">Cards</h3>
                                <p className="text-green-700">{createdSet.flashcards.length} flashcards</p>
                            </div>
                            <div className="bg-purple-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-purple-900">Difficulty</h3>
                                <p className="text-purple-700 capitalize">{createdSet.difficulty}</p>
                            </div>
                        </div>

                        {/* Share Section */}
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
                            <h3 className="font-semibold text-amber-900 mb-3 flex items-center gap-2">
                                <Users className="w-5 h-5" />
                                Share with Students or Colleagues
                            </h3>
                            <div className="flex gap-3">
                                <Input
                                    placeholder="Enter email addresses (comma-separated)"
                                    value={shareEmails}
                                    onChange={(e) => setShareEmails(e.target.value)}
                                    className="flex-1"
                                />
                                <Button 
                                    onClick={handleShareSet}
                                    disabled={!shareEmails.trim()}
                                    className="bg-amber-600 hover:bg-amber-700"
                                >
                                    <Send className="w-4 h-4 mr-2" />
                                    Share
                                </Button>
                            </div>
                        </div>

                        {/* Preview Cards */}
                        <div className="mb-6">
                            <h3 className="font-semibold text-slate-900 mb-3">Preview Flashcards</h3>
                            <div className="space-y-3 max-h-96 overflow-y-auto">
                                {createdSet.flashcards.slice(0, 5).map((card, index) => (
                                    <div key={index} className="bg-white border rounded-lg p-4">
                                        <div className="font-medium text-blue-600 mb-2">Q: {card.question}</div>
                                        <div className="text-gray-700 mb-2">A: {card.answer}</div>
                                        {card.explanation && (
                                            <div className="text-sm text-gray-600">
                                                <strong>Explanation:</strong> {card.explanation}
                                            </div>
                                        )}
                                    </div>
                                ))}
                                {createdSet.flashcards.length > 5 && (
                                    <p className="text-sm text-gray-500 text-center">
                                        ... and {createdSet.flashcards.length - 5} more cards
                                    </p>
                                )}
                            </div>
                        </div>

                        <div className="flex gap-3">
                            <Button 
                                onClick={() => navigate(createPageUrl(`Study?set=${createdSet.id}`))}
                                className="bg-blue-600 hover:bg-blue-700"
                            >
                                <Eye className="w-4 h-4 mr-2" />
                                Study Now
                            </Button>
                            <Button 
                                onClick={() => navigate(createPageUrl(`Test?set=${createdSet.id}`))}
                                className="bg-green-600 hover:bg-green-700"
                            >
                                Take Test
                            </Button>
                            <Button 
                                onClick={() => navigate(createPageUrl(`Export?type=flashcards&id=${createdSet.id}`))}
                                variant="outline"
                            >
                                Export
                            </Button>
                            <Button 
                                onClick={() => navigate(createPageUrl("Dashboard"))}
                                variant="outline"
                            >
                                Back to Dashboard
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-8">
                <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Dashboard"))}>
                    <ArrowLeft className="w-4 h-4" />
                </Button>
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Create Flashcards Manually</h1>
                    <p className="text-slate-600 mt-1">Design your own custom flashcard set</p>
                </div>
            </div>

            <div className="grid gap-6">
                {/* Set Information */}
                <Card>
                    <CardHeader>
                        <CardTitle>Flashcard Set Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="title">Title *</Label>
                                <Input
                                    id="title"
                                    placeholder="e.g., Spanish Vocabulary"
                                    value={setInfo.title}
                                    onChange={(e) => setSetInfo(prev => ({ ...prev, title: e.target.value }))}
                                    className="bg-white/80"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="subject">Subject *</Label>
                                <Input
                                    id="subject"
                                    placeholder="e.g., Spanish, Biology, History"
                                    value={setInfo.subject}
                                    onChange={(e) => setSetInfo(prev => ({ ...prev, subject: e.target.value }))}
                                    className="bg-white/80"
                                />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="description">Description</Label>
                            <Textarea
                                id="description"
                                placeholder="Describe what this flashcard set covers"
                                value={setInfo.description}
                                onChange={(e) => setSetInfo(prev => ({ ...prev, description: e.target.value }))}
                                className="bg-white/80"
                                rows={3}
                            />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label>Difficulty Level</Label>
                                <Select
                                    value={setInfo.difficulty}
                                    onValueChange={(value) => setSetInfo(prev => ({ ...prev, difficulty: value }))}
                                >
                                    <SelectTrigger className="bg-white/80">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="beginner">Beginner</SelectItem>
                                        <SelectItem value="intermediate">Intermediate</SelectItem>
                                        <SelectItem value="advanced">Advanced</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="tags">Tags (comma-separated)</Label>
                                <Input
                                    id="tags"
                                    placeholder="e.g., exam prep, vocabulary, review"
                                    onChange={(e) => handleTagsChange(e.target.value)}
                                    className="bg-white/80"
                                />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Flashcards */}
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Flashcards ({flashcards.length})</CardTitle>
                        <Button onClick={addFlashcard} size="sm" className="bg-green-600 hover:bg-green-700">
                            <Plus className="w-4 h-4 mr-2" />
                            Add Card
                        </Button>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            <AnimatePresence>
                                {flashcards.map((card, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -20 }}
                                        className="border rounded-lg p-4 bg-white/50"
                                    >
                                        <div className="flex items-center justify-between mb-3">
                                            <h4 className="font-medium text-slate-900">Card {index + 1}</h4>
                                            {flashcards.length > 1 && (
                                                <Button
                                                    onClick={() => removeFlashcard(index)}
                                                    variant="ghost"
                                                    size="sm"
                                                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            )}
                                        </div>
                                        <div className="space-y-3">
                                            <div className="space-y-2">
                                                <Label>Question *</Label>
                                                <Textarea
                                                    placeholder="Enter the question or term"
                                                    value={card.question}
                                                    onChange={(e) => updateFlashcard(index, 'question', e.target.value)}
                                                    rows={2}
                                                    className="bg-white/80"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Answer *</Label>
                                                <Textarea
                                                    placeholder="Enter the answer or definition"
                                                    value={card.answer}
                                                    onChange={(e) => updateFlashcard(index, 'answer', e.target.value)}
                                                    rows={2}
                                                    className="bg-white/80"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Explanation (Optional)</Label>
                                                <Textarea
                                                    placeholder="Add additional context or explanation"
                                                    value={card.explanation}
                                                    onChange={(e) => updateFlashcard(index, 'explanation', e.target.value)}
                                                    rows={2}
                                                    className="bg-white/80"
                                                />
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>
                    </CardContent>
                </Card>

                {/* Create Button */}
                <Button
                    onClick={handleCreateSet}
                    disabled={isCreating || !setInfo.title || !setInfo.subject}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all"
                    size="lg"
                >
                    {isCreating ? (
                        <>
                            <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                                className="w-5 h-5 mr-2 border-2 border-white border-t-transparent rounded-full"
                            />
                            Creating Flashcard Set...
                        </>
                    ) : (
                        <>
                            <Plus className="w-5 h-5 mr-2" />
                            Create Flashcard Set
                        </>
                    )}
                </Button>
            </div>
        </div>
    );
}