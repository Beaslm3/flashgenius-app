import React, { useState, useEffect } from 'react';
import { User, Course, Assignment } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Edit, 
  Camera, 
  MapPin, 
  Calendar, 
  Mail, 
  Phone, 
  BookOpen, 
  Users, 
  Award, 
  TrendingUp,
  Star,
  MessageCircle,
  Share2,
  Plus,
  Settings,
  Save,
  Upload
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [editData, setEditData] = useState({});

  useEffect(() => {
    loadProfileData();
  }, []);

  const loadProfileData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setEditData({
        bio: currentUser.bio || '',
        location: currentUser.location || '',
        phone: currentUser.phone || '',
        website: currentUser.website || '',
        skills: currentUser.skills || [],
        experience: currentUser.experience || '',
        education: currentUser.education || '',
        hourly_rate: currentUser.hourly_rate || 0,
        teaching_subjects: currentUser.teaching_subjects || []
      });

      // Load user's content
      const [userCourses, userAssignments] = await Promise.all([
        Course.filter({ created_by: currentUser.email }, '-created_date', 6),
        Assignment.filter({ teacher_id: currentUser.id }, '-created_date', 6)
      ]);
      
      setCourses(userCourses);
      setAssignments(userAssignments);
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    try {
      await User.updateMyUserData(editData);
      setUser({ ...user, ...editData });
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving profile:', error);
      alert('Failed to save profile. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const { file_url } = await UploadFile({ file });
      await User.updateMyUserData({ profile_picture_url: file_url });
      setUser({ ...user, profile_picture_url: file_url });
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Failed to upload image. Please try again.');
    }
  };

  const stats = {
    courses: courses.length,
    students: courses.reduce((acc, course) => acc + (course.enrolled_count || 0), 0),
    rating: 4.8,
    reviews: 127
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Cover & Profile Header */}
      <div className="relative">
        <div className="h-64 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
        <div className="absolute inset-0 bg-black/20"></div>
        
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-start md:items-end gap-6">
              <div className="relative">
                <Avatar className="w-32 h-32 border-4 border-white shadow-xl">
                  <AvatarImage src={user?.profile_picture_url} alt={user?.full_name} />
                  <AvatarFallback className="text-4xl font-bold bg-indigo-600 text-white">
                    {user?.full_name?.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="avatar-upload"
                />
                <label
                  htmlFor="avatar-upload"
                  className="absolute bottom-2 right-2 bg-white rounded-full p-2 shadow-lg cursor-pointer hover:bg-gray-50"
                >
                  <Camera className="w-4 h-4 text-gray-600" />
                </label>
              </div>
              
              <div className="flex-1 text-white">
                <h1 className="text-3xl font-bold mb-2">{user?.full_name}</h1>
                <p className="text-xl opacity-90 capitalize mb-2">{user?.role}</p>
                <div className="flex flex-wrap gap-4 text-sm opacity-75">
                  {user?.location && (
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {user.location}
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Joined {new Date(user?.created_date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                  </div>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Button
                  onClick={() => setIsEditing(!isEditing)}
                  variant={isEditing ? "secondary" : "default"}
                  className="bg-white text-gray-900 hover:bg-gray-100"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  {isEditing ? 'Cancel' : 'Edit Profile'}
                </Button>
                <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-6 -mt-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Sidebar */}
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="text-center">
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-indigo-600">{stats.courses}</div>
                  <div className="text-sm text-gray-600">Courses</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-600">{stats.students}</div>
                  <div className="text-sm text-gray-600">Students</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-4">
                  <div className="flex items-center justify-center gap-1">
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <span className="text-2xl font-bold">{stats.rating}</span>
                  </div>
                  <div className="text-sm text-gray-600">Rating</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-purple-600">{stats.reviews}</div>
                  <div className="text-sm text-gray-600">Reviews</div>
                </CardContent>
              </Card>
            </div>

            {/* About Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  About
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isEditing ? (
                  <div className="space-y-4">
                    <Textarea
                      placeholder="Tell us about yourself..."
                      value={editData.bio}
                      onChange={(e) => setEditData({...editData, bio: e.target.value})}
                      rows={4}
                    />
                    <Input
                      placeholder="Location"
                      value={editData.location}
                      onChange={(e) => setEditData({...editData, location: e.target.value})}
                    />
                    <Input
                      placeholder="Phone"
                      value={editData.phone}
                      onChange={(e) => setEditData({...editData, phone: e.target.value})}
                    />
                    <Input
                      placeholder="Website"
                      value={editData.website}
                      onChange={(e) => setEditData({...editData, website: e.target.value})}
                    />
                    {user?.role === 'teacher' && (
                      <Input
                        type="number"
                        placeholder="Hourly Rate ($)"
                        value={editData.hourly_rate}
                        onChange={(e) => setEditData({...editData, hourly_rate: Number(e.target.value)})}
                      />
                    )}
                    <Button onClick={handleSaveProfile} disabled={isSaving} className="w-full">
                      <Save className="w-4 h-4 mr-2" />
                      {isSaving ? 'Saving...' : 'Save Changes'}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-gray-700 leading-relaxed">
                      {user?.bio || 'No bio available. Edit your profile to add a description about yourself.'}
                    </p>
                    <div className="space-y-2 text-sm">
                      {user?.location && (
                        <div className="flex items-center gap-2 text-gray-600">
                          <MapPin className="w-4 h-4" />
                          {user.location}
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="w-4 h-4" />
                        {user?.email}
                      </div>
                      {user?.phone && (
                        <div className="flex items-center gap-2 text-gray-600">
                          <Phone className="w-4 h-4" />
                          {user.phone}
                        </div>
                      )}
                      {user?.role === 'teacher' && user?.hourly_rate && (
                        <div className="flex items-center gap-2 text-green-600 font-semibold">
                          <TrendingUp className="w-4 h-4" />
                          ${user.hourly_rate}/hour
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Skills Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  Skills & Expertise
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isEditing ? (
                  <Input
                    placeholder="Enter skills separated by commas"
                    value={Array.isArray(editData.skills) ? editData.skills.join(', ') : ''}
                    onChange={(e) => setEditData({...editData, skills: e.target.value.split(',').map(s => s.trim())})}
                  />
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {(user?.skills || ['JavaScript', 'Python', 'Teaching', 'Mathematics']).map((skill, index) => (
                      <Badge key={index} variant="secondary">{skill}</Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="courses" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="courses">My Courses</TabsTrigger>
                <TabsTrigger value="assignments">Assignments</TabsTrigger>
                <TabsTrigger value="activity">Activity</TabsTrigger>
              </TabsList>

              <TabsContent value="courses">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-semibold">My Courses ({courses.length})</h2>
                    <Button onClick={() => navigate(createPageUrl('CourseBuilder'))}>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Course
                    </Button>
                  </div>
                  
                  <div className="grid gap-4">
                    {courses.map((course, index) => (
                      <motion.div
                        key={course.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Card className="hover:shadow-lg transition-shadow cursor-pointer"
                              onClick={() => navigate(createPageUrl(`CourseViewer?id=${course.id}`))}>
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-4">
                              <div className="flex-1">
                                <h3 className="font-semibold text-lg mb-2">{course.title}</h3>
                                <p className="text-gray-600 mb-3">
                                  {course.meta_description || `A comprehensive course on ${course.subject}`}
                                </p>
                                <div className="flex gap-2 mb-3">
                                  <Badge>{course.subject}</Badge>
                                  <Badge variant="outline">{course.level}</Badge>
                                  <Badge variant="outline">{course.language}</Badge>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="flex items-center gap-1 mb-1">
                                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                                  <span className="text-sm">4.8</span>
                                </div>
                                <div className="text-sm text-gray-600">
                                  {Math.floor(Math.random() * 500) + 100} students
                                </div>
                              </div>
                            </div>
                            <div className="flex justify-between items-center text-sm text-gray-500">
                              <span>Created {new Date(course.created_date).toLocaleDateString()}</span>
                              <div className="flex gap-4">
                                <span className="flex items-center gap-1">
                                  <BookOpen className="w-4 h-4" />
                                  {course.syllabus?.length || 0} modules
                                </span>
                                <span className="flex items-center gap-1">
                                  <MessageCircle className="w-4 h-4" />
                                  {Math.floor(Math.random() * 50) + 5} reviews
                                </span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                    
                    {courses.length === 0 && (
                      <Card className="text-center py-12">
                        <CardContent>
                          <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                          <h3 className="text-lg font-semibold text-gray-700 mb-2">No courses yet</h3>
                          <p className="text-gray-500 mb-4">Start creating engaging courses for your students</p>
                          <Button onClick={() => navigate(createPageUrl('CourseBuilder'))}>
                            <Plus className="w-4 h-4 mr-2" />
                            Create Your First Course
                          </Button>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="assignments">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-semibold">My Assignments ({assignments.length})</h2>
                    <Button onClick={() => navigate(createPageUrl('CreateAssignment'))}>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Assignment
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    {assignments.map((assignment, index) => (
                      <Card key={assignment.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold mb-1">{assignment.title}</h3>
                              <p className="text-gray-600 text-sm mb-2">{assignment.description}</p>
                              <div className="text-xs text-gray-500">
                                Due: {new Date(assignment.due_date).toLocaleDateString()}
                              </div>
                            </div>
                            <Badge variant="outline">
                              {Math.floor(Math.random() * 30) + 5} submissions
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    
                    {assignments.length === 0 && (
                      <Card className="text-center py-8">
                        <CardContent>
                          <h3 className="text-lg font-semibold text-gray-700 mb-2">No assignments yet</h3>
                          <p className="text-gray-500">Create assignments to engage your students</p>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4 p-3 bg-blue-50 rounded-lg">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <div>
                          <p className="text-sm">Created a new course: "Advanced JavaScript"</p>
                          <p className="text-xs text-gray-500">2 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 bg-green-50 rounded-lg">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div>
                          <p className="text-sm">Received 5-star review from Maria Garcia</p>
                          <p className="text-xs text-gray-500">1 day ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 bg-purple-50 rounded-lg">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <div>
                          <p className="text-sm">Updated profile information</p>
                          <p className="text-xs text-gray-500">3 days ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}