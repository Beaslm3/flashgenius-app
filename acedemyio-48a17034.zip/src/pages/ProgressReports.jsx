import React, { useState, useEffect } from "react";
import { User, ProgressReport, Achievement, Course, FlashcardSet, Flashcard } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  Star, 
  Award, 
  Brain, 
  Lightbulb, 
  BookOpen,
  Plus,
  Sparkles,
  Crown,
  Medal,
  Zap,
  CheckCircle,
  AlertCircle,
  Loader2,
  MoreVertical,
  Trash2,
  ThumbsUp,
  ThumbsDown,
  ChevronsRight
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const gradeColors = {
  "A+": "bg-emerald-100 text-emerald-800 border-emerald-200", "A": "bg-emerald-100 text-emerald-800 border-emerald-200", "A-": "bg-emerald-100 text-emerald-800 border-emerald-200",
  "B+": "bg-blue-100 text-blue-800 border-blue-200", "B": "bg-blue-100 text-blue-800 border-blue-200", "B-": "bg-blue-100 text-blue-800 border-blue-200",
  "C+": "bg-yellow-100 text-yellow-800 border-yellow-200", "C": "bg-yellow-100 text-yellow-800 border-yellow-200", "C-": "bg-yellow-100 text-yellow-800 border-yellow-200",
  "D": "bg-orange-100 text-orange-800 border-orange-200", "F": "bg-red-100 text-red-800 border-red-200"
};

const masteryLevels = {
  beginner: { icon: BookOpen, color: "text-blue-600", bg: "bg-blue-50" },
  intermediate: { icon: Target, color: "text-amber-600", bg: "bg-amber-50" },
  advanced: { icon: Crown, color: "text-purple-600", bg: "bg-purple-50" },
  expert: { icon: Trophy, color: "text-emerald-600", bg: "bg-emerald-50" }
};

const ReportCard = ({ report, onViewDetails, onDelete }) => {
  const MasteryIcon = masteryLevels[report.mastery_level]?.icon || BookOpen;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} whileHover={{ scale: 1.02 }}
      className="group"
    >
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 h-full flex flex-col">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1 cursor-pointer" onClick={() => onViewDetails(report)}>
              <h3 className="font-bold text-lg text-gray-900 mb-2 truncate">{report.topic}</h3>
              <div className="flex items-center gap-3">
                <Badge className={`${gradeColors[report.grade]} font-bold text-lg px-3 py-1`}>{report.grade}</Badge>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${masteryLevels[report.mastery_level]?.bg}`}>
                  <MasteryIcon className={`w-4 h-4 ${masteryLevels[report.mastery_level]?.color}`} />
                  <span className={`text-sm font-medium capitalize ${masteryLevels[report.mastery_level]?.color}`}>{report.mastery_level}</span>
                </div>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => onDelete(report.id)} className="text-red-600 focus:text-red-600"><Trash2 className="w-4 h-4 mr-2" />Delete Report</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent className="flex-grow cursor-pointer" onClick={() => onViewDetails(report)}>
          <div className="flex justify-between text-sm mb-1 text-gray-600"><span>Overall Progress</span><span className="font-medium text-gray-800">{report.overall_score}%</span></div>
          <Progress value={report.overall_score} className="h-2 mb-4" />
          <p className="text-sm text-gray-600 line-clamp-2">{report.ai_feedback?.split('\n\n')[0]}</p>
        </CardContent>
        <div className="border-t p-4 flex justify-between items-center bg-slate-50/50 rounded-b-lg">
           <div className="text-right">
                <div className="flex items-center gap-1 text-amber-500"><Star className="w-4 h-4 fill-current" /><span className="font-bold">{report.points_earned} XP</span></div>
                <p className="text-xs text-gray-500">{new Date(report.last_assessment_date).toLocaleDateString()}</p>
            </div>
           <Button onClick={() => onViewDetails(report)} variant="default" size="sm" className="bg-primary hover:bg-primary/90">
             View Pathway <ChevronsRight className="w-4 h-4 ml-1" />
           </Button>
        </div>
      </Card>
    </motion.div>
  );
};

const NewAssessmentForm = ({ onGenerate, isGenerating, error, generationProgress, currentStep }) => {
    const [topic, setTopic] = useState("");
    const [priorLearning, setPriorLearning] = useState("");

    const handleSubmit = () => {
        if (!topic.trim()) return;
        onGenerate(topic, priorLearning);
    };

    if (isGenerating) {
        return (
            <Card className="max-w-2xl mx-auto bg-white/80 backdrop-blur-sm shadow-xl border-0">
                <CardContent className="p-8 text-center">
                  <Sparkles className="w-12 h-12 text-indigo-500 mx-auto mb-4 animate-pulse" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Generating Your Learning Pathway...</h3>
                  <p className="text-slate-600 mb-6">{currentStep}</p>
                  <Progress value={generationProgress} className="w-full" />
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="max-w-2xl mx-auto bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl font-bold">
                    <Plus className="w-6 h-6 text-indigo-600" />
                    Create New Learning Pathway
                </CardTitle>
                <CardDescription>Get a personalized progress report and a full course built by AI.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                {error && (<Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error}</AlertDescription></Alert>)}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Topic to Master <span className="text-red-500">*</span></label>
                  <Input placeholder="e.g., Quantum Physics, Digital Marketing, The Renaissance" value={topic} onChange={(e) => setTopic(e.target.value)} className="bg-white/80 text-base py-6" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Prior Knowledge (Optional)</label>
                  <Textarea placeholder="Describe what you already know, courses you've taken, or text you've read..." value={priorLearning} onChange={(e) => setPriorLearning(e.target.value)} className="bg-white/80 h-32" />
                  <p className="text-xs text-slate-500">Providing context helps the AI create a more accurate and personalized plan.</p>
                </div>
                <Button onClick={handleSubmit} disabled={!topic.trim() || isGenerating} className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200" size="lg">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Generate My Professional Report
                </Button>
            </CardContent>
        </Card>
    );
};

export default function ProgressReportsPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [reports, setReports] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [generationProgress, setGenerationProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState("");

  useEffect(() => {
    const fetchUserAndData = async () => {
      setIsLoading(true);
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        await loadReportsAndAchievements(currentUser);
      } catch (error) {
        navigate(createPageUrl("Home"));
      }
      setIsLoading(false);
    };
    fetchUserAndData();
  }, [navigate]);

  const loadReportsAndAchievements = async (currentUser) => {
    try {
      const [userReports, userAchievements] = await Promise.all([
        ProgressReport.filter({ created_by: currentUser.email }, "-created_date"),
        Achievement.filter({ created_by: currentUser.email }, "-earned_date")
      ]);
      setReports(userReports);
      setAchievements(userAchievements);
    } catch (error) {
      console.error("Error loading reports:", error);
      setError("Could not load your progress data. Please refresh the page.");
    }
  };

  const handleGenerateReport = async (topic, priorLearning) => {
    setIsGenerating(true);
    setError(null);

    try {
        setCurrentStep("Assessing your learning needs...");
        setGenerationProgress(10);
        
        const assessmentPrompt = `You are an expert educator and motivational coach. A student wants a progress report on the topic "${topic}". Their stated prior knowledge is: "${priorLearning || 'Beginner'}".

Generate a comprehensive and encouraging progress report in JSON format. The report must include:
1. "grade": A letter grade (A+, A, B, C, D, F).
2. "overall_score": A number from 0-100.
3. "mastery_level": A string from ["beginner", "intermediate", "advanced", "expert"].
4. "overview": A short, one-paragraph summary of the student's current standing on this topic.
5. "strengths": An array of 3-4 specific strengths or mastered concepts.
6. "areas_for_improvement": An array of 3-4 specific areas or concepts that need more focus.
7. "next_steps": An array of 3 actionable next steps to improve. Each step should be a clear, concise instruction.
8. "motivational_note": A short, encouraging message to the student.
9. "learning_timeline": A suggested timeline for mastering the topic (e.g., "2-3 weeks").`;

        const assessmentResponse = await InvokeLLM({
            prompt: assessmentPrompt,
            response_json_schema: {
                type: "object",
                properties: {
                    grade: { type: "string" }, overall_score: { type: "number" }, mastery_level: { type: "string", enum: ["beginner", "intermediate", "advanced", "expert"] },
                    overview: { type: "string" }, strengths: { type: "array", items: { type: "string" } }, areas_for_improvement: { type: "array", items: { type: "string" } },
                    next_steps: { type: "array", items: { type: "string" } }, motivational_note: { type: "string" }, learning_timeline: { type: "string" }
                },
                required: ["grade", "overall_score", "mastery_level", "overview", "strengths", "areas_for_improvement", "next_steps", "motivational_note"]
            }
        });
        
        setCurrentStep("Building a personalized course curriculum...");
        setGenerationProgress(30);

        const coursePrompt = `Based on the topic "${topic}", create a comprehensive 3-module course syllabus. For each module, provide a title and detailed learning content.`;
        const courseResponse = await InvokeLLM({
            prompt: coursePrompt,
            response_json_schema: {
                type: "object",
                properties: { title: { type: "string" }, description: { type: "string" },
                    modules: { type: "array", items: { type: "object", properties: { module_title: { type: "string" }, content: { type: "string" } }, required: ["module_title", "content"] } }
                }, required: ["title", "description", "modules"]
            }
        });
        
        setCurrentStep("Creating practice quizzes...");
        setGenerationProgress(60);

        const syllabusWithQuizzes = [];
        for (const module of courseResponse.modules) {
            const quizPrompt = `Create a 5-question multiple choice quiz for the module "${module.module_title}" based on its content. Provide a question, an array of 4 options, and the correct answer for each.`;
            const quizResponse = await InvokeLLM({
                prompt: quizPrompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        questions: { type: "array", items: { type: "object", properties: { question: { type: "string" }, options: {type: "array", items: {type: "string"}}, answer: { type: "string" } }, required: ["question", "options", "answer"] } }
                    }, required: ["questions"]
                }
            });

            const newSet = await FlashcardSet.create({ title: `${module.module_title} Quiz`, subject: topic, source_type: 'ai_generated' });
            const flashcards = quizResponse.questions.map((q, i) => ({ question: q.question, answer: q.answer, set_id: newSet.id, order_index: i }));
            await Flashcard.bulkCreate(flashcards);
            syllabusWithQuizzes.push({ module: module.module_title, content: module.content, test_set_id: newSet.id });
        }
        
        setCurrentStep("Finalizing your learning pathway...");
        setGenerationProgress(90);

        const newCourse = await Course.create({ title: courseResponse.title, subject: topic, syllabus: syllabusWithQuizzes, status: 'published' });

        const reportData = {
            ...assessmentResponse,
            topic: topic, points_earned: 50, sessions_completed: 0, status: 'in_progress',
            last_assessment_date: new Date().toISOString(),
            course_id: newCourse.id,
            next_milestone: assessmentResponse.next_steps.join('\n'),
            ai_feedback: `${assessmentResponse.overview}\n\n${assessmentResponse.motivational_note}`
        };
        await ProgressReport.create(reportData);

        await loadReportsAndAchievements(user);
        setActiveTab("overview");

    } catch (err) {
        console.error("Error generating report:", err);
        setError("Failed to create learning pathway. The AI may be experiencing high load. Please try again.");
    } finally {
        setIsGenerating(false);
    }
  };

  const handleViewDetails = (report) => {
    if (report.course_id) {
        navigate(createPageUrl(`CourseViewer?id=${report.course_id}`));
    } else {
        alert("This progress report does not have an associated learning course.");
    }
  };

  const handleDeleteReport = async (reportId) => {
    try {
        await ProgressReport.delete(reportId);
        await loadReportsAndAchievements(user);
    } catch (error) {
        console.error("Error deleting report:", error);
        setError("Failed to delete report. Please try again.");
    }
  };
  
  if (isLoading) {
    return (<div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-indigo-600" /></div>);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">My Learning Pathways</h1>
          <p className="text-slate-600">Generate personalized reports and courses to track your mastery and accelerate growth.</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm shadow-sm p-1 rounded-lg">
            <TabsTrigger value="overview">My Pathways</TabsTrigger>
            <TabsTrigger value="new-assessment">New Pathway</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-8">
            {reports.length === 0 && !isGenerating ? (
              <div className="text-center py-12"><Brain className="w-16 h-16 text-slate-400 mx-auto mb-4" /><h3 className="text-xl font-semibold text-slate-900 mb-2">No Learning Pathways Yet</h3><p className="text-slate-600 mb-6">Start your journey by creating your first AI-powered assessment and course.</p><Button onClick={() => setActiveTab("new-assessment")} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"><Plus className="w-4 h-4 mr-2" />Generate New Pathway</Button></div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"><AnimatePresence>{reports.map((report) => (<ReportCard key={report.id} report={report} onViewDetails={handleViewDetails} onDelete={(id) => { if (window.confirm("Are you sure you want to delete this report? This cannot be undone.")) { handleDeleteReport(id); } }} />))}</AnimatePresence></div>
            )}
          </TabsContent>

          <TabsContent value="new-assessment" className="mt-8">
            <NewAssessmentForm onGenerate={handleGenerateReport} isGenerating={isGenerating} error={error} generationProgress={generationProgress} currentStep={currentStep} />
          </TabsContent>

          <TabsContent value="achievements" className="mt-8">
            {achievements.length === 0 ? (
              <div className="text-center py-12"><Trophy className="w-16 h-16 text-slate-400 mx-auto mb-4" /><h3 className="text-xl font-semibold text-slate-900 mb-2">No Achievements Unlocked</h3><p className="text-slate-600">Complete learning pathways and master topics to earn badges and XP.</p></div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">{achievements.map((achievement) => (<Card key={achievement.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg"><CardContent className="p-6 text-center"><div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4"><Trophy className="w-8 h-8 text-white" /></div><h3 className="font-bold text-lg text-slate-900 mb-2">{achievement.badge_name}</h3><p className="text-sm text-slate-600 mb-3">{achievement.description}</p><Badge className="bg-amber-100 text-amber-800">+{achievement.points_awarded} XP</Badge></CardContent></Card>))}</div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}