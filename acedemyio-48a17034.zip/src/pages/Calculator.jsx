
import React, { useState, useEffect } from "react";
import { InvokeLLM, UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ArrowLeft, Calculator as CalcIcon, Loader2, Sparkles, Image as ImageIcon, FileText, Upload, Brain, Wand2, Mic, MicOff, Volume2, BarChart2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ReactMarkdown from 'react-markdown';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const mathSubjects = [
    { id: "algebra", name: "Algebra" }, { id: "calculus", name: "Calculus" }, 
    { id: "geometry", name: "Geometry" }, { id: "statistics", name: "Statistics" },
    { id: "trigonometry", name: "Trigonometry" }, { id: "physics", name: "Physics (Formulas)" },
    { id: "chemistry", name: "Chemistry (Formulas)" }
];

const languages = [
    { code: "en", name: "English" }, { code: "es", name: "Español" }, { code: "fr", name: "Français" }, 
    { code: "de", name: "Deutsch" }, { code: "zh", name: "中文" }, { code: "ja", name: "日本語" },
    { code: "ru", name: "Русский" }, { code: "ar", name: "العربية" }
];

export default function Calculator() {
    const navigate = useNavigate();
    const [problem, setProblem] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState(null);
    const [error, setError] = useState(null);
    const [imageFile, setImageFile] = useState(null);
    const [activeTab, setActiveTab] = useState("text");
    const [subject, setSubject] = useState("algebra");
    const [language, setLanguage] = useState("en");

    const [isListening, setIsListening] = useState(false);
    const [recognition, setRecognition] = useState(null);
    
    useEffect(() => {
        if ('webkitSpeechRecognition' in window) {
            const recognitionInstance = new window.webkitSpeechRecognition();
            recognitionInstance.continuous = false;
            recognitionInstance.interimResults = false;
            recognitionInstance.lang = language;
            recognitionInstance.onresult = (event) => setProblem(event.results[0][0].transcript);
            recognitionInstance.onend = () => setIsListening(false);
            setRecognition(recognitionInstance);
        }
    }, [language]);
    
    const toggleListening = () => {
        if (isListening) {
            recognition?.stop();
        } else {
            recognition?.start();
        }
        setIsListening(!isListening);
    };
    
    const speakResult = (text) => {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = language;
            window.speechSynthesis.speak(utterance);
        }
    };
    
    const handleSolve = async () => {
        let contentToSolve = problem;
        let fileUrls = [];

        if (activeTab === 'image' && imageFile) {
            try {
                const uploadResponse = await UploadFile({ file: imageFile });
                fileUrls.push(uploadResponse.file_url);
                contentToSolve = `Problem is in the attached image: ${imageFile.name}`;
            } catch (err) {
                setError("Failed to upload image. Please try again.");
                return;
            }
        } else if (!problem.trim()) {
            setError("Please enter a math problem to solve.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setResult(null);

        try {
            const prompt = `You are MathGPT, an expert AI mathematics tutor. A student needs help with a ${subject} problem.
            The problem is: "${contentToSolve}".
            Your language for explanation MUST be ${languages.find(l => l.code === language)?.name}.

            Please provide a detailed, structured response in JSON format. The JSON object should contain:
            1.  "final_answer": A string with the final, concise answer.
            2.  "step_by_step_solution": An array of objects, where each object has a "step" number and a detailed "explanation" string.
            3.  "key_concepts": An array of strings, listing the key mathematical concepts used.
            4.  "graph_data": If the problem is a function that can be graphed (e.g., y = 2x + 1), provide an array of 20 {x, y} data points for x from -10 to 10. Otherwise, this should be null.
            5.  "practice_problems": An array of 2-3 similar practice problems, each with a "question" and "answer" string.`;
            
            const responseSchema = {
                type: "object",
                properties: {
                    final_answer: { type: "string" },
                    step_by_step_solution: { type: "array", items: { type: "object", properties: { step: { type: "number" }, explanation: { type: "string" } } } },
                    key_concepts: { type: "array", items: { type: "string" } },
                    graph_data: { type: "array", items: { type: "object", properties: { x: { type: "number" }, y: { type: "number" } } } },
                    practice_problems: { type: "array", items: { type: "object", properties: { question: { type: "string" }, answer: { type: "string" } } } }
                },
                required: ["final_answer", "step_by_step_solution", "key_concepts"]
            };

            const response = await InvokeLLM({ prompt, file_urls: fileUrls, response_json_schema: responseSchema });
            setResult(response);
        } catch (err) {
            setError("Failed to solve the problem. The AI may have encountered an issue with this specific problem type. Please try again or rephrase your question.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-4 md:p-8 max-w-6xl mx-auto bg-slate-50 min-h-screen">
            <div className="flex items-center gap-4 mb-6">
                <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Dashboard"))}><ArrowLeft className="w-4 h-4" /></Button>
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">AI Math Tutor</h1>
                    <p className="text-slate-600">Your personal AI-powered math problem solver, inspired by MathGPT.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Input Card */}
                <Card className="shadow-lg">
                    <CardHeader><CardTitle className="flex items-center gap-2"><Wand2 className="w-5 h-5 text-primary" />Enter Your Problem</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                        <Tabs value={activeTab} onValueChange={setActiveTab}>
                            <TabsList className="grid w-full grid-cols-2">
                                <TabsTrigger value="text"><FileText className="mr-2 h-4 w-4" />Type Problem</TabsTrigger>
                                <TabsTrigger value="image"><ImageIcon className="mr-2 h-4 w-4" />Upload Image</TabsTrigger>
                            </TabsList>
                            <TabsContent value="text" className="pt-4 space-y-2">
                                <Label htmlFor="problem-input">Type your problem below</Label>
                                <div className="flex items-center gap-2">
                                    <Textarea id="problem-input" placeholder="e.g., Solve for x: 2x^2 - 5x + 3 = 0" value={problem} onChange={(e) => setProblem(e.target.value)} rows={3} />
                                    {recognition && <Button variant="outline" size="icon" onClick={toggleListening}>{isListening ? <MicOff /> : <Mic />}</Button>}
                                </div>
                            </TabsContent>
                            <TabsContent value="image" className="pt-4">
                                <Label>Upload an image of your problem</Label>
                                <Input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} />
                                {imageFile && <p className="text-sm text-slate-500 mt-2">Selected: {imageFile.name}</p>}
                            </TabsContent>
                        </Tabs>

                        <div className="grid grid-cols-2 gap-4">
                            <div><Label>Subject</Label><Select value={subject} onValueChange={setSubject}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{mathSubjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select></div>
                            <div><Label>Language</Label><Select value={language} onValueChange={setLanguage}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{languages.map(l => <SelectItem key={l.code} value={l.code}>{l.name}</SelectItem>)}</SelectContent></Select></div>
                        </div>

                        <Button onClick={handleSolve} disabled={isLoading} className="w-full" size="lg"><Sparkles className="w-5 h-5 mr-2" />{isLoading ? 'Solving...' : 'Solve Problem'}</Button>
                    </CardContent>
                </Card>

                {/* Output Card */}
                <div className="space-y-4">
                    {error && <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>}
                    {!isLoading && !result && <Card className="flex items-center justify-center h-full min-h-[300px] bg-slate-100 border-dashed"><div className="text-center text-slate-500"><Brain className="w-16 h-16 mx-auto mb-4 text-slate-300" /><h3 className="text-lg font-semibold">Your Solution Appears Here</h3><p>Enter a problem and let our AI tutor guide you.</p></div></Card>}
                    {isLoading && <Card className="flex items-center justify-center h-full min-h-[300px]"><Loader2 className="w-12 h-12 animate-spin text-primary" /></Card>}
                    
                    {result && (
                        <Card className="shadow-lg">
                            <CardHeader>
                                <CardTitle className="flex justify-between items-center">Solution Breakdown <Button variant="outline" size="icon" onClick={() => speakResult(result.step_by_step_solution.map(s => `Step ${s.step}. ${s.explanation}`).join('. '))}><Volume2 /></Button></CardTitle>
                                <CardDescription>Final Answer: <strong className="text-primary text-lg">{result.final_answer}</strong></CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Tabs defaultValue="solution">
                                    <TabsList className="grid w-full grid-cols-4">
                                        <TabsTrigger value="solution">Steps</TabsTrigger>
                                        <TabsTrigger value="graph" disabled={!result.graph_data}>Graph</TabsTrigger>
                                        <TabsTrigger value="concepts">Concepts</TabsTrigger>
                                        <TabsTrigger value="practice">Practice</TabsTrigger>
                                    </TabsList>
                                    <TabsContent value="solution" className="mt-4 prose max-w-none">
                                        {result.step_by_step_solution.map(step => (
                                            <div key={step.step} className="mb-4 p-3 bg-slate-50 rounded-lg">
                                                <h4 className="font-bold">Step {step.step}</h4>
                                                <ReactMarkdown>{step.explanation}</ReactMarkdown>
                                            </div>
                                        ))}
                                    </TabsContent>
                                    <TabsContent value="graph" className="mt-4 h-80">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <LineChart data={result.graph_data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                                <CartesianGrid strokeDasharray="3 3" />
                                                <XAxis dataKey="x" />
                                                <YAxis />
                                                <Tooltip />
                                                <Legend />
                                                <Line type="monotone" dataKey="y" stroke="#1d4ed8" strokeWidth={2} />
                                            </LineChart>
                                        </ResponsiveContainer>
                                    </TabsContent>
                                    <TabsContent value="concepts" className="mt-4">
                                        <ul className="list-disc pl-5 space-y-2">
                                            {result.key_concepts.map((concept, i) => <li key={i}>{concept}</li>)}
                                        </ul>
                                    </TabsContent>
                                    <TabsContent value="practice" className="mt-4 space-y-4">
                                        {result.practice_problems.map((prob, i) => (
                                            <div key={i} className="p-3 bg-slate-50 rounded-lg">
                                                <p><strong>Q:</strong> {prob.question}</p>
                                                <p className="text-sm text-green-700"><strong>A:</strong> {prob.answer}</p>
                                            </div>
                                        ))}
                                    </TabsContent>
                                </Tabs>
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
        </div>
    );
}
