import React, { useState, useEffect } from "react";
import { InvokeLLM, UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { Summary } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Loader2, Sparkles, Upload, FileText, Download, Eye, Copy, RefreshCw, CheckCircle, Wand2 } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { motion, AnimatePresence } from "framer-motion";

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "it", name: "Italiano", flag: "🇮🇹" },
  { code: "pt", name: "Português", flag: "🇵🇹" },
  { code: "zh", name: "中文", flag: "🇨🇳" },
  { code: "ja", name: "日本語", flag: "🇯🇵" },
  { code: "ko", name: "한국어", flag: "🇰🇷" },
  { code: "ar", name: "العربية", flag: "🇸🇦" },
  { code: "ru", name: "Русский", flag: "🇷🇺" },
  { code: "hi", name: "हिन्दी", flag: "🇮🇳" }
];

const summaryLengths = [
  { id: "short", name: "Short", description: "Key points only", percentage: 20 },
  { id: "medium", name: "Medium", description: "Balanced overview", percentage: 40 },
  { id: "long", name: "Long", description: "Comprehensive summary", percentage: 60 },
  { id: "custom", name: "Custom", description: "Set your own length", percentage: 30 }
];

const summaryStyles = [
  { id: "paragraph", name: "Paragraph", description: "Flowing narrative style" },
  { id: "bullets", name: "Bullet Points", description: "Structured key points" },
  { id: "outline", name: "Outline", description: "Hierarchical structure" },
  { id: "academic", name: "Academic", description: "Scholarly format" }
];

const toneOptions = [
  { id: "professional", name: "Professional" },
  { id: "casual", name: "Casual" },
  { id: "academic", name: "Academic" },
  { id: "journalistic", name: "Journalistic" },
  { id: "technical", name: "Technical" }
];

export default function Summarizer() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const summaryId = searchParams.get('summaryId');

    const [isLoading, setIsLoading] = useState(false);
    const [isRewriting, setIsRewriting] = useState(false);
    const [summary, setSummary] = useState(null);
    const [originalSummary, setOriginalSummary] = useState(null);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [source, setSource] = useState("text");
    const [file, setFile] = useState(null);
    const [inputText, setInputText] = useState("");
    const [language, setLanguage] = useState("en");
    const [summaryLength, setSummaryLength] = useState("medium");
    const [customLength, setCustomLength] = useState([30]);
    const [summaryStyle, setSummaryStyle] = useState("paragraph");
    const [tone, setTone] = useState("professional");
    const [enablePolish, setEnablePolish] = useState(true);
    const [enableHighlighting, setEnableHighlighting] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [detectedTopic, setDetectedTopic] = useState("");
    const [dragActive, setDragActive] = useState(false);

    useEffect(() => {
        if (summaryId) {
            loadExistingSummary();
        }
    }, [summaryId]);

    const loadExistingSummary = async () => {
        try {
            const existingSummary = await Summary.get(summaryId);
            setSummary(existingSummary);
            setOriginalSummary(existingSummary);
        } catch (error) {
            console.error("Error loading summary:", error);
        }
    };

    const handleDrag = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
        else if (e.type === "dragleave") setDragActive(false);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            setFile(e.dataTransfer.files[0]);
        }
    };

    const handleFileSelect = (e) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const detectTopic = async (content) => {
        try {
            const topicResponse = await InvokeLLM({
                prompt: `Analyze this content and identify the main topic/subject in 2-3 words: ${content.substring(0, 500)}`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        topic: { type: "string" }
                    }
                }
            });
            return topicResponse.topic || "General";
        } catch (error) {
            return "General";
        }
    };

    const handleGenerate = async () => {
        setIsLoading(true);
        setError(null);
        setSuccess(null);
        setSummary(null);
        setDetectedTopic("");

        try {
            let contentToSummarize = "";
            let title = "Document Summary";

            if (source === "text") {
                if (!inputText || inputText.trim().length < 50) {
                    throw new Error("Please enter at least 50 characters of text to summarize.");
                }
                contentToSummarize = inputText;
                title = "Text Summary";
            } else if (source === "document") {
                if (!file) {
                    throw new Error("Please upload a file to summarize.");
                }
                title = `${file.name} Summary`;
                const uploadRes = await UploadFile({ file });
                const extractRes = await ExtractDataFromUploadedFile({
                    file_url: uploadRes.file_url,
                    json_schema: { type: "object", properties: { content: { type: "string" } } }
                });
                if (extractRes.status !== 'success' || !extractRes.output.content) {
                    throw new Error("Failed to extract content from the document.");
                }
                contentToSummarize = extractRes.output.content;
            }

            // Detect topic for context-aware summarization
            const topic = await detectTopic(contentToSummarize);
            setDetectedTopic(topic);

            const selectedLanguage = languages.find(l => l.code === language)?.name || 'English';
            const lengthConfig = summaryLengths.find(l => l.id === summaryLength);
            const lengthPercentage = summaryLength === "custom" ? customLength[0] : lengthConfig.percentage;
            
            let styleInstructions = "";
            switch (summaryStyle) {
                case "bullets":
                    styleInstructions = "Format as clear bullet points with main ideas.";
                    break;
                case "outline":
                    styleInstructions = "Structure as a hierarchical outline with main topics and subtopics.";
                    break;
                case "academic":
                    styleInstructions = "Write in academic format with proper citations and scholarly tone.";
                    break;
                default:
                    styleInstructions = "Write in flowing paragraph format.";
            }

            const prompt = `You are a professional summarization expert. Create a high-quality ${tone} summary of the following content.

CONTENT TOPIC: ${topic}
TARGET LANGUAGE: ${selectedLanguage}
SUMMARY LENGTH: Reduce to approximately ${lengthPercentage}% of original length
STYLE: ${styleInstructions}
${enableHighlighting ? 'HIGHLIGHTING: Emphasize key concepts with **bold** formatting.' : ''}
${enablePolish ? 'POLISH: Ensure grammar, clarity, and professional tone.' : ''}

Please write the ENTIRE summary in ${selectedLanguage}.

Content to summarize:
${contentToSummarize}`;

            const response = await InvokeLLM({ 
                prompt,
                add_context_from_internet: topic !== "General" // Add context for specific topics
            });

            if (!response || response.trim().length < 20) {
                throw new Error("The AI generated an insufficient summary. Please try again.");
            }

            const summaryData = {
                title: title,
                summarized_content: response,
                original_content: contentToSummarize,
                language: selectedLanguage,
                source_type: source,
                style: summaryStyle,
                length: summaryLength,
                tone: tone,
                topic: topic
            };

            setSummary(summaryData);
            setOriginalSummary(summaryData);

        } catch (err) {
            setError(err.message || "An unexpected error occurred.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleRewrite = async () => {
        if (!summary) return;
        setIsRewriting(true);
        setError(null);

        try {
            const selectedLanguage = languages.find(l => l.code === language)?.name || 'English';
            
            const rewritePrompt = `Rewrite this summary in a different style while preserving all key information:

Original Summary:
${summary.summarized_content}

Instructions:
- Maintain the same key points and information
- Change the sentence structure and word choice
- Keep the ${tone} tone
- Write in ${selectedLanguage}
- ${summaryStyle === "bullets" ? "Keep bullet point format" : "Maintain paragraph format"}`;

            const rewrittenContent = await InvokeLLM({ prompt: rewritePrompt });

            setSummary(prev => ({
                ...prev,
                summarized_content: rewrittenContent
            }));

            setSuccess("Summary rewritten successfully!");
            setTimeout(() => setSuccess(null), 3000);

        } catch (error) {
            setError("Failed to rewrite summary. Please try again.");
            console.error(error);
        } finally {
            setIsRewriting(false);
        }
    };

    const handleSave = async () => {
        if (!summary) return;
        setIsSaving(true);
        setError(null);
        setSuccess(null);
        
        try {
            const savedSummary = await Summary.create({
                title: summary.title,
                original_content: summary.original_content.substring(0, 10000),
                summarized_content: summary.summarized_content,
                source_type: summary.source_type,
                language: summary.language,
                style: summary.style,
                tone: summary.tone,
                topic: summary.topic
            });
            setSuccess("Summary saved successfully!");
            setTimeout(() => setSuccess(null), 3000);
        } catch (err) {
            setError("Failed to save summary.");
            console.error(err);
        } finally {
            setIsSaving(false);
        }
    };

    const copyToClipboard = (content) => {
        navigator.clipboard.writeText(content);
        setSuccess("Copied to clipboard!");
        setTimeout(() => setSuccess(null), 2000);
    };

    const downloadFile = (content, format, filename) => {
        const blob = new Blob([content], { type: format });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const resetToOriginal = () => {
        if (originalSummary) {
            setSummary(originalSummary);
            setSuccess("Reset to original summary!");
            setTimeout(() => setSuccess(null), 2000);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="flex items-center gap-4 mb-8">
                    <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Dashboard"))}>
                        <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">AI Summarizer Pro</h1>
                        <p className="text-slate-600 mt-1">Professional-grade text summarization with advanced customization</p>
                    </div>
                </div>

                {error && <Alert variant="destructive" className="mb-4"><AlertDescription>{error}</AlertDescription></Alert>}
                {success && <Alert className="mb-4 border-green-200 bg-green-50 text-green-800"><AlertDescription>{success}</AlertDescription></Alert>}

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                    {/* Input Section */}
                    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Wand2 className="w-5 h-5 text-primary" />
                                Create Your Summary
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <Tabs value={source} onValueChange={setSource}>
                                <TabsList className="grid w-full grid-cols-2">
                                    <TabsTrigger value="text">
                                        <FileText className="mr-2 h-4 w-4"/>
                                        Text Input
                                    </TabsTrigger>
                                    <TabsTrigger value="document">
                                        <Upload className="mr-2 h-4 w-4"/>
                                        File Upload
                                    </TabsTrigger>
                                </TabsList>
                                
                                <TabsContent value="text" className="mt-4">
                                    <Textarea
                                        placeholder="Paste your text here... (minimum 50 characters)"
                                        value={inputText}
                                        onChange={(e) => setInputText(e.target.value)}
                                        rows={8}
                                        className="bg-slate-50"
                                    />
                                    <div className="flex justify-between text-xs text-slate-500 mt-1">
                                        <span>{inputText.length} characters</span>
                                        <span>{inputText.length >= 50 ? "✓ Ready" : "Need 50+ characters"}</span>
                                    </div>
                                </TabsContent>
                                
                                <TabsContent value="document" className="mt-4">
                                    <div
                                        className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
                                            dragActive ? "border-primary bg-primary/10" : "border-slate-300 hover:border-slate-400"
                                        }`}
                                        onDragEnter={handleDrag}
                                        onDragLeave={handleDrag}
                                        onDragOver={handleDrag}
                                        onDrop={handleDrop}
                                    >
                                        <input
                                            type="file"
                                            id="file-upload"
                                            className="hidden"
                                            onChange={handleFileSelect}
                                            accept=".pdf,.doc,.docx,.txt"
                                        />
                                        {file ? (
                                            <div className="space-y-2">
                                                <FileText className="w-12 h-12 text-primary mx-auto" />
                                                <p className="font-medium text-slate-900">{file.name}</p>
                                                <p className="text-sm text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                                                <label htmlFor="file-upload">
                                                    <Button type="button" variant="outline" size="sm">Change file</Button>
                                                </label>
                                            </div>
                                        ) : (
                                            <div>
                                                <Upload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                                                <label htmlFor="file-upload" className="cursor-pointer">
                                                    <h3 className="text-lg font-semibold text-slate-700 mb-2">
                                                        <span className="text-primary">Click to upload</span> or drag and drop
                                                    </h3>
                                                </label>
                                                <p className="text-slate-500 text-sm">Supports PDF, Word, and text files</p>
                                            </div>
                                        )}
                                    </div>
                                </TabsContent>
                            </Tabs>

                            {/* Advanced Settings */}
                            <div className="space-y-6 pt-4 border-t">
                                <h3 className="font-semibold text-slate-900">Customization Options</h3>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label>Language</Label>
                                        <Select value={language} onValueChange={setLanguage}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {languages.map(l => (
                                                    <SelectItem key={l.code} value={l.code}>
                                                        <div className="flex items-center gap-2">
                                                            <span>{l.flag}</span>
                                                            <span>{l.name}</span>
                                                        </div>
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    
                                    <div>
                                        <Label>Tone</Label>
                                        <Select value={tone} onValueChange={setTone}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {toneOptions.map(t => (
                                                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label>Summary Length</Label>
                                        <Select value={summaryLength} onValueChange={setSummaryLength}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {summaryLengths.map(l => (
                                                    <SelectItem key={l.id} value={l.id}>
                                                        <div>
                                                            <div className="font-medium">{l.name}</div>
                                                            <div className="text-xs text-slate-500">{l.description}</div>
                                                        </div>
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                        {summaryLength === "custom" && (
                                            <div className="mt-2">
                                                <Label className="text-xs">Custom Length: {customLength[0]}%</Label>
                                                <Slider
                                                    value={customLength}
                                                    onValueChange={setCustomLength}
                                                    max={80}
                                                    min={10}
                                                    step={5}
                                                    className="mt-1"
                                                />
                                            </div>
                                        )}
                                    </div>
                                    
                                    <div>
                                        <Label>Format Style</Label>
                                        <Select value={summaryStyle} onValueChange={setSummaryStyle}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {summaryStyles.map(s => (
                                                    <SelectItem key={s.id} value={s.id}>
                                                        <div>
                                                            <div className="font-medium">{s.name}</div>
                                                            <div className="text-xs text-slate-500">{s.description}</div>
                                                        </div>
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="highlighting"
                                            checked={enableHighlighting}
                                            onCheckedChange={setEnableHighlighting}
                                        />
                                        <Label htmlFor="highlighting">Smart Highlighting</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="polish"
                                            checked={enablePolish}
                                            onCheckedChange={setEnablePolish}
                                        />
                                        <Label htmlFor="polish">Grammar Polish</Label>
                                    </div>
                                </div>
                            </div>

                            <Button
                                onClick={handleGenerate}
                                disabled={isLoading || (source === 'text' && inputText.length < 50) || (source === 'document' && !file)}
                                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
                                size="lg"
                            >
                                {isLoading ? (
                                    <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating Summary...</>
                                ) : (
                                    <><Sparkles className="w-5 h-5 mr-2" /> Generate Professional Summary</>
                                )}
                            </Button>
                        </CardContent>
                    </Card>

                    {/* Output Section */}
                    <div className="space-y-6">
                        {detectedTopic && (
                            <Card className="bg-blue-50/80 backdrop-blur-sm border-blue-200">
                                <CardContent className="p-4">
                                    <div className="flex items-center gap-2">
                                        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                            Detected Topic: {detectedTopic}
                                        </Badge>
                                        <span className="text-xs text-blue-600">AI optimized for this subject</span>
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {summary ? (
                            <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
                                <CardHeader className="pb-4">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-xl">Generated Summary</CardTitle>
                                            <div className="flex gap-2 mt-2">
                                                <Badge variant="outline">{summary.style}</Badge>
                                                <Badge variant="outline">{summary.tone}</Badge>
                                                {summary.topic && <Badge variant="outline">{summary.topic}</Badge>}
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            <Button variant="outline" size="sm" onClick={() => copyToClipboard(summary.summarized_content)}>
                                                <Copy className="w-4 h-4 mr-1" />
                                                Copy
                                            </Button>
                                            <Button variant="outline" size="sm" onClick={handleRewrite} disabled={isRewriting}>
                                                {isRewriting ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <RefreshCw className="w-4 h-4 mr-1" />}
                                                Rewrite
                                            </Button>
                                            <Button variant="outline" size="sm" onClick={() => downloadFile(summary.summarized_content, 'text/plain', 'summary.txt')}>
                                                <Download className="w-4 h-4 mr-1" />
                                                Export
                                            </Button>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="prose max-w-none bg-slate-50 rounded-lg p-6 border h-96 overflow-y-auto">
                                        <AnimatePresence mode="wait">
                                            <motion.div
                                                key={summary.summarized_content}
                                                initial={{ opacity: 0 }}
                                                animate={{ opacity: 1 }}
                                                exit={{ opacity: 0 }}
                                                transition={{ duration: 0.3 }}
                                            >
                                                {summary.summarized_content.split('\n').map((paragraph, index) => (
                                                    <p key={index} className="mb-3 text-slate-800 leading-relaxed">
                                                        {paragraph.split('**').map((part, i) => 
                                                            i % 2 === 1 ? <strong key={i} className="text-primary font-semibold">{part}</strong> : part
                                                        )}
                                                    </p>
                                                ))}
                                            </motion.div>
                                        </AnimatePresence>
                                    </div>
                                    <div className="flex justify-between items-center mt-4">
                                        <div className="flex gap-2">
                                            {originalSummary && (
                                                <Button variant="ghost" size="sm" onClick={resetToOriginal}>
                                                    <RefreshCw className="w-4 h-4 mr-1" />
                                                    Reset to Original
                                                </Button>
                                            )}
                                        </div>
                                        <Button onClick={handleSave} disabled={isSaving} className="bg-primary">
                                            {isSaving ? <><Loader2 className="w-4 h-4 animate-spin mr-2"/>Saving...</> : <><CheckCircle className="w-4 h-4 mr-2"/>Save Summary</>}
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="flex items-center justify-center h-96 border-2 border-dashed border-slate-300 rounded-lg bg-slate-50/50">
                                <div className="text-center text-slate-500">
                                    <FileText className="w-20 h-20 mx-auto mb-4 text-slate-300" />
                                    <h3 className="text-xl font-semibold text-slate-600 mb-2">Your Professional Summary Will Appear Here</h3>
                                    <p className="text-slate-500">Provide text or upload a document to get started</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}