import React, { useState, useEffect } from "react";
import { User, Course, FlashcardSet, Flashcard } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Sparkles, Wand2, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";

export default function CourseBuilderPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState("");
  const [formData, setFormData] = useState({
    topic: "",
    level: "intermediate",
    language: "en",
    summary: ""
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (e) {
      // Redirect to login or home if not authenticated
      navigate(createPageUrl("Home"));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGenerateCourse = async () => {
    setIsLoading(true);
    setError(null);
    setGenerationProgress(0);
    
    try {
      // Step 1: Generate Course Outline
      setCurrentStep("Designing course structure...");
      setGenerationProgress(15);

      const courseStructurePrompt = `You are a world-class instructional designer. A user wants to create a course on "${formData.topic}".
      Their learning objective is: "${formData.summary || 'Provide a comprehensive overview'}".
      The target audience is ${formData.level}. The language must be ${formData.language}.

      Generate a complete, professional-grade course structure containing:
      1. A compelling 'title' and a short, engaging 'description'.
      2. An array of 3-5 'learning_objectives'.
      3. An array of 'prerequisites'.
      4. An 'estimated_duration' string.
      5. A 'syllabus' array of 4-6 modules. For each module, generate a unique 'id', a 'module_title', a 'module_description', and an array of 4-6 'topics' to be covered.`;

      const courseStructure = await InvokeLLM({
        prompt: courseStructurePrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" },
            learning_objectives: { type: "array", items: { type: "string" } },
            prerequisites: { type: "array", items: { type: "string" } },
            estimated_duration: { type: "string" },
            syllabus: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  id: { type: "string" },
                  module_title: { type: "string" },
                  module_description: { type: "string" },
                  topics: { type: "array", items: { type: "string" } },
                },
                required: ["id", "module_title", "module_description", "topics"]
              }
            }
          },
          required: ["title", "description", "syllabus"]
        }
      });
      
      setCurrentStep("Generating detailed content for each module...");
      const modulesWithContentAndQuizzes = [];
      const totalModules = courseStructure.syllabus.length;

      for (let i = 0; i < totalModules; i++) {
        const module = courseStructure.syllabus[i];
        const progress = 30 + (i / totalModules) * 60;
        setGenerationProgress(progress);
        setCurrentStep(`Processing Module ${i + 1}/${totalModules}: ${module.module_title}`);

        // Step 2: Generate Lesson Content
        const moduleContentPrompt = `For a course on "${formData.topic}", generate detailed content for the module "${module.module_title}".
        The module covers these topics: ${module.topics.join(', ')}. Target audience is ${formData.level}. Language must be ${formData.language}.

        Your response must be a JSON object containing:
        1. 'lesson_content': A detailed, well-structured text for the lesson (using Markdown for formatting like headers, lists, and bold text).
        2. 'key_points': An array of the 3-5 most important takeaways.
        3. 'summary': A concise summary of the module content.`;

        const moduleContent = await InvokeLLM({
          prompt: moduleContentPrompt,
          response_json_schema: {
            type: "object",
            properties: {
              lesson_content: { type: "string" },
              key_points: { type: "array", items: { type: "string" } },
              summary: { type: "string" }
            },
            required: ["lesson_content", "key_points", "summary"]
          }
        });

        // Step 3: Generate Quiz
        const quizPrompt = `Create a 5-question multiple-choice quiz for the module "${module.module_title}" based on its content. Provide a question, an array of 4 options, and the correct answer for each. The language must be ${formData.language}.`;
        const quizResponse = await InvokeLLM({
          prompt: quizPrompt,
          response_json_schema: {
            type: "object",
            properties: {
              questions: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    question: { type: "string" },
                    options: { type: "array", items: { type: "string" } },
                    answer: { type: "string" }
                  },
                  required: ["question", "options", "answer"]
                }
              }
            },
            required: ["questions"]
          }
        });

        const newSet = await FlashcardSet.create({
            title: `${module.module_title} - Quiz`,
            subject: formData.topic,
            source_type: 'ai_generated'
        });
        const flashcards = quizResponse.questions.map((q, index) => ({
            set_id: newSet.id,
            question: q.question,
            answer: q.answer,
            explanation: `Options were: ${q.options.join(', ')}`, // Store options in explanation
            order_index: index
        }));
        await Flashcard.bulkCreate(flashcards);

        modulesWithContentAndQuizzes.push({
          ...module,
          content: moduleContent.lesson_content,
          key_points: moduleContent.key_points,
          summary: moduleContent.summary,
          quiz_id: newSet.id
        });
      }

      setCurrentStep("Finalizing course...");
      const courseData = {
        title: courseStructure.title,
        subject: formData.topic,
        level: formData.level,
        language: formData.language,
        meta_description: courseStructure.description,
        learning_objectives: courseStructure.learning_objectives,
        prerequisites: courseStructure.prerequisites,
        estimated_duration: courseStructure.estimated_duration,
        syllabus: modulesWithContentAndQuizzes,
        status: 'draft'
      };

      const newCourse = await Course.create(courseData);
      setGenerationProgress(100);
      setCurrentStep("Course created successfully!");
      
      setTimeout(() => navigate(createPageUrl(`CourseEditor?id=${newCourse.id}`)), 1000);

    } catch (err) {
      console.error(err);
      setError("Failed to create course. The AI may have returned an unexpected format. Please check your inputs and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return (
        <div className="flex h-screen items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg shadow-2xl">
          <CardContent className="p-8 text-center">
            <Wand2 className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Crafting Your Course...</h3>
            <p className="text-gray-600 mb-6">{currentStep}</p>
            <Progress value={generationProgress} className="w-full" />
            <p className="text-xs text-gray-500 mt-4">This may take a few moments. Please don't close this window.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="py-12">
        <div className="max-w-2xl mx-auto px-4">
          <div className="text-center mb-10">
            <Wand2 className="mx-auto h-12 w-12 text-primary" />
            <h1 className="mt-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">AI Course Builder</h1>
            <p className="mt-4 text-lg text-gray-500">Turn any topic into a professional, well-structured course in minutes.</p>
          </div>

          <Card className="shadow-lg">
            <CardHeader><CardTitle>1. Describe Your Course</CardTitle></CardHeader>
            <CardContent className="space-y-6">
              {error && <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>}
              
              <div className="space-y-2">
                <label htmlFor="topic" className="font-medium text-gray-700">Course Topic *</label>
                <Input id="topic" name="topic" value={formData.topic} onChange={handleInputChange} placeholder="e.g., Introduction to Python, Digital Marketing" required />
              </div>

              <div className="space-y-2">
                <label htmlFor="summary" className="font-medium text-gray-700">Summary / Learning Objective (Optional)</label>
                <Textarea id="summary" name="summary" value={formData.summary} onChange={handleInputChange} placeholder="e.g., 'This course should teach students how to build a basic web application from scratch.'" className="h-24" />
                <p className="text-xs text-gray-500">Provide a brief summary to help the AI tailor the content to your goals.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="level" className="font-medium text-gray-700">Difficulty</label>
                  <Select name="level" value={formData.level} onValueChange={(value) => handleSelectChange('level', value)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="beginner">Beginner</SelectItem><SelectItem value="intermediate">Intermediate</SelectItem><SelectItem value="advanced">Advanced</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                   <label htmlFor="language" className="font-medium text-gray-700">Language</label>
                   <Select name="language" value={formData.language} onValueChange={(value) => handleSelectChange('language', value)}>
                     <SelectTrigger><SelectValue /></SelectTrigger>
                     <SelectContent><SelectItem value="en">English</SelectItem><SelectItem value="es">Spanish</SelectItem><SelectItem value="fr">French</SelectItem><SelectItem value="de">German</SelectItem></SelectContent>
                   </Select>
                </div>
              </div>
              <Button onClick={handleGenerateCourse} disabled={isLoading || !formData.topic.trim()} className="w-full text-lg py-6"><Sparkles className="mr-2 h-5 w-5" />Generate Complete Course</Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}