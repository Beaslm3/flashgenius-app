import React, { useState, useEffect } from 'react';
import { User, Course, FlashcardSet, Summary } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  BookOpen, Copy, Trash2, Edit, Plus, ExternalLink, Loader2, Search, MoreVertical, 
  Share, TrendingUp, Target, Clock, Trophy, Brain, FileText, Activity, Zap, Star, Bell, Settings, Wand2
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, 
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const StatsCard = ({ icon: Icon, title, value, change, color }) => (
  <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-all">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-3xl font-bold text-gray-900">{value}</p>
          {change && (
            <p className={`text-sm ${change > 0 ? 'text-green-600' : 'text-red-600'} flex items-center gap-1 mt-1`}>
              <TrendingUp className="w-4 h-4" />
              {change > 0 ? '+' : ''}{change}% from last week
            </p>
          )}
        </div>
        <div className={`w-12 h-12 ${color} rounded-lg flex items-center justify-center text-white`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </CardContent>
  </Card>
);

const ContentGrid = ({ items, type, onDelete }) => {
  const navigate = useNavigate();

  const getEditUrl = (item) => {
    switch (type) {
      case 'Course': return createPageUrl(`CourseEditor?id=${item.id}`);
      case 'FlashcardSet': return createPageUrl(`Edit?id=${item.id}`);
      default: return null;
    }
  };

  const getViewUrl = (item) => {
    switch (type) {
      case 'Course': return createPageUrl(`CourseViewer?id=${item.id}`);
      case 'FlashcardSet': return createPageUrl(`Study?set=${item.id}`);
      case 'Summary': return createPageUrl(`Summarizer?summaryId=${item.id}`);
      default: return null;
    }
  };

  const getTypeIcon = () => {
    switch (type) {
      case 'Course': return <BookOpen className="w-5 h-5 text-primary" />;
      case 'FlashcardSet': return <Copy className="w-5 h-5 text-green-600" />;
      case 'Summary': return <FileText className="w-5 h-5 text-purple-600" />;
      default: return <BookOpen className="w-5 h-5" />;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {items.map((item, index) => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300 group h-full flex flex-col">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-secondary rounded-md">{getTypeIcon()}</div>
                  <CardTitle className="font-semibold text-base text-gray-900 truncate leading-tight">{item.title}</CardTitle>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onSelect={() => navigate(getViewUrl(item))}><ExternalLink className="w-4 h-4 mr-2" />View / Study</DropdownMenuItem>
                    {getEditUrl(item) && <DropdownMenuItem onSelect={() => navigate(getEditUrl(item))}><Edit className="w-4 h-4 mr-2" />Edit</DropdownMenuItem>}
                    <DropdownMenuItem><Share className="w-4 h-4 mr-2" />Share</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600 focus:text-red-600"><Trash2 className="w-4 h-4 mr-2" />Delete</DropdownMenuItem>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                          <AlertDialogDescription>This action cannot be undone. This will permanently delete your {type.toLowerCase()}.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => onDelete(type, item.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-sm text-gray-600 line-clamp-2 mb-4">{item.meta_description || item.description}</p>
            </CardContent>
            <div className="p-6 pt-0 flex items-center justify-between text-xs text-muted-foreground">
                <Badge variant="outline">{item.subject || type}</Badge>
                {item.status && <Badge variant={item.status === 'published' ? 'default' : 'secondary'}>{item.status}</Badge>}
            </div>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [content, setContent] = useState({ courses: [], flashcardSets: [], summaries: [] });
  const [filteredContent, setFilteredContent] = useState({ courses: [], flashcardSets: [], summaries: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('courses');
  const [stats, setStats] = useState({ totalCourses: 0, totalSets: 0, totalSummaries: 0, avgScore: 0 });

  useEffect(() => { loadDashboardData(); }, []);
  useEffect(() => { filterContent(); }, [content, searchTerm, activeTab]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      const [courses, flashcardSets, summaries] = await Promise.all([
        Course.filter({ created_by: currentUser.email }, '-created_date'),
        FlashcardSet.filter({ created_by: currentUser.email }, '-created_date'),
        Summary.filter({ created_by: currentUser.email }, '-created_date'),
      ]);
      setContent({ courses, flashcardSets, summaries });
      setStats({ totalCourses: courses.length, totalSets: flashcardSets.length, totalSummaries: summaries.length, avgScore: 88 });
    } catch (error) { console.error("Error loading dashboard data:", error); } 
    finally { setIsLoading(false); }
  };

  const filterContent = () => {
    const filter = (items) => items.filter(item => 
      item.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.subject?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredContent({
      courses: filter(content.courses),
      flashcardSets: filter(content.flashcardSets),
      summaries: filter(content.summaries)
    });
  };

  const handleDelete = async (type, id) => {
    try {
      switch (type) {
        case 'Course': await Course.delete(id); break;
        case 'FlashcardSet': await FlashcardSet.delete(id); break;
        case 'Summary': await Summary.delete(id); break;
      }
      loadDashboardData();
    } catch (error) { console.error(`Failed to delete ${type}:`, error); }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-gray-900 mb-1">Welcome back, {user?.full_name?.split(' ')[0]}!</h1>
        <p className="text-lg text-gray-600">Here's your learning dashboard at a glance.</p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard icon={BookOpen} title="Courses" value={stats.totalCourses} change={2} color="bg-primary" />
          <StatsCard icon={Copy} title="Flashcard Sets" value={stats.totalSets} change={5} color="bg-green-600" />
          <StatsCard icon={FileText} title="Summaries" value={stats.totalSummaries} change={-1} color="bg-purple-600" />
          <StatsCard icon={Star} title="Average Score" value={`${stats.avgScore}%`} change={3} color="bg-amber-500" />
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <TabsList>
              <TabsTrigger value="courses">Courses ({filteredContent.courses.length})</TabsTrigger>
              <TabsTrigger value="flashcards">Flashcards ({filteredContent.flashcardSets.length})</TabsTrigger>
              <TabsTrigger value="summaries">Summaries ({filteredContent.summaries.length})</TabsTrigger>
            </TabsList>
            <div className="flex items-center gap-2">
              <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" /><Input placeholder="Search content..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10 w-48 sm:w-64" /></div>
              <DropdownMenu>
                  <DropdownMenuTrigger asChild><Button><Plus className="w-4 h-4 mr-2" />Create New</Button></DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                      <DropdownMenuItem onSelect={() => navigate(createPageUrl('CourseBuilder'))}><Wand2 className="w-4 h-4 mr-2" />Create Course</DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => navigate(createPageUrl('Create'))}><Plus className="w-4 h-4 mr-2" />Create Flashcards</DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => navigate(createPageUrl('Summarizer'))}><FileText className="w-4 h-4 mr-2" />Create Summary</DropdownMenuItem>
                  </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          <TabsContent value="courses">
            {filteredContent.courses.length > 0 ? (
              <ContentGrid items={filteredContent.courses} type="Course" onDelete={handleDelete} />
            ) : (<div className="text-center py-12"><BookOpen className="mx-auto w-12 h-12 mb-4 text-gray-300" /><h3 className="text-lg font-semibold text-gray-700">No courses yet.</h3><p className="text-gray-500 mb-4">Create your first course with our AI Course Builder.</p><Button onClick={() => navigate(createPageUrl('CourseBuilder'))}><Plus className="w-4 h-4 mr-2" />Create Course</Button></div>)}
          </TabsContent>
          <TabsContent value="flashcards">
            {filteredContent.flashcardSets.length > 0 ? (
              <ContentGrid items={filteredContent.flashcardSets} type="FlashcardSet" onDelete={handleDelete} />
            ) : (<div className="text-center py-12"><Copy className="mx-auto w-12 h-12 mb-4 text-gray-300" /><h3 className="text-lg font-semibold text-gray-700">No flashcard sets.</h3><p className="text-gray-500 mb-4">Generate flashcards from any topic or document.</p><Button onClick={() => navigate(createPageUrl('Create'))}><Plus className="w-4 h-4 mr-2" />Create Flashcards</Button></div>)}
          </TabsContent>
          <TabsContent value="summaries">
            {filteredContent.summaries.length > 0 ? (
              <ContentGrid items={filteredContent.summaries} type="Summary" onDelete={handleDelete} />
            ) : (<div className="text-center py-12"><FileText className="mx-auto w-12 h-12 mb-4 text-gray-300" /><h3 className="text-lg font-semibold text-gray-700">No summaries available.</h3><p className="text-gray-500 mb-4">Summarize long documents or articles with AI.</p><Button onClick={() => navigate(createPageUrl('Summarizer'))}><Plus className="w-4 h-4 mr-2" />Create Summary</Button></div>)}
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}