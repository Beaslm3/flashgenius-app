import React, { useState, useEffect } from 'react';
import { StudyPlan, User } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Calendar, Clock, Target, Brain, Plus, Edit, Trash2, CheckCircle, AlertCircle, Download, Share, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

const StudyPlanForm = ({ onSubmit, isGenerating }) => {
  const [formData, setFormData] = useState({
    title: '',
    goals: '',
    subjects: '',
    available_hours_per_day: 2,
    deadline: '',
    study_technique: 'mixed'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const planData = {
      ...formData,
      goals: formData.goals.split(',').map(g => g.trim()),
      subjects: formData.subjects.split(',').map(s => s.trim())
    };
    onSubmit(planData);
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5" />
          Create Your Personalized Study Plan
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="title">Study Plan Title</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              placeholder="e.g., Final Exam Preparation"
              required
            />
          </div>

          <div>
            <Label htmlFor="goals">Learning Goals (comma-separated)</Label>
            <Textarea
              id="goals"
              value={formData.goals}
              onChange={(e) => setFormData({...formData, goals: e.target.value})}
              placeholder="e.g., Master calculus, Improve writing skills, Learn Spanish basics"
              required
            />
          </div>

          <div>
            <Label htmlFor="subjects">Subjects (comma-separated)</Label>
            <Input
              id="subjects"
              value={formData.subjects}
              onChange={(e) => setFormData({...formData, subjects: e.target.value})}
              placeholder="e.g., Mathematics, English, History"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="hours">Available Hours Per Day</Label>
              <Input
                id="hours"
                type="number"
                min="0.5"
                max="12"
                step="0.5"
                value={formData.available_hours_per_day}
                onChange={(e) => setFormData({...formData, available_hours_per_day: parseFloat(e.target.value)})}
                required
              />
            </div>

            <div>
              <Label htmlFor="deadline">Target Deadline</Label>
              <Input
                id="deadline"
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData({...formData, deadline: e.target.value})}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="technique">Preferred Study Technique</Label>
            <Select value={formData.study_technique} onValueChange={(value) => setFormData({...formData, study_technique: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select study technique" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pomodoro">Pomodoro Technique (25-min blocks)</SelectItem>
                <SelectItem value="spaced_repetition">Spaced Repetition</SelectItem>
                <SelectItem value="block_schedule">Time Blocking</SelectItem>
                <SelectItem value="mixed">Mixed Approach</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            type="submit" 
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {isGenerating ? (
              <>
                <Brain className="w-4 h-4 mr-2 animate-spin" />
                Generating Your Plan...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Generate Study Plan
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

const StudyPlanViewer = ({ studyPlan, onEdit, onDelete }) => {
  const [selectedDay, setSelectedDay] = useState('Monday');
  
  const daySchedule = studyPlan.schedule?.find(day => day.day === selectedDay);
  const subjectColors = {
    'Mathematics': 'bg-blue-100 text-blue-800',
    'English': 'bg-green-100 text-green-800',
    'History': 'bg-purple-100 text-purple-800',
    'Science': 'bg-orange-100 text-orange-800',
    'default': 'bg-gray-100 text-gray-800'
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">{studyPlan.title}</h2>
              <p className="text-purple-100">Created: {new Date(studyPlan.created_date).toLocaleDateString()}</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{studyPlan.progress}%</div>
              <p className="text-sm text-purple-100">Complete</p>
            </div>
          </div>
          <Progress value={studyPlan.progress} className="mt-4 bg-purple-400" />
        </CardContent>
      </Card>

      {/* Goals and Subjects */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-600" />
              Learning Goals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {studyPlan.goals?.map((goal, index) => (
                <li key={index} className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className="text-sm">{goal}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-600" />
              Subjects
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {studyPlan.subjects?.map((subject, index) => (
                <Badge key={index} className={subjectColors[subject] || subjectColors.default}>
                  {subject}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            Weekly Schedule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedDay} onValueChange={setSelectedDay}>
            <TabsList className="grid w-full grid-cols-7">
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                <TabsTrigger key={day} value={day} className="text-xs">
                  {day.slice(0, 3)}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <TabsContent value={selectedDay} className="mt-4">
              <div className="space-y-3">
                {daySchedule?.time_blocks?.map((block, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-4 rounded-lg border-l-4 ${
                      block.completed ? 'bg-green-50 border-green-500' : 'bg-white border-purple-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Clock className="w-4 h-4 text-gray-500" />
                          <span className="font-medium">{block.start_time} - {block.end_time}</span>
                          <Badge className={subjectColors[block.subject] || subjectColors.default}>
                            {block.subject}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{block.task}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={block.priority === 'high' ? 'destructive' : block.priority === 'medium' ? 'default' : 'secondary'}>
                          {block.priority}
                        </Badge>
                        {block.completed && <CheckCircle className="w-5 h-5 text-green-500" />}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-4">
        <Button onClick={onEdit} className="flex-1">
          <Edit className="w-4 h-4 mr-2" />
          Edit Plan
        </Button>
        <Button variant="outline" className="flex-1">
          <Download className="w-4 h-4 mr-2" />
          Export PDF
        </Button>
        <Button variant="outline" className="flex-1">
          <Share className="w-4 h-4 mr-2" />
          Share Plan
        </Button>
        <Button variant="destructive" onClick={onDelete}>
          <Trash2 className="w-4 h-4 mr-2" />
          Delete
        </Button>
      </div>
    </div>
  );
};

export default function StudyPlanner() {
  const navigate = useNavigate();
  const [studyPlans, setStudyPlans] = useState([]);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadStudyPlans();
  }, []);

  const loadStudyPlans = async () => {
    try {
      const plans = await StudyPlan.list('-created_date');
      setStudyPlans(plans);
    } catch (error) {
      console.error('Error loading study plans:', error);
    }
  };

  const generateStudyPlan = async (formData) => {
    setIsGenerating(true);
    try {
      const response = await InvokeLLM({
        prompt: `Create a detailed study plan with the following requirements:
        
        Title: ${formData.title}
        Goals: ${formData.goals.join(', ')}
        Subjects: ${formData.subjects.join(', ')}
        Available hours per day: ${formData.available_hours_per_day}
        Deadline: ${formData.deadline}
        Study technique: ${formData.study_technique}
        
        Generate a comprehensive weekly schedule with specific time blocks, tasks, and priorities. 
        Include variety in study methods and ensure realistic time allocation.
        Return the schedule as a structured JSON format.`,
        response_json_schema: {
          type: "object",
          properties: {
            schedule: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  day: { type: "string" },
                  time_blocks: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        start_time: { type: "string" },
                        end_time: { type: "string" },
                        subject: { type: "string" },
                        task: { type: "string" },
                        priority: { type: "string", enum: ["low", "medium", "high"] },
                        completed: { type: "boolean", default: false }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      });

      const planData = {
        ...formData,
        schedule: response.schedule,
        progress: 0,
        color_scheme: {
          'Mathematics': '#3b82f6',
          'English': '#10b981',
          'History': '#8b5cf6',
          'Science': '#f97316'
        }
      };

      const newPlan = await StudyPlan.create(planData);
      setCurrentPlan(newPlan);
      setShowForm(false);
      loadStudyPlans();
    } catch (error) {
      console.error('Error generating study plan:', error);
      alert('Failed to generate study plan. Please try again.');
    }
    setIsGenerating(false);
  };

  const handleDeletePlan = async (planId) => {
    try {
      await StudyPlan.delete(planId);
      setCurrentPlan(null);
      loadStudyPlans();
    } catch (error) {
      console.error('Error deleting study plan:', error);
    }
  };

  if (currentPlan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPlan(null)}
              className="bg-white/80 backdrop-blur-sm"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">Study Plan Viewer</h1>
          </div>

          <StudyPlanViewer
            studyPlan={currentPlan}
            onEdit={() => {
              setShowForm(true);
              setCurrentPlan(null);
            }}
            onDelete={() => handleDeletePlan(currentPlan.id)}
          />
        </div>
      </div>
    );
  }

  if (showForm) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowForm(false)}
              className="bg-white/80 backdrop-blur-sm"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">Create Study Plan</h1>
          </div>

          <StudyPlanForm onSubmit={generateStudyPlan} isGenerating={isGenerating} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl('Dashboard'))}
              className="bg-white/80 backdrop-blur-sm"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Study Planner</h1>
              <p className="text-gray-600">Create personalized AI-generated study plans</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Study Plan
          </Button>
        </div>

        {studyPlans.length === 0 ? (
          <Card className="text-center p-12 bg-white/80 backdrop-blur-sm">
            <Target className="w-16 h-16 text-purple-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Study Plans Yet</h3>
            <p className="text-gray-500 mb-6">Create your first personalized study plan to get started!</p>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Plan
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {studyPlans.map((plan, index) => (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card 
                  className="bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all cursor-pointer group"
                  onClick={() => setCurrentPlan(plan)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-bold text-lg group-hover:text-purple-600 transition-colors">
                          {plan.title}
                        </h3>
                        <p className="text-sm text-gray-500">
                          {plan.subjects?.join(', ')}
                        </p>
                      </div>
                      <Badge className="bg-purple-100 text-purple-700">
                        {plan.progress}%
                      </Badge>
                    </div>
                    
                    <Progress value={plan.progress} className="mb-4" />
                    
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {plan.available_hours_per_day}h/day
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Due: {new Date(plan.deadline).toLocaleDateString()}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}