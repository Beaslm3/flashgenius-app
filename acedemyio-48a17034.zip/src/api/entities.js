import { base44 } from './base44Client';


export const FlashcardSet = base44.entities.FlashcardSet;

export const Flashcard = base44.entities.Flashcard;

export const TestSession = base44.entities.TestSession;

export const Subscription = base44.entities.Subscription;

export const Course = base44.entities.Course;

export const Summary = base44.entities.Summary;

export const Referral = base44.entities.Referral;

export const ClassSchedule = base44.entities.ClassSchedule;

export const Message = base44.entities.Message;

export const Assignment = base44.entities.Assignment;

export const AssignmentSubmission = base44.entities.AssignmentSubmission;

export const Blog = base44.entities.Blog;

export const CourseReview = base44.entities.CourseReview;

export const CourseEnrollment = base44.entities.CourseEnrollment;

export const CoursePricing = base44.entities.CoursePricing;

export const ZoomSession = base44.entities.ZoomSession;

export const StudyPlan = base44.entities.StudyPlan;

export const ProgressReport = base44.entities.ProgressReport;

export const Achievement = base44.entities.Achievement;

export const PaymentMethod = base44.entities.PaymentMethod;

export const ContactMessage = base44.entities.ContactMessage;

export const AISession = base44.entities.AISession;



// auth sdk:
export const User = base44.auth;